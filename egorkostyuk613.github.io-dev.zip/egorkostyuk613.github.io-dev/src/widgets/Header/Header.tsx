import { HeaderMainImage, HeaderRoot, StyledLink} from "widgets/Header/Header.styled";
import {Button} from "shared/ui";
import logo from "./logo.png"
import {Link} from "react-router-dom";
import {observer} from "mobx-react";
import {authModel} from "../../entities/auth/model/Auth.model";

export const Header = observer(() => {
  // const location: any = useLocation();

  return <HeaderRoot>
    <Link to="/">
    <HeaderMainImage src={logo}/>
    </Link>
    {/*<HeaderCenterText>*/}
    {/*  <HeaderLinks to="/about" $select={location.pathname === "/about"}>О нас</HeaderLinks>*/}
    {/*  <HeaderLinks to="/teacher" $select={location.pathname === "/teacher"}>Преподаватели</HeaderLinks>*/}
    {/*  <HeaderLinks to="/tariffs" $select={location.pathname === "/tariffs"}>Тарифы</HeaderLinks>*/}
    {/*  <HeaderLinks to="/news" $select={location.pathname === "/news"}>Новости</HeaderLinks>*/}
    {/*  <HeaderLinks to="/" $select={location.pathname === "/faq"}>FAQ</HeaderLinks>*/}
    {/*</HeaderCenterText>*/}
    <StyledLink to={authModel.user?.role === 1 ? "/account/teacher/schedule"  : authModel.user?.role === 2 ? "/account/schedule" : authModel.user?.role === 0 ? "/administr/students" : "/login"}>
      <Button variant='dark' height={50} mt={10 / 8}>Личный кабинет</Button>
    </StyledLink>
  </HeaderRoot>
})
