import {styled} from "shared/lib";
import {Box} from "@mui/system";


export const AccountSelectTimeRoot = styled(Box)({});

export const AccountTable = styled('table')({});

export const AccountTableHead = styled('thead')({});

export const AccountTableBody = styled('tbody')({});

export const AccountTableTr = styled('tr')({});

export const AccountTableTh = styled('th')({});

export const AccountTableTd = styled('td')({});
