import { useQuery } from "react-query";
import { getMaterialSolo } from "../../../AccountStudent/AccountCourses/api";
import { useState, useEffect } from "react";

export const useMaterial = () => {
  const [isQueryEnabled, setIsQueryEnabled] = useState(true);

  const { data, isLoading, isError } = useQuery({
    queryKey: "courses-solo",
    queryFn: getMaterialSolo,
    enabled: isQueryEnabled,  // Запрос будет выполняться только когда enabled === true
    onError: (error) => {
      console.log("An error occurred", error);
    },
    retry: false,
    onSuccess: () => {
      // После успешного запроса, отключаем выполнение последующих запросов
      setIsQueryEnabled(false);
    },
  });

  // Если данные загружены, можно установить запрос как неактивный
  useEffect(() => {
    if (data) {
      setIsQueryEnabled(false);
    }
  }, [data]);

  return {
    book: data,
    isLoading,
    isError,
  };
};
