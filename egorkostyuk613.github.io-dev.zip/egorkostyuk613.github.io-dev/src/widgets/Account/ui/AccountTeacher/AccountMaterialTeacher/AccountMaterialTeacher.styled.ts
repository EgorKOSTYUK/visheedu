import {styled} from "../../../../../shared/lib";
import {Box} from "@mui/system";

export const AccountMaterialRoot = styled(Box)({})

export const AccountHideTop = styled(Box)({
  position: 'absolute',
  top: 0,
  left: 0,
  height: 50,
  width: "100%",
  background: '#C1C6E0',
})

export const MaterialsContainer = styled(Box)({
  display: 'grid',
  gridTemplateColumns: '1fr 1fr 1fr',
  gap: 15,
})
