import { useEffect, useState } from 'react';
import {AccountHideTop} from "./AccountMaterialTeacher.styled";

export const PDFViewer = ({ base64Data }: { base64Data: string }) => {
  const [pdfUrl, setPdfUrl] = useState<string | null>(null);

  useEffect(() => {
    if (base64Data) {
      const blob = new Blob([Uint8Array.from(atob(base64Data), (c) => c.charCodeAt(0))], {
        type: 'application/pdf',
      });
      const url = URL.createObjectURL(blob);
      setPdfUrl(url);

      return () => URL.revokeObjectURL(url); // Освобождаем память
    }
  }, [base64Data]);

  return (
    <div style={{height: '100vh', width: '100%', position: 'relative'}}>
      <AccountHideTop />
      {pdfUrl ? (
        <iframe src={pdfUrl} style={{width: '100%', height: '100%'}} frameBorder="0"/>
      ) : (
        <p>Загрузка PDF...</p>
      )}
    </div>
  );
}
