export * from "./AccountMaterialTeacher"
