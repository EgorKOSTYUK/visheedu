import { useQuery } from "react-query";
import axios from "axios";
import {BACK_URL} from "../../../../../../shared/back/backURL";
import {authModel} from "../../../../../../entities/auth/model/Auth.model";

export const getMaterials = async (id: any) => {
  const res = await axios.get(BACK_URL + `api/course/studyBooks?courseId=${id}`, {
    withCredentials: true,
  })

  return res.data
}

export const useGetMaterialInCourses = (id: any) => {

  const { data, isLoading, isError } = useQuery({
    queryKey: "courses-books-solo",
    queryFn: () => getMaterials(id),
    onError: (error) => {
      console.log("An error occurred", error);
    },
    retry: false,
    onSuccess: authModel.setBooksAxios,
  });

  return {
    book: data,
    isLoading,
    isError,
  };
};
