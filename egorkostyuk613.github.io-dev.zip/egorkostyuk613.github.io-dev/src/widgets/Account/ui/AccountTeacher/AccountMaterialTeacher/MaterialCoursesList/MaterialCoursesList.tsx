import {
  AllMaterialsWrapper, MaterialsCoursesButtonsContainer,
  MaterialsCoursesContainer
} from "../../../../../Admin/ui/AllMaterials/AllMaterials.styled";
import {Link} from "react-router-dom";
import {Button} from "../../../../../../shared/ui";
import {MaterialsContainer} from "../../../../../Admin/ui/AllMaterials/Materials/Materials.styled";
import {useMaterial} from "../hooks/useMaterial";
import {authModel} from "../../../../../../entities/auth/model/Auth.model";

export const MaterialCoursesList = () => {
  const {book} = useMaterial()

  return <MaterialsContainer>
    <AllMaterialsWrapper>
      {book?.courses ? book?.courses.map((value: any) => {
        return <MaterialsCoursesContainer>
          {value.title}
          <MaterialsCoursesButtonsContainer>
            <Link to={`/account/teacher/materials/${value._id}`}>
              <Button variant="outlined" onClick={() => authModel.setBooks(value.studyBooks)}>Перейти</Button>
            </Link>
          </MaterialsCoursesButtonsContainer>
        </MaterialsCoursesContainer>
      }) : null}
    </AllMaterialsWrapper>
  </MaterialsContainer>
}

