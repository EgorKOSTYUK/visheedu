import {AccountMaterialRoot, MaterialsContainer} from "./AccountMaterialTeacher.styled";
import {Material} from "./Material";
import {authModel} from "../../../../../entities/auth/model/Auth.model";
import {useGetMaterialInCourses} from "./hooks/useGetMaterialInCourses";
import {useParams} from "react-router-dom";

export const AccountMaterialTeacher = () => {
  const {coureId} = useParams()

  useGetMaterialInCourses(coureId)

  // console.log(book)

  // const [selectedFile, setSelectedFile] = useState(null);
  //
  // const handleFileChange = (event: any) => {
  //   const file = event.target.files[0];
  //   if (file) {
  //     setSelectedFile(file);
  //   }
  // };
  //
  // const handleUpload = async () => {
  //   if (!selectedFile) {
  //     alert("Пожалуйста, выберите файл для загрузки");
  //     return;
  //   }
  //
  //   const formData = new FormData();
  //   formData.append("studyBook", selectedFile);
  //
  //   for (let [key, value] of formData.entries()) {
  //     console.log(`${key}:`, value);
  //   }
  //
  //   try {
  //     const response = await axios.post(
  //       "http://localhost:4000/api/course/studyBook/6767509a7b5f095966cedf65",
  //       formData,
  //       {
  //         withCredentials: true,
  //       }
  //     );
  //
  //     alert("Файл успешно загружен");
  //     console.log("Серверный ответ:", response.data);
  //   } catch (error) {
  //     console.error("Ошибка при загрузке файла:", error);
  //     alert("Ошибка при загрузке файла. Попробуйте снова.");
  //   }
  // };

  return (
    <AccountMaterialRoot>
      <h3>Учебные материалы</h3>
      <MaterialsContainer>
        {authModel.books ? authModel.books.map((value: any) => {
          return <Material id={value._id} name={value.name}/>
        }) : null}
      </MaterialsContainer>
    </AccountMaterialRoot>
  );
};
