export enum AccountTeacherEnum {
  main = 'main',
  schedule = 'schedule',
  list = "list",
  materials = 'materials',
}
