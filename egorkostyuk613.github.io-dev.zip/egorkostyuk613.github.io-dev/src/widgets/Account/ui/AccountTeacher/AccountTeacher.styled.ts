import {styled} from "shared/lib";
import {Box} from "@mui/system";

export const AccountTeachertRoot = styled(Box)({

})

export const AccountTeacherContainer = styled(Box)({})

export const AccountTeacherTitle = styled(Box)({
  fontSize: "24px",
  fontWeight: 600,
})
