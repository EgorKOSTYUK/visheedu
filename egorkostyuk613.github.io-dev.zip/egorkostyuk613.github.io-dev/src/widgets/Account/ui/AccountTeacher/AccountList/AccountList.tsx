import {AccountCoursesRoot} from "./AccountList.styled";
import {AccountHeadText} from "../../Account.styled";
import {Stack} from "@mui/system";
import {Pupil} from "./Pupil";
import {useGetStudents} from "./hooks/useGetStudents";
import {accountTeacherModel} from "../model/AccountTeacher.model";

export const AccountList = () => {
  useGetStudents()

  return <AccountCoursesRoot>
    <AccountHeadText>Список учеников</AccountHeadText>
    <Stack spacing={15 / 8} mt={25 / 8}>
      {accountTeacherModel?.students && accountTeacherModel?.students.map((value: any) => <Pupil {...value}/>)}
    </Stack>
  </AccountCoursesRoot>
}
