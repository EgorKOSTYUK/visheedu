import { useQuery } from "react-query";
import { getStudents } from "../../../AccountStudent/AccountCourses/api";
import { accountTeacherModel } from "../../model/AccountTeacher.model";

export const useGetStudents = () => {
  const { students } = accountTeacherModel;

  const { isLoading, isError } = useQuery({
    queryKey: "students-teacher",
    queryFn: getStudents,
    enabled: !students,
    staleTime: Infinity,
    onSuccess: accountTeacherModel.setStudents,
    onError: (error) => {
      console.log("An error occurred", error);
    },
  });

  return {
    isLoading,
    isError,
    students, // Возвращаем students из MobX
  };
};
