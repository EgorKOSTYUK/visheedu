import {NameContainer, NameText, PupilContainer, SpanRightStyled, StyledBox} from "./Pupil.styled";
import { ReactComponent as Arrow } from './arrow.svg'
import { ReactComponent as Avatar } from './avatar.svg'
import {Button} from "shared/ui";
import {Link} from "react-router-dom";
import {AvatarUser} from "../AccountList.styled";

export const Pupil = (props: any) => {

  return <PupilContainer>
    <NameContainer>
      {props.picture ? <AvatarUser src={props.picture}/> : <Avatar />}
      <NameText>{props.name} {props.surname}</NameText>
    </NameContainer>
    <StyledBox>
      <Link to={`/account/teacher/students/${props._id}`}>
        <Button variant="outlinedv5"> <SpanRightStyled>Прощедшие уроки</SpanRightStyled> <Arrow /> </Button>
      </Link>
    </StyledBox>
  </PupilContainer>
}
