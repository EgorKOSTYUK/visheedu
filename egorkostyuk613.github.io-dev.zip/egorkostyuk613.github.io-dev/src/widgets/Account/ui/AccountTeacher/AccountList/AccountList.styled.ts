import {styled} from "shared/lib";
import {Box} from "@mui/system";

export const AccountCoursesRoot = styled(Box)({

})

export const AvatarUser = styled('img')({
  width: 27,
  height: 27,
  borderRadius: "50%"
})
