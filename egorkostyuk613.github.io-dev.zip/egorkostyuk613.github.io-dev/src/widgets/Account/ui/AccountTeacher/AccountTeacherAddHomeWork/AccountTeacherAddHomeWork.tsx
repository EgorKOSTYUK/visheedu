import {useRef, useState} from "react";
import {useDropzone} from "react-dropzone";
import {
  ButtonsContainer,
  IconsContaienr,
  SendBlackButton, SendDragItem,
  SendHomeWorkContainer,
  SendHomeWorkContent,
  SendHomeWorkLeft,
  SendHomeWorkRight,
  SendPurpleButton, SendSmallText,
  SendTable, SendTableBody,
  SendTableHead, SendTableRow,
  SendText,
  SendWhiteContainer
} from "../../AccountStudent/AccountHomeWork/HomeWork/SendHomeWork/SendHomeWork.styled";
import {
  AccountDialogaTitle,
  AccountDialogButton, AccountDialogContainer,
  AccountHwTitle, AccountStar, AccountStarContainer, CloseDialog
} from "../../AccountStudent/AccountHomeWork/AccountHomeWork.styled";
import {format} from "date-fns";

import { ReactComponent as Trash } from './assets/trash.svg'
import { ReactComponent as Add } from './assets/add.svg'
import { ReactComponent as Upload } from './assets/upload.svg'
import {useGetHomeWork} from "./hooks/useGetHomeWork";
import { useParams } from "react-router-dom";
import {Box} from "@mui/system";
import {
  AccountStudentButtonGray,
  AccountStudentButtonPurp, AccountStudentHomeWorkLine,
  AccountStudentText
} from "../AccountTeacherStudent/AccountTeacherStudent.styled";
import { ReactComponent as Pdf } from './pdf.svg'
import axios from "axios";
import {Dialog} from "../../../../../shared/ui/Dialog/Dialog";
import {BACK_URL} from "../../../../../shared/back/backURL";

export const AccountTeacherAddHomeWork = () => {
  const { hw } = useParams()
  const [grade, setGrade] = useState<1 | 2 | 3 | 4 | 5 | null>(null)
  const [openDialog, setOpen] = useState<boolean>(false)

  // @ts-ignore
  const {lesson} = useGetHomeWork(hw)

  const [files, setFiles] = useState<File[]>([]);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const onDrop = (acceptedFiles: File[]) => {
    // Добавляем файлы в состояние
    setFiles((prevFiles) => [...prevFiles, ...acceptedFiles]);
  };

  const openFileDialog = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click(); // Клик по скрытому input
    }
  };

  const { getRootProps, getInputProps } = useDropzone({
    onDrop,
    maxFiles: 5,
    noClick: files.length > 0,
  });

  const uploadHomeWork = async () => {
    const formData = new FormData();

    // Добавляем файлы в FormData
    files.forEach((file) => {
      formData.append('homework', file); // 'homeworkFiles' - это название поля на сервере
    });

    try {
      // Отправка POST запроса с FormData
      await axios.post(BACK_URL + `api/lesson/homework/${hw}`, formData, {
        withCredentials: true,
        headers: {
          'Content-Type': 'multipart/form-data', // Указываем, что отправляем файлы
        },
      });

      // Очистка файлов после успешной загрузки
      setFiles([]);
      alert("Файлы успешно загружены!");
    } catch (error) {
      console.error("Ошибка при загрузке файлов:", error);
      alert("Ошибка при загрузке файлов!");
    }
  };

  const giveRate = async () => {
    try{
      await axios.patch(BACK_URL + `api/lesson/${hw}`, {
        // name,
        // description,
        // maxAnswerNumber,
        // deadLine,
        // comment,
        rating: grade,
        status: 1,
        // resetAttempt,
      }, {
        withCredentials: true,
      });

      setOpen(false)
    }catch(e){
      console.log(e)
    }
  }

  const handleClose = () => {
    setGrade(null)
    setOpen(false)
  }

  return <SendHomeWorkContainer>
    <AccountHwTitle>Домашнее задание ученика</AccountHwTitle>
    {!lesson?.homework ? <SendHomeWorkContent>
      <SendHomeWorkLeft>
        <SendText>Добавить в виде файла</SendText>
        <ButtonsContainer>
          <SendPurpleButton onClick={uploadHomeWork}>Сохранить</SendPurpleButton>
          <SendBlackButton>Отмена</SendBlackButton>
        </ButtonsContainer>
      </SendHomeWorkLeft>
      <SendHomeWorkRight>
        <IconsContaienr>
          <Add onClick={openFileDialog} />
          <Upload />
          <Trash onClick={() => setFiles([])}/>
        </IconsContaienr>
        <SendWhiteContainer {...getRootProps()}>
          <input {...getInputProps()} ref={fileInputRef} style={{ display: 'none' }}/>
          {files.length > 0 ? (
            <SendTable>
              <SendTableHead>
                <SendSmallText>Название</SendSmallText>
                <SendSmallText>Последнее изминение</SendSmallText>
                <SendSmallText>Размер</SendSmallText>
                <SendSmallText>Тип</SendSmallText>
              </SendTableHead>
              <SendTableBody>
                {files.map((file) => (
                  <SendTableRow key={file.name}>
                    <SendSmallText>{file.name}</SendSmallText>
                    <SendSmallText>{format(file.lastModified, 'dd.MM.yyyy')}</SendSmallText>
                    <SendSmallText>{(file.size / 1024).toFixed(2)} KB</SendSmallText>
                    <SendSmallText>{file.type}</SendSmallText>
                  </SendTableRow>
                ))}

              </SendTableBody>
            </SendTable>
          ) : (
            <SendDragItem>
              <SendText>Для загрузки файлов перетащите их сюда</SendText>
            </SendDragItem>
          )}

        </SendWhiteContainer>
      </SendHomeWorkRight>
    </SendHomeWorkContent> : lesson?.answer ? <AccountStudentHomeWorkLine>
      <Box display='flex' gap="22px" alignItems="center">
        <Pdf />
        <AccountStudentText>Домашняя работа</AccountStudentText>
      </Box>
      <Box display="flex" gap="6px" >
        <AccountStudentButtonPurp>Скачать</AccountStudentButtonPurp>
        <AccountStudentButtonGray onClick={() => setOpen(true)}>Оценить</AccountStudentButtonGray>
      </Box>
    </AccountStudentHomeWorkLine> : <SendText>Ожидание ответа от ученика</SendText>}

    <Dialog open={openDialog} onClose={handleClose}>
      <AccountDialogContainer>
        <CloseDialog onClick={handleClose}>X</CloseDialog>
        <AccountDialogaTitle>Оцените работу</AccountDialogaTitle>
        <AccountStarContainer>
          <AccountStar $select={grade === 1} onClick={() => setGrade(1)}>1</AccountStar>
          <AccountStar $select={grade === 2} onClick={() => setGrade(2)}>2</AccountStar>
          <AccountStar $select={grade === 3} onClick={() => setGrade(3)}>3</AccountStar>
          <AccountStar $select={grade === 4} onClick={() => setGrade(4)}>4</AccountStar>
          <AccountStar $select={grade === 5} onClick={() => setGrade(5)}>5</AccountStar>
        </AccountStarContainer>
        <AccountDialogButton onClick={giveRate}>Оценить</AccountDialogButton>
      </AccountDialogContainer>
    </Dialog>

  </SendHomeWorkContainer>
}
