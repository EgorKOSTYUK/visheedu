import { useQuery } from "react-query";
import {getBookSolo} from "../../../AccountStudent/AccountCourses/api";

export const useGetSoloBook = (id: string) => {

  const { data, isLoading, isError } = useQuery({
    queryKey: "book-solo",
    queryFn: () => getBookSolo(id),
    onError: (error) => {
      console.log("An error occurred", error);
    },
    retry: false,
  });


  return {
    book: data,
    isLoading,
    isError,
  };
};
