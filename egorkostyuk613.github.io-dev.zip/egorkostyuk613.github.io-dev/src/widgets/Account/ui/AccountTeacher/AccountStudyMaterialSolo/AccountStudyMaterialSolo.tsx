import {AccountStudyMaterialSoloContainer} from "./AccountStudyMaterialSolo.styled";
import {useGetSoloBook} from "./hooks/useGetSoloBook";
import {useParams} from "react-router-dom";
import {PDFViewer} from "../AccountMaterialTeacher/PDFViewer";
import {Loading} from "../../../../Loading/Loading";

export const AccountStudyMaterialSolo = () => {
  const { bookId, isLoading } = useParams()

  // @ts-ignore
  const {book} = useGetSoloBook(bookId)
  console.log(book)
  return <AccountStudyMaterialSoloContainer>
    {!isLoading && book ? <PDFViewer base64Data={book.file}/> : <Loading />}

  </AccountStudyMaterialSoloContainer>
}
