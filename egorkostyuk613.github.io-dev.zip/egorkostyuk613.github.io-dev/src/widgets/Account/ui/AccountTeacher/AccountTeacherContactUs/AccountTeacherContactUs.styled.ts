import {styled} from "../../../../../shared/lib";
import {Box, Stack} from "@mui/system";

export const AccountContactUsContainer = styled(Box)({})

export const AccountContactUsWrapper = styled(Stack)({})

export const AccountContactUsText = styled('p')({
  fontSize: 24,
  fontWeight: 'bold',
  lineHeight: "43px",
})

export const AccountInputMain = styled('input')({
  backgroundColor: 'white',
  maxWidth: 330,
  borderRadius: 10,
  paddingLeft: 18,
  height: 36,
  border: 'none',
  width: '100%',
  marginTop: 4,

  ['&:focus']: {
    outline: 'none',
  }
})

export const AccountTextAreMain = styled('textarea')({
  background: 'rgba(242, 242, 242, 1)',
  border: 'none',
  width: "60%",
  borderRadius: 10,
  height: 80,
  padding: 10,
  resize: 'none',

  ['&:focus']: {
    outline: 'none',
  }
})

export const AccountTextMain = styled('p')({
  fontSize: 16,
  fontWeight: 400,
  lineHeight: '28px'
})
