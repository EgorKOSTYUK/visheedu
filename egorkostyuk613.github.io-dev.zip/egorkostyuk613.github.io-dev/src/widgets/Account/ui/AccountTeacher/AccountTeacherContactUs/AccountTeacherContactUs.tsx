import {
  AccountContactUsContainer,
  AccountContactUsText,
  AccountContactUsWrapper, AccountInputMain, AccountTextAreMain, AccountTextMain
} from "./AccountTeacherContactUs.styled";
import {Box} from "@mui/system";
import {Button} from "../../../../../shared/ui";
import axios from "axios";
import {BACK_URL} from "../../../../../shared/back/backURL";
import {useState} from "react";
import {ErrorMessage, GreenMessage} from "../../../../Register/InfoTeacher/InfoTeacher.styled";

export const AccountTeacherContactUs = () => {
  const [title, setTitle] = useState<string>("");
  const [description, setDescription] = useState<string>("");
  const [error, setError] = useState<boolean>(false);
  const [send, setSend] = useState<boolean>(false);


  const sendFeedback = async () => {
    try{
      await axios.post( BACK_URL + 'api/course/supportTicket', {
        "title": title,
        "description": description
      }, {
        withCredentials: true
      })
      setSend(true)
      setError(false)
    }catch(e){
      console.log(e)
      setError(true)
    }

  }
  return <AccountContactUsContainer>
    <AccountContactUsWrapper spacing={10 / 8}>
      <AccountContactUsText>Связаться с нами</AccountContactUsText>
      <AccountTextMain>Здесь вы можете связаться с нами, если у вас возникли какие-то проблемы или предложения для развития нашей платформы.</AccountTextMain>
      <Box>
        <AccountInputMain placeholder="Тема" onChange={(e) => setTitle(e.target.value)} value={title}/>
      </Box>
      <Box>
        <AccountTextAreMain placeholder="Здесь вы можете написать свой вопрос" onChange={(e) => setDescription(e.target.value)} value={description}/>
      </Box>
      <Box>
        <Button onClick={sendFeedback}>Отправить</Button>
      </Box>
      {error ? <ErrorMessage>Не получилось связаться с нами, попробуйте немного позже</ErrorMessage> : null}
      {send ? <GreenMessage>Сообщение отправлено</GreenMessage> : null}
    </AccountContactUsWrapper>
  </AccountContactUsContainer>
}
