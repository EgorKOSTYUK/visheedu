import {AccountHomeWorkRoot} from "./AccountHomeWork.styled";

export const AccountHomeWork = () => {
  return <AccountHomeWorkRoot>
    hw
  </AccountHomeWorkRoot>
}
