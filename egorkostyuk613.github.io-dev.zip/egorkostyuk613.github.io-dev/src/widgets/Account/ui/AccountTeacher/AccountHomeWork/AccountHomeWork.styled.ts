import {styled} from "shared/lib";
import {Box} from "@mui/system";

export const AccountHomeWorkRoot = styled(Box)({

})
