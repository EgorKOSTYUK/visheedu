import React, { useState } from "react";
import { observer } from "mobx-react";
import { format } from "date-fns";
import {
  CalendarArrowBlock,
  CalendarArrowRightBlock, CalendarButtonContainer,
  CalendarDay,
  CalendarDays, CalendarErrorContainer, CalendarHeadText,
  CalendarRoot,
  CalendarSelectWeeks, CalendarSuccessContainer,
  CalendarSwitcherBlock,
  CalendarSwitchWeek,
  CalendarText,
  CalendarTime,
  CalendarTimes,
  CalendarTimeText,
  CalendarUpContainer,
  DayText, ErrorMessageText, SuccessMessageText,
} from "./ChangeSchadule.styled";
import { useWeeklyCalendar } from "../../../../Calendar/config";
import { authModel } from "../../../../../entities/auth/model/Auth.model";
import {Button} from "../../../../../shared/ui";
import axios from "axios";
import {BACK_URL} from "../../../../../shared/back/backURL";

export const ChangeSchadule = observer(() => {
  const { weekDaysWithTimes, goToPreviousWeek, goToNextWeek, weekRange } = useWeeklyCalendar();

  const [timeWeek, setTimeWeek] = useState<any>(authModel.user?.hours);
  const [error, setError] = useState<any>(false);
  const [success, setSuccess] = useState<any>(false);

  const handleTimeToggle = (dayName: string, index: number) => {
    setTimeWeek((prev: any) => {
      const currentDaySlots = prev?.[dayName] || [];

      const exists = currentDaySlots.some((slot: any) => slot.timeslot === index);

      const updatedDaySlots = exists
        ? currentDaySlots.filter((slot: any) => slot.timeslot !== index)
        : [...currentDaySlots, { timeslot: index }];

      return {
        ...prev,
        [dayName]: updatedDaySlots,
      };
    });
  };

  const selectNewTime = async () => {

    try{
      await axios.post(BACK_URL + 'api/extra/user/schedule', {
        hours: {
          Mon: timeWeek["Mon"].sort((a: any, b: any) => a.timeslot - b.timeslot),
          Tue: timeWeek["Tue"].sort((a: any, b: any) => a.timeslot - b.timeslot),
          Wed: timeWeek["Wed"].sort((a: any, b: any) => a.timeslot - b.timeslot),
          Thu: timeWeek["Thu"].sort((a: any, b: any) => a.timeslot - b.timeslot),
          Fri: timeWeek["Fri"].sort((a: any, b: any) => a.timeslot - b.timeslot),
          Sat: timeWeek["Sat"].sort((a: any, b: any) => a.timeslot - b.timeslot),
          Sun: timeWeek["Sun"].sort((a: any, b: any) => a.timeslot - b.timeslot),
        }
      }, {
        withCredentials: true
      })
      setSuccess(true)
      setError(false)
    }
    catch(e){
      setError(true)
      console.log(e)
    }
  }

  return (
    <CalendarRoot>
      <CalendarHeadText>Смена расписания (UTC+0) (Смена расписания один раз в 7 дней)</CalendarHeadText>
      <CalendarUpContainer>
        <CalendarSelectWeeks>
          <CalendarSwitcherBlock>
            <CalendarSwitchWeek>
              <CalendarArrowBlock onClick={goToPreviousWeek}>{"<"}</CalendarArrowBlock>
              <CalendarArrowRightBlock onClick={goToNextWeek}>{">"}</CalendarArrowRightBlock>
            </CalendarSwitchWeek>
            <CalendarText>{weekRange.start + " - " + weekRange.end}</CalendarText>
          </CalendarSwitcherBlock>
        </CalendarSelectWeeks>
        <CalendarDays>
          {weekDaysWithTimes.map((value) => (
            <CalendarDay key={value.dayNumber}>
              <DayText>{value.shortDay}</DayText>
              <DayText>{value.dayNumber}</DayText>
            </CalendarDay>
          ))}
        </CalendarDays>
        <CalendarTimes>
          {weekDaysWithTimes.map((value, index) => {
            const dayName = format(value.day, "EEE");
            const availableTimes = timeWeek?.[dayName] || [];

            return (
              <CalendarTime key={index}>
                {value.times.map((time, idx) => {
                  const isSelected = availableTimes.some(
                    (slot: any) => slot.timeslot === idx
                  );

                  return (
                    <CalendarTimeText
                      key={idx}
                      $select={isSelected}
                      onClick={() => handleTimeToggle(dayName, idx)}
                    >
                      {format(time, "HH:mm")}
                    </CalendarTimeText>
                  );
                })}
              </CalendarTime>
            );
          })}
        </CalendarTimes>
      </CalendarUpContainer>
      <CalendarButtonContainer>
        <Button onClick={selectNewTime}>Сменить</Button>
      </CalendarButtonContainer>

      {error && <CalendarErrorContainer>
        <ErrorMessageText>Что-то пошло не так, попробуйте позже</ErrorMessageText>
      </CalendarErrorContainer>}

      {success && <CalendarSuccessContainer>
        <SuccessMessageText>Расписание изменено</SuccessMessageText>
      </CalendarSuccessContainer>}

    </CalendarRoot>
  );
});
