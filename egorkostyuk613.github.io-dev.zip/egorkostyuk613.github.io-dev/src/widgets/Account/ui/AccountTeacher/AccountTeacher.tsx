import {AccountTeacherContainer, AccountTeachertRoot} from "./AccountTeacher.styled";
import {AccountContainer, AccountMenu, AccountMenuText} from "../Account.styled";
import {Link, Outlet, useLocation} from "react-router-dom";

export const AccountTeacher = () => {
  const location: any = useLocation()

  return <AccountTeachertRoot>
    <AccountContainer>
      <AccountMenu>
        <Link to="/account/teacher/schedule">
          <AccountMenuText $background={location.pathname === '/account/teacher/schedule'}>Расписание</AccountMenuText>
        </Link>
        <Link to="/account/teacher/students">
          <AccountMenuText $background={location.pathname && location?.pathname.startsWith('/account/teacher/students')}>Список учеников</AccountMenuText>
        </Link>
        <Link to="/account/teacher/materials">
          <AccountMenuText $background={location.pathname === '/account/teacher/materials'}>Учебные материалы</AccountMenuText>
        </Link>
        <Link to="/account/teacher/materials">
          <AccountMenuText $background={location.pathname === '/account/materials'}>Тарифы</AccountMenuText>
        </Link>
        <Link to="/account/teacher/changeSchadule">
          <AccountMenuText $background={location.pathname === '/account/teacher/changeSchadule'}>Сменить расписание</AccountMenuText>
        </Link>
        <Link to="/account/teacher/settings">
          <AccountMenuText $background={location.pathname === '/account/teacher/settings'}>Настройки</AccountMenuText>
        </Link>
        <Link to="/account/teacher/contactUs">
          <AccountMenuText $background={location.pathname === '/account/teacher/contactUs'}>Cвяжитесь с нами</AccountMenuText>
        </Link>
      </AccountMenu>
      <AccountTeacherContainer>
        <Outlet />
      </AccountTeacherContainer>
    </AccountContainer>
  </AccountTeachertRoot>
}
