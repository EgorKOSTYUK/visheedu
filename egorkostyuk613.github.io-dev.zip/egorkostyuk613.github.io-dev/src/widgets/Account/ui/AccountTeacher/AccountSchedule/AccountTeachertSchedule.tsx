import {AccountScheduleRoot} from "./AccountTeachertSchedule.styled";
import {useGetLessons} from "./hooks/useGetLessons";
import {AccountStudentTitle} from "../../AccountStudent/AccountStudent.styled";
import {Line} from "./Line/Line";
import {accountTeacherModel} from "../model/AccountTeacher.model";
import {observer} from "mobx-react";
import {Loading} from "../../../../Loading/Loading";

export const AccountTeachertSchedule = observer(() => {
  const {isLoading} = useGetLessons()

  return <AccountScheduleRoot>
    <AccountStudentTitle>Расписание</AccountStudentTitle>
    {
      isLoading ? <Loading /> : accountTeacherModel?.lessons ? accountTeacherModel?.lessons.map((value: any) => {
        return <Line deadLine={value.deadLine} title={value.course.title} id={value._id} key={value._id} student={value?.student}/>
      }) : null
    }
    {}

     </AccountScheduleRoot>
})
