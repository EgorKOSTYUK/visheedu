import {styled} from "../../../../../../shared/lib";
import {Box} from "@mui/system";


export const LineDialogContainer = styled(Box)({

})

export const DialogTitle = styled('p')({
  color: 'rgba(0, 0, 0, 1)',
  fontWeight: 500,
  fontSize: 22,
  lineHeight: "24px"
})

export const DialogText = styled('p')({
  color: 'rgba(0, 0, 0, 1)',
  fontWeight: 500,
  fontSize: 18,
  lineHeight: "24px",
})
