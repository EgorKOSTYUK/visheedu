import {
  AccountLessonsButton, AccountLessonsLine,
  AccountLessonsName,
  AccountLessonsTime
} from "../../../AccountStudent/AccountSchedule/AccountSchedule.styled";
import {format} from "date-fns";
import {Dialog} from "../../../../../../shared/ui/Dialog/Dialog";
import {useState} from "react";
import {DialogText, DialogTitle, LineDialogContainer} from "./Line.styled";
import {Button} from "../../../../../../shared/ui";
import { ReactComponent as Query } from './query.svg'
import { ReactComponent as Person } from './person.svg'
import {Box} from "@mui/system";
import axios from "axios";
import {BACK_URL} from "../../../../../../shared/back/backURL";

export const Line = (props: any) => {
  const [open, setOpen] = useState<boolean>(false);

  const cancelHour = async () => {
    try{
      const res = await axios.post(BACK_URL + 'api/public/schedule/clearHour/' + props.id, {},{
        withCredentials: true,
      })
      console.log(res)
    }catch (e){
      console.log(e)
    }

  }

  return <AccountLessonsLine>
    <AccountLessonsTime>{format(props.deadLine, 'dd.MM.yyyy HH:mm')}</AccountLessonsTime>
    <AccountLessonsName>{props.title}</AccountLessonsName>
    <AccountLessonsButton onClick={() => setOpen(true)}>Изменить</AccountLessonsButton>
    {/*<Link to={`/account/teacher/students/${props.id}`}>*/}
    {/*  */}
    {/*</Link>*/}
    <Dialog open={open} onClose={() => setOpen(false)}>
      <LineDialogContainer>
        <DialogTitle>{props.title}</DialogTitle>
        <Box display="flex" gap="6px" alignItems="center" mt={10 / 8}>
          <Query /> <DialogText>{format(props.deadLine, 'dd.MM.yyyy HH:mm')}</DialogText>
        </Box>
        {props?.student ? <Box display="flex" gap="6px" alignItems="center" mt={10 / 8}>
          <Person /> <DialogText>{props.student.name} {props.student.surname}</DialogText>
        </Box> : null}

        <Button variant="containedv2" mt={2}>Отменить урок</Button>
      </LineDialogContainer>
    </Dialog>
  </AccountLessonsLine>
}
