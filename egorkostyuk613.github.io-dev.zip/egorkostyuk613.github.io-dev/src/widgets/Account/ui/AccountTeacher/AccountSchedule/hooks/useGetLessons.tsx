import { useQuery } from "react-query";
import { getLessonsForTeacher } from "../../../AccountStudent/AccountCourses/api";
import { accountTeacherModel } from "../../model/AccountTeacher.model";

export const useGetLessons = () => {
  const { lessons } = accountTeacherModel;

  const { isLoading, isError } = useQuery({
    queryKey: "lessons-teacher",
    queryFn: getLessonsForTeacher,
    enabled: !lessons,
    staleTime: Infinity,
    onSuccess: accountTeacherModel.setLessons,
    onError: (error) => {
      console.log("An error occurred", error);
    },
  });

  return {
    isLoading,
    isError,
    lessons, // Возвращаем lessons из MobX для использования в компонентах
  };
};
