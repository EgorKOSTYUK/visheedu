import {
  AccountPastBlockContainer, AccountPastBlockText, AccountPastText,
  AccountStudentButton,
  AccountStudentButtonGray,
  AccountStudentButtonHw,
  AccountStudentButtonPurp, AccountStudentButtonPurple,
  AccountStudentContainer,
  AccountStudentHomeWorkLine,
  AccountStudentPastContainer,
  AccountStudentPill,
  AccountStudentText,
  AccountTeacherStudentBottomContainer,
  AccountTeacherStudentHeadContainer,
  AccountTeacherStudentListContainer,
  AccountTeacherStudentTabsContainer,
  AccountTeacherStudentText,
  AccountTeacherStudentTextSecond,
  AccountTeacherStudentWrapper
} from "./AccountTeacherStudent.styled";
import {Box, Stack} from "@mui/system";
import {Fragment, useState} from "react";
import { ReactComponent as Pdf } from './pdf.svg'
import {Link, useParams} from "react-router-dom";
import {useGetInfoStudent} from "./hooks/useGetInfoStudent";
import { format, parseISO } from 'date-fns';
import {Button} from "../../../../../shared/ui";
import axios from "axios";
import {BACK_URL} from "../../../../../shared/back/backURL";

export const AccountTeacherStudent = () => {
  const { studentId } = useParams()

  // @ts-ignore
  const {info} = useGetInfoStudent(studentId)

  const cancelHour = async (lessonId: string) => {
    try{
      const res = await axios.post(BACK_URL + 'api/public/schedule/clearHour' + lessonId, {},{
        withCredentials: true,
      })
      console.log(res)
    }catch (e){
      console.log(e)
    }

  }



  const [tab, setTab] = useState<'about' | 'hw' | 'pastLess'>('about')

  return <AccountTeacherStudentWrapper>
    <AccountTeacherStudentHeadContainer>
    <AccountTeacherStudentText> {tab === 'about' ? "Об ученике" : tab === 'hw' ? "Домашние задания" : "Прошедшие уроки"  }</AccountTeacherStudentText>
    <AccountTeacherStudentTabsContainer>
      {/*<AccountTeacherStudentTab onClick={() => setTab('about')} $background={tab === 'about'}>Об ученике</AccountTeacherStudentTab>*/}
      {/*<AccountTeacherStudentTab onClick={() => setTab('hw')} $background={tab === 'hw'}>Домашнее задание</AccountTeacherStudentTab>*/}
      {/*<AccountTeacherStudentTab onClick={() => setTab('pastLess')} $background={tab === 'pastLess'}>Прошедшие уроки</AccountTeacherStudentTab>*/}
    </AccountTeacherStudentTabsContainer>
      {/*{tab === 'about' && <AccountTeacherStudentTextSecond>Курс : Бизнес-Академия</AccountTeacherStudentTextSecond>  }*/}
      {tab === 'hw' && <AccountStudentButtonHw>Добавить домашнее задание</AccountStudentButtonHw>  }

    </AccountTeacherStudentHeadContainer>
    {tab === 'about' ? <Fragment><AccountTeacherStudentBottomContainer>
      <AccountTeacherStudentText>Запланированные уроки</AccountTeacherStudentText>
      {info && info.map((lesson: any, idx: number) => {
        const lessonTime = lesson?.time ? new Date(lesson.time) : null;
        // @ts-ignore
        const isWithinTimeLimit = lessonTime ? new Date() <= lessonTime.getTime() + 60 * 60 * 1000 : false;
        return (<AccountTeacherStudentListContainer>
          <AccountStudentContainer>
            <Box>
              <AccountStudentText>Урок {idx + 1}</AccountStudentText>
              <AccountStudentPill>{new Date(lesson.time).toISOString().replace("T", " ").slice(0, 16)} UTC+0</AccountStudentPill>
            </Box>
            <Box display={'flex'} gap={1}>
              <Link to={`/account/teacher/students/${studentId}/${lesson._id}`} style={{textDecoration: 'none', display: 'flex'}}>
                <AccountStudentButtonPurple>Перейти к домашнему заданию</AccountStudentButtonPurple>
              </Link>
              <Stack spacing={4 / 8}>
                <AccountStudentButton onClick={() => cancelHour(lesson._id)}>Отменить урок</AccountStudentButton>
                <Link to={`/account/teacher/students/${studentId}/${lesson._id}`} style={{textDecoration: 'none', display: 'flex'}}>
                  <AccountStudentButtonPurple>Подключиться к уроку</AccountStudentButtonPurple>
                </Link>
              </Stack>
            </Box>
          </AccountStudentContainer>
        </AccountTeacherStudentListContainer>)
      })}

    </AccountTeacherStudentBottomContainer></Fragment> : tab === 'hw' ? <Fragment>
      <AccountTeacherStudentBottomContainer>
      <AccountTeacherStudentText>Выполненные домашние задания</AccountTeacherStudentText>
        <AccountStudentHomeWorkLine>
          <Box display='flex' gap="22px" alignItems="center">
            <Pdf />
            <AccountStudentText>Домашняя работа</AccountStudentText>
          </Box>
          <Box display="flex" gap="6px">
            <Link to="/account/teacher/students/1111/1231">
              <AccountStudentButtonPurp>Открыть</AccountStudentButtonPurp>
            </Link>
            <AccountStudentButtonGray>Оценить</AccountStudentButtonGray>
          </Box>
        </AccountStudentHomeWorkLine>
        <AccountStudentHomeWorkLine>
          <Box display='flex' gap="22px" alignItems="center">
            <Pdf />
            <AccountStudentText>Домашняя работа</AccountStudentText>
          </Box>
          <Box display="flex" gap="6px">
            <Link to="/account/teacher/students/1111/1231">
              <AccountStudentButtonPurp>Открыть</AccountStudentButtonPurp>
            </Link>
            <AccountStudentButtonGray>Оценить</AccountStudentButtonGray>
          </Box>
        </AccountStudentHomeWorkLine>
        <AccountStudentHomeWorkLine>
          <Box display='flex' gap="22px" alignItems="center">
            <Pdf />
            <AccountStudentText>Домашняя работа</AccountStudentText>
          </Box>
          <Box display="flex" gap="6px" >
            <Link to="/account/teacher/students/1111/1231">
              <AccountStudentButtonPurp>Открыть</AccountStudentButtonPurp>
            </Link>
            <AccountStudentButtonGray>Оценить</AccountStudentButtonGray>
          </Box>
        </AccountStudentHomeWorkLine>
      </AccountTeacherStudentBottomContainer>

    </Fragment> : <Fragment>
      <AccountStudentPastContainer>
        <AccountPastBlockContainer>
          <AccountPastBlockText>Урок 1: Введение в морфологию</AccountPastBlockText>
          <AccountPastText>В этом уроке изучены основные части речи: существительное, прилагательное, глагол, наречие. Рассмотрены их грамматические категории и роль в предложении.</AccountPastText>
        </AccountPastBlockContainer>
        <AccountPastBlockContainer>
          <AccountPastBlockText>Урок 1: Введение в морфологию</AccountPastBlockText>
          <AccountPastText>В этом уроке изучены основные части речи: существительное, прилагательное, глагол, наречие. Рассмотрены их грамматические категории и роль в предложении.</AccountPastText>
        </AccountPastBlockContainer>
        <AccountPastBlockContainer>
          <AccountPastBlockText>Урок 1: Введение в морфологию</AccountPastBlockText>
          <AccountPastText>В этом уроке изучены основные части речи: существительное, прилагательное, глагол, наречие. Рассмотрены их грамматические категории и роль в предложении.</AccountPastText>
        </AccountPastBlockContainer>
      </AccountStudentPastContainer>
    </Fragment>}
  </AccountTeacherStudentWrapper>
}
