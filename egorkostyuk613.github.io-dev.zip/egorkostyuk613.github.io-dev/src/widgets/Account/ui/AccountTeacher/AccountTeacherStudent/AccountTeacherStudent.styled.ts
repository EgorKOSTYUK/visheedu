import {styled} from "../../../../../shared/lib";
import {Box} from "@mui/system";

export const AccountTeacherStudentWrapper = styled(Box)({})

export const AccountTeacherStudentText = styled('p')({
  fontSize: 24,
  fontWeight: 600,
  lineHeight: "43px",
})

export const AccountTeacherStudentTextSecond = styled('p')({
  fontSize: 20,
  fontWeight: 500,
  lineHeight: "27px",
})

export const AccountTeacherStudentHeadContainer = styled(Box)({
  marginBottom: 30,
})

export const AccountTeacherStudentBottomContainer = styled(Box)({
  ['a']: {
    textDecoration: 'none'
  }
})

export const AccountTeacherStudentListContainer = styled(Box)({
})

export const AccountTeacherStudentTabsContainer = styled(Box)({
  display: 'grid',
  gridTemplateColumns: 'repeat(3, 250px)',
  gap: 10,
  margin: "16px 0px",
})

interface studentTabProps {
  $background: boolean
}

export const AccountTeacherStudentTab = styled(Box)<studentTabProps>( ({$background}) => ({
  padding: '16px 32px',
  borderRadius: 8,
  textAlign: 'center',
  color: $background ? 'white' : 'black',
  background: $background ? 'rgba(117, 110, 222, 1)' : 'rgba(242, 242, 242, 1)',
  cursor: 'pointer',
  fontSize: 16,
  fontWeight: 400,
}))

export const AccountStudentContainer = styled(Box)({
  background: 'rgba(255, 255, 255, 1)',
  borderRadius: 8,
  padding: "24px 18px",
  maxWidth: 780,
  display: 'flex',
  justifyContent: 'space-between',
  marginTop: 8,
})

export const AccountStudentText = styled('p')({
  fontSize: 16,
  fontWeight: 500,
})

export const AccountStudentPill = styled(Box)({
  background: 'rgba(206, 212, 218, 1)',
  padding: '4px 10px',
  borderRadius: 20,
  width: 'fit-content',
  fontSize: 12,
  fontWeight: 400,
  marginTop: 18,
})

export const AccountStudentButton = styled(Box)({
  background: 'rgba(0, 0, 0, 1)',
  color: 'white',
  padding: '16px 32px',
  borderRadius: 8,
  textAlign: 'center',
  fontSize: 12,
  fontWeight: 400,
  height: 28,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  marginTop: 'auto',
  cursor: 'pointer'
})

export const AccountStudentButtonPurple = styled(Box)({
  background: 'rgba(117, 110, 222, 1)',
  color: 'white',
  padding: '16px 32px',
  borderRadius: 8,
  textAlign: 'center',
  fontSize: 12,
  fontWeight: 400,
  height: 28,
  display: 'flex',
  alignItems: 'center',
  marginTop: 'auto',
  cursor: 'pointer'
})

export const AccountStudentButtonHw = styled(Box)({
  background: 'rgba(0, 0, 0, 1)',
  color: 'white',
  padding: '16px 32px',
  borderRadius: 8,
  textAlign: 'center',
  fontSize: 16,
  fontWeight: 400,
  height: 44,
  display: 'flex',
  alignItems: 'center',
  marginTop: 'auto',
  cursor: 'pointer',
  width: 'fit-content',
})

export const AccountStudentHomeWorkLine = styled(Box)({
  background: 'rgba(255, 255, 255, 1)',
  borderRadius: 8,
  display: 'flex',
  justifyContent: 'space-between',
  padding: '25px 21px',
  marginTop: 8,
})


export const AccountStudentButtonPurp = styled(Box)({
  background: 'rgba(117, 110, 222, 1)',
  color: 'white',
  padding: '16px 32px',
  textAlign: 'center',
  fontSize: 12,
  fontWeight: 400,
  height: 28,
  display: 'flex',
  alignItems: 'center',
  marginTop: 'auto',
  cursor: 'pointer',
  borderRadius: 50,
})

export const AccountStudentButtonGray = styled(Box)({
  background: 'rgba(206, 212, 218, 1)',
  color: 'black',
  padding: '16px 32px',
  textAlign: 'center',
  fontSize: 12,
  fontWeight: 400,
  height: 28,
  display: 'flex',
  alignItems: 'center',
  marginTop: 'auto',
  cursor: 'pointer',
  borderRadius: 50,
})

export const AccountStudentPastContainer = styled(Box)({
  display: 'grid',
  gridTemplateColumns: '1fr 1fr 1fr',
  gap: 18,
})

export const AccountPastBlockContainer = styled(Box)({
  background: 'rgba(255, 255, 255, 1)',
  borderRadius: 8,
  padding: "18px 25px"
})

export const AccountPastBlockText = styled('p')({
  fontSize: 16,
  fontWeight: 500,
})

export const AccountPastText = styled('p')({
  fontSize: 12,
  fontWeight: 500,
})

