import { useQuery } from "react-query";
import { getStudentLessons } from "../../../AccountStudent/AccountCourses/api";
import { useState, useEffect } from "react";

export const useGetInfoStudent = (id: string) => {
  const [isQueryEnabled, setIsQueryEnabled] = useState(true);

  const { data, isLoading, isError } = useQuery({
    queryKey: "info-student",
    queryFn: () => getStudentLessons(id),
    enabled: isQueryEnabled,  // Запрос будет выполняться только когда enabled === true
    onError: (error) => {
      console.log("An error occurred", error);
    },
    retry: false,
    onSuccess: () => {
      // После успешного запроса, отключаем выполнение последующих запросов
      setIsQueryEnabled(false);
    },
  });

  // Если данные загружены, можно установить запрос как неактивный
  useEffect(() => {
    if (data) {
      setIsQueryEnabled(false);
    }
  }, [data]);

  return {
    info: data?.lessons,
    isLoading,
    isError,
  };
};
