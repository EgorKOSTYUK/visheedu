import {action, observable} from "mobx";

class AccountTeacher {
  @observable accessor lessons: any = null;
  @observable accessor students: any = null;

  @action.bound setLessons(lessons: any){

    this.lessons = lessons?.lessons
  }

  @action.bound setStudents(students: any){

    this.students = students?.users
  }
}

export const accountTeacherModel = new AccountTeacher();
