export enum AccountStudentEnum {
  schedule = 'schedule',
  hw = "hw",
  courses = 'courses',
  materials = 'materials',
  cards = 'cards',
  settings = 'settings',
}
