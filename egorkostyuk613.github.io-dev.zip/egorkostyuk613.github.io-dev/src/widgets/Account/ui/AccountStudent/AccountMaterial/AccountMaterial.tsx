import {AccountMaterialHeadText, AccountMaterialRoot, MaterialsContainer} from "./AccountMaterial.styled";
import {Material} from "./Material";
import {useMaterial} from "../../AccountTeacher/AccountMaterialTeacher/hooks/useMaterial";

export const AccountMaterial = () => {
  const {book} = useMaterial()

  return <AccountMaterialRoot>
    <AccountMaterialHeadText>Учебные материалы</AccountMaterialHeadText>
    <MaterialsContainer>
      {book ? book?.materials.map((value: any) => {
        return <Material id={value._id} name={value.name}/>
      }) : null}
    </MaterialsContainer>
  </AccountMaterialRoot>
}
