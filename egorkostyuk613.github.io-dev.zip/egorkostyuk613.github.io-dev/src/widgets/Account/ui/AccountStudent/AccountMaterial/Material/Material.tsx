import {MaterialButton, MaterialContainer, MaterialImg} from "./Material.styled";
import {Box} from "@mui/system";
import { ReactComponent as Arrow } from './arrow.svg'
import {Link} from "react-router-dom";

export const Material = (props: any) => {
  return <MaterialContainer>
    <MaterialImg />
    <Box >
      {props.name}
      <Box sx={{
        display: 'flex',
        justifyContent: 'flex-end',
        alignItems: 'flex-end',
        height: '80%',
        textDecoration: 'none',
      }}>
        <Link to={`/account/teacher/materials/${props.id}`}>
          <MaterialButton>Перейти <Arrow /> </MaterialButton>
        </Link>
      </Box>
    </Box>
  </MaterialContainer>
}
