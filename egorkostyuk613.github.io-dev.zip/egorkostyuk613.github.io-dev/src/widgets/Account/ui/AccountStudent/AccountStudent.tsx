import {Link, Outlet, useLocation} from "react-router-dom";

import {AccountStudentContainer, AccountStydentRoot} from "./AccountStudent.styled";
import {AccountContainer, AccountMenu, AccountMenuText} from "../Account.styled";


export const AccountStudent = () => {
  const location: any = useLocation();

  return <AccountStydentRoot>
    <AccountContainer>
      <AccountMenu>
          <Link to="/account/schedule">
            <AccountMenuText $background={location.pathname === '/account/schedule'}>Расписание</AccountMenuText>
          </Link>
          <AccountMenuText $background={location.pathname.startsWith('/account/homeWork')}>Домашние задания</AccountMenuText>
        <Link to="/account/courses">
            <AccountMenuText $background={location.pathname === '/account/courses'}>Тарифы</AccountMenuText>
          </Link>
          <Link to="/account/materials">
            <AccountMenuText $background={location.pathname === '/account/materials'}>Учебные материалы</AccountMenuText>
          </Link>
            <AccountMenuText $background={location.pathname === '/account/cards'}>Карточки</AccountMenuText>
          <Link to="/account/settings">
            <AccountMenuText $background={location.pathname === '/account/settings'}>Настройки</AccountMenuText>
          </Link>
        <Link to="/account/contactUs">
          <AccountMenuText $background={location.pathname === '/account/contactUs'}>Cвяжитесь с нами</AccountMenuText>
        </Link>
      </AccountMenu>
      <AccountStudentContainer>
        <Outlet />
      </AccountStudentContainer>
    </AccountContainer>
  </AccountStydentRoot>
}
