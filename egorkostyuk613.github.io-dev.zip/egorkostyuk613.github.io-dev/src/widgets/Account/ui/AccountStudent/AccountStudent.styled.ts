import {styled} from "shared/lib";
import {Box} from "@mui/system";

export const AccountStydentRoot = styled(Box)({

})

export const AccountStudentContainer = styled(Box)({})

export const AccountStudentTitle = styled(Box)({
  fontSize: "24px",
  fontWeight: 600,
})
