import {
  BlackButton, HomeWorkButtonsContainer, HomeWorkContent, HomeWorkContentLeft, HomeWorkRow, HomeWorkTable,
  HomeWorkText,
  HomeWorkWrapper,
  SilverButton,
  SoloHomeWork
} from "./HomeWork.styled";
import { AccountHwTitle } from "../AccountHomeWork.styled";
import { Box } from "@mui/system";
import { Link, useParams } from "react-router-dom";
import { useGetHomeWork } from "../../../AccountTeacher/AccountTeacherAddHomeWork/hooks/useGetHomeWork";
import axios from "axios";
import {format} from "date-fns";
import {BACK_URL} from "../../../../../../shared/back/backURL";

export const HomeWork = () => {
  const { homeWorkId } = useParams();

  // @ts-ignore
  const { lesson } = useGetHomeWork(homeWorkId);

  console.log(lesson)

  const getHomeWorkPDF = async () => {
    try {
      const res = await axios.get(BACK_URL + `api/lesson/homework/${lesson._id}`, {
        withCredentials: true,
      });

      let base64Data = res.data.file;

      if (typeof base64Data !== 'string') {
        console.error('Ожидалась строка Base64, но пришли:', base64Data);
        return;
      }

      if (base64Data.startsWith('data:application/pdf;base64,')) {
        base64Data = base64Data.split('base64,')[1];
      }

      const byteCharacters = atob(base64Data);
      const byteArrays = [];

      for (let offset = 0; offset < byteCharacters.length; offset += 1024) {
        const slice = byteCharacters.slice(offset, offset + 1024);
        const byteNumbers = new Array(slice.length);
        for (let i = 0; i < slice.length; i++) {
          byteNumbers[i] = slice.charCodeAt(i);
        }
        byteArrays.push(new Uint8Array(byteNumbers));
      }

      const blob = new Blob(byteArrays, { type: 'application/pdf' });

      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);

      const contentDisposition = res.headers['content-disposition'];
      const fileName = contentDisposition
        ? contentDisposition.split('filename=')[1]?.replace(/"/g, '') || 'homework.pdf'
        : 'homework.pdf';

      link.download = fileName;
      link.click();

      URL.revokeObjectURL(link.href);
    } catch (error) {
      console.error('Ошибка при загрузке файла:', error);
    }
  };

  const renderFunc = (status: number) => {
    switch (status) {
      case 0:
        return "Домашнее Задание не предоставлено учителем"
      case 1:
        return "Нет оценки"
      case 2:
        return "Домашнее здание проверено"
      case 3:
        return "Домашнее задание не было предоставлено вовремя"
      case 4:
        return "Больше попыток нет"
    }
  }

  const lessonTime = lesson?.time ? new Date(lesson.time) : null;
  // @ts-ignore
  const isWithinTimeLimit = lessonTime ? new Date() <= lessonTime.getTime() + 60 * 60 * 1000 : false;
  

  return (
    <HomeWorkWrapper>
      <AccountHwTitle>Домашнeе заданиe</AccountHwTitle>
      {lesson && lesson?.homework && <SoloHomeWork>
        <HomeWorkText>Домашняя работа</HomeWorkText>
        <Box display="flex">
          <SilverButton onClick={getHomeWorkPDF}>Скачать</SilverButton>
        </Box>
      </SoloHomeWork>}

      <HomeWorkButtonsContainer>
        <Link to={`/account/homeWork/${homeWorkId}/${lesson?._id}`}>
          <BlackButton>Добавить ответ на задание</BlackButton>
        </Link>
        {isWithinTimeLimit && <a href={lesson?.link} target="_blank">
          <BlackButton>Перейти на урок</BlackButton>
        </a>}

      </HomeWorkButtonsContainer>
      {isWithinTimeLimit && <Box mt={12 / 8}>
        <HomeWorkText>Начало урока запланировано {new Date(lesson?.time).toISOString().replace("T", " ").slice(0, 16)} UTC+0</HomeWorkText>
      </Box>}


      <AccountHwTitle>Состояние ответа</AccountHwTitle>
      <HomeWorkTable>
        <HomeWorkRow>
          <HomeWorkContentLeft>Номер попытки</HomeWorkContentLeft>
          <HomeWorkContent>{lesson?.answerNumber ? "Попытка " + lesson?.answerNumber : "Попытка 0"}</HomeWorkContent>
        </HomeWorkRow>
        <HomeWorkRow>
          <HomeWorkContentLeft>Состояние ответа на задание</HomeWorkContentLeft>
          <HomeWorkContent>{lesson?.status && renderFunc(lesson.status)}</HomeWorkContent>
        </HomeWorkRow>
        <HomeWorkRow>
          <HomeWorkContentLeft>Состояние оценивания</HomeWorkContentLeft>
          {lesson?.rating ? <HomeWorkContent>{lesson.rating}</HomeWorkContent> : <HomeWorkContent>Не оценено</HomeWorkContent>}

        </HomeWorkRow>
        <HomeWorkRow>
          <HomeWorkContentLeft>Дата сдачи Д/З</HomeWorkContentLeft>
          <HomeWorkContent>{lesson?.deadLine ? format(lesson.deadLine, 'dd.MM.yyyy HH:mm') : "Нет дедлайна" }</HomeWorkContent>
        </HomeWorkRow>
      </HomeWorkTable>
    </HomeWorkWrapper>
  );
};
