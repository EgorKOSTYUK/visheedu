import {styled} from "shared/lib";
import {Box} from "@mui/system";

export const AccountHomeWorkRoot = styled(Box)({

})

export const AccountHwTitle = styled(Box)({
  fontSize: "24px",
  fontWeight: 600,
  marginTop: 30,
  marginBottom: 30,
})

export const AccountDialogContainer = styled(Box)({
  textAlign: 'center',
  position: 'relative',
})

export const CloseDialog = styled(Box)({
  color: 'black',
  position: 'absolute',
  right: -50,
  top: -50,
  zIndex: 99,
  cursor: 'pointer',
})

export const AccountDialogaTitle = styled(Box)({
  fontSize: "24px",
  fontWeight: 600,
  marginBottom: 30,
  color: 'black'
})

export const AccountDialogButton = styled(Box)({
  border: "2px solid black",
  color: 'black',
  fontSize: 18,
  lineHeight: "43px",
  textAligtn: 'center',
  display: 'flex',
  justifyContent: 'center',
  borderRadius: 10,
  cursor: 'pointer'
})

export const AccountStarContainer = styled(Box)({
  display: 'grid',
  gridTemplateColumns: '1fr 1fr 1fr 1fr 1fr',
  marginBottom: '20px'
})

interface SelectProps {
  $select: boolean
}

export const AccountStar = styled(Box)<SelectProps>(({$select}) => ({
  background: '#FFFFFF',
  height: 30,
  width: 30,
  color: 'black',
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  borderRadius: 8,
  cursor: 'pointer',
  border: $select ? '2px solid #00000069' : 'none'
}))
