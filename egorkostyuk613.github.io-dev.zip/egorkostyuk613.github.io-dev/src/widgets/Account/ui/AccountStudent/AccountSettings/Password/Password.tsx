import {ForgotPassword, PasswordContainer, SettingsPurpleButton} from "./Password.styled";
import {Stack} from "@mui/system";
import {SettingsInput} from "../SettingsInput";
import {useState} from "react";
import axios from "axios";
import {BACK_URL} from "../../../../../../shared/back/backURL";
import {authModel} from "../../../../../../entities/auth/model/Auth.model";

export const Password = () => {
  const [nowpassword, setNowPassword] = useState<string>("");
  const [send, setSend] = useState<boolean>(false);
  const [code, setCode] = useState<string>("");
  const [newPassword, setNewPassword] = useState<string>("");
  const [newPasswordSec, setNewPasswordSec] = useState<string>("");

  const RequestPasswordRecovery = async () => {
    try{
      await axios.post(BACK_URL + 'api/user/requestPasswordRecovery', {
        email: authModel.user.email,
      })
      setSend(true)
    }catch (e){
      console.log(e)
    }

  }

  const ResetPassword = async () => {
    try{
      await axios.post(BACK_URL + 'api/user/resetPassword', {
        email: authModel.user.email,
        newPassword: newPassword,
        code: code
      })
      setSend(false)
    }catch (e){
      console.log(e)
    }

  }


  return <PasswordContainer>
    <Stack spacing={10 / 8}>
      <SettingsInput name="Текущий пароль" onChange={(e: any) => setNowPassword(e.target.value)} value={nowpassword} type="password"/>
      <ForgotPassword onClick={RequestPasswordRecovery}>Отправить код</ForgotPassword>
      {send && <SettingsInput name="Код подтверждение" onChange={(e: any) => setCode(e.target.value)} value={code} type="text"/>}
      <SettingsInput name="Новый пароль" onChange={(e: any) => setNewPassword(e.target.value)} value={newPassword} type="password"/>
      <SettingsInput name="Подтвердить пароль" onChange={(e: any) => setNewPasswordSec(e.target.value)} value={newPasswordSec} type="password"/>
      <SettingsPurpleButton onClick={ResetPassword}>Сохранить изменения</SettingsPurpleButton>
    </Stack>
  </PasswordContainer>
}
