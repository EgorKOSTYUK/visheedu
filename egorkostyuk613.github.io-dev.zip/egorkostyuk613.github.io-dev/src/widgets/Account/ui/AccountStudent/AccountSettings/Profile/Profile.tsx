import {
  ProfileContainer,
  ProfileImage,
  ProfileLogoContainer,
  ProfileMainText,
  SaveButton,
  SettingImage,
  SettingsPurpleButton
} from "./Profile.styled";
import { Stack } from "@mui/system";
import { SettingsInput } from "../SettingsInput";
import { ReactComponent as ProfileLog } from './profileLogo.svg';
import axios from "axios";
import { useState } from "react";
import { BACK_URL } from "../../../../../../shared/back/backURL";
import { authModel } from "../../../../../../entities/auth/model/Auth.model";
import { observer } from "mobx-react";
import {Loading} from "../../../../../Loading/Loading";

export const Profile = observer(() => {
  const [name, setName] = useState('');
  const [surname, setSurName] = useState('');
  const [network, setNetwork] = useState('');
  const [image, setImage] = useState<File | null>(null);
  const [previewSrc, setPreviewSrc] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const updateInfo = async () => {
    const user: any = {};

    if (name !== '') {
      user.name = name;
      return
    }
    if (surname !== '') {
      user.surname = surname;
      return
    }
    if (network !== '') {
      user.network = network;
      return
    }

    try {
      await axios.patch(BACK_URL + 'api/user/profile', user, {
        withCredentials: true
      });
    } catch (e) {
      console.log(e);
    }
  };

  const updatePhoto = async () => {
    setIsLoading(true)
    try {
      if (!image) return;
      await updateInfo()

      const pngImage = await convertToPng(image);

      const formData = new FormData();
      formData.append('picture', pngImage);

      if (!authModel.user.picture) {
        await axios.post(BACK_URL + 'api/user/picture', formData, {
          withCredentials: true,
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        });
        return;
      }

      await axios.delete(BACK_URL + 'api/user/picture', {
        withCredentials: true,
      });

      await axios.post(BACK_URL + 'api/user/picture', formData, {
        withCredentials: true,
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      setIsLoading(false)

    } catch (err) {
      setIsLoading(false)
      console.error('Ошибка при обновлении данных профиля', err);
    }
  };

  const handleImageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files) {
      const file = event.target.files[0];
      setImage(file); // Сохраняем выбранное изображение
      setPreviewSrc(URL.createObjectURL(file));
    }
  };

  const convertToPng = (file: File): Promise<File> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();

      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          canvas.width = img.width;
          canvas.height = img.height;

          const ctx = canvas.getContext('2d');
          if (!ctx) {
            reject(new Error('Не удалось получить контекст canvas'));
            return;
          }

          ctx.drawImage(img, 0, 0);
          canvas.toBlob(
            (blob) => {
              if (blob) {
                const pngFile = new File([blob], 'converted-image.png', {
                  type: 'image/jpeg',
                });
                resolve(pngFile);
              } else {
                reject(new Error('Не удалось создать PNG'));
              }
            },
            'image/png',
            1
          );
        };
        img.src = e.target?.result as string;
      };

      reader.onerror = (e) => reject(e);
      reader.readAsDataURL(file);
    });
  };

  function convertGoogleDriveLink(url: any) {
    const regex = /(?:drive\.google\.com\/file\/d\/)([^\/?]+)/;
    const match = url.match(regex);

    if (match) {
      const fileId = match[1];
      return `https://lh3.google.com/u/0/d/${fileId}`;
    } else {
      return 'Неверная ссылка Google Drive';
    }
  }

  return (
    <ProfileContainer>
      <ProfileMainText>
        <ProfileMainText>Фото профиля</ProfileMainText>
        <ProfileLogoContainer>
          <ProfileImage>
            {previewSrc ? (
              <SettingImage src={previewSrc} alt="Profile" />
            ) : authModel.user.pictureLink ? (
              <SettingImage src={convertGoogleDriveLink(authModel.user.pictureLink)} alt="Profile" />
            ) : (
              <ProfileLog />
            )}
          </ProfileImage>

          <SaveButton>
            <label htmlFor="file-input">Загрузить фото</label>
            <input
              type="file"
              id="file-input"
              style={{ display: 'none' }}
              onChange={handleImageChange}
            />
          </SaveButton>
        </ProfileLogoContainer>

        <Stack spacing={10 / 8} mt={15 / 8}>
          <SettingsInput name="Имя" onChange={(e: any) => setName(e.target.value)} value={name} type="text" />
          <SettingsInput name="Фамилия" onChange={(e: any) => setSurName(e.target.value)} value={surname} type="text" />
          <SettingsInput name="Соц сеть" onChange={(e: any) => setNetwork(e.target.value)} value={network} type="text" />
          <SettingsPurpleButton onClick={updatePhoto}>Сохранить изменения</SettingsPurpleButton>
        </Stack>
      </ProfileMainText>
      {isLoading && <Loading /> }
    </ProfileContainer>
  );
});
