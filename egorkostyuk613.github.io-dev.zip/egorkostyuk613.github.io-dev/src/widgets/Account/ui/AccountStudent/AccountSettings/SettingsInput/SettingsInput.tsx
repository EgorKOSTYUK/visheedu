import {HeadInputText, SettingsInputContainer, SettingsInputMain} from "./SettingsInput.styled";

export const SettingsInput = ({name, onChange, type, value}: {name: string, onChange: any, type: string, value: string}) => {
  return <SettingsInputContainer>
    <HeadInputText>{name}</HeadInputText>
    <SettingsInputMain placeholder={name} onChange={onChange} name={name} type={type} value={value}/>
  </SettingsInputContainer>
}
