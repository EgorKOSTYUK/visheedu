import {EmailContainer, SettingsPurpleButton} from "./Email.styled";
import {SettingsInput} from "../SettingsInput";
import {Stack} from "@mui/system";
import {useState} from "react";

export const Email = () => {
  const [password, setPassword] = useState<string>("");

  return <EmailContainer>
    <Stack spacing={10 / 8}>
    <SettingsInput name="Эл. адрес" onChange={(e: any) => setPassword(e.target.value)} value={password} type="text"/>
    <SettingsPurpleButton>Сохранить изменения</SettingsPurpleButton>
    </Stack>
  </EmailContainer>
}
