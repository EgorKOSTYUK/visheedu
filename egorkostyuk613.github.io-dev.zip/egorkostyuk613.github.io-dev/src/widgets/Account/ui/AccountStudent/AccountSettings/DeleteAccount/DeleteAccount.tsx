import {DeleteContainer, DeleteText, SettingsPurpleButton} from "./DeleteAccount.styled";
import {SettingsInput} from "../SettingsInput";
import {Stack} from "@mui/system";
import {useState} from "react";

export const DeleteAccount = () => {
  const [password, setPassword] = useState<string>("");
  return <DeleteContainer>
    <Stack spacing={10 / 8}>
      <DeleteText>Удаление аккаунта является необратимым, и вся связанная с ним информация также будет удалена. Если вы уверены, что хотите продолжить, введите свой адрес электронной почты ниже.</DeleteText>
      <SettingsInput name="Текущий пароль" onChange={(e: any) => setPassword(e.target.value)} value={password} type="password" />
      <SettingsPurpleButton>Сохранить изменения</SettingsPurpleButton>
    </Stack>
  </DeleteContainer>
}
