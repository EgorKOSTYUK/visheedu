export enum AccountSettingsTab {
  profile,
  password,
  email,
  delete
}
