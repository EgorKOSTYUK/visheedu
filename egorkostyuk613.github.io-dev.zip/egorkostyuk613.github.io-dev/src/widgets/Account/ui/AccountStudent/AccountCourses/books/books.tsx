import {
  RegisterSelectBooksTarifs,
  RegisterSelectBooksTarifsHeadText,
  RegisterSelectBooksTarifsSmallText, RegisterSelectBooksTarifsSPriceText
} from "./books.styled";
import {Box} from "@mui/system";
import {Button} from "../../../../../../shared/ui";
import {AccountStudentModel} from "../../model/AccountStudent.model";
import {Dialog} from "../../../../../../shared/ui/Dialog/Dialog";
import {
  DialogButtonsContainer,
  DialogContainer, DialogText,
  DialogTitleErrorText,
  DialogTitleText
} from "../Tarif/TarifRegister.styled";
import {useState} from "react";
import axios from "axios";
import {BACK_URL} from "../../../../../../shared/back/backURL";
import {registerModel} from "../../../../../Register/model/Register.model";
import {RegisterType} from "../../../../../Register/Register.types";

export const Book = (props: any) => {
  const [open, setOpen] = useState(false)
  const [areYouSure, setAreYouSure] = useState(false)
  const [ErrorDialog, setErrorDialog] = useState(false)

  const checkPayment = async () => {
    try{
      await axios.post(BACK_URL + `api/public/payment/tPay/${AccountStudentModel.books?.products[0]._id}`,{}, {
        withCredentials: true
      })
      registerModel.setPage(RegisterType.tarif)
    }
    catch(e){
      setErrorDialog(true)
      console.log(e)
    }
  }

  return <RegisterSelectBooksTarifs>
    {+props.amount / 1000 / 60 / 60 / 24 < 15 && <RegisterSelectBooksTarifsHeadText>Пробный период</RegisterSelectBooksTarifsHeadText>}

    <RegisterSelectBooksTarifsSmallText>{+props.amount / 1000 / 60 / 60 / 24 } дней</RegisterSelectBooksTarifsSmallText>
    <Box mt={24 / 8}>
      <RegisterSelectBooksTarifsSPriceText>{props.price / 100}</RegisterSelectBooksTarifsSPriceText>
      <Box display="flex" justifyContent="center" mt={1}>
        <Button onClick={() => {
          setAreYouSure(true)
        }}>Записаться</Button>
      </Box>
    </Box>
    <Dialog open={open} onClose={() => console.log('не-а закрыть нельзя=)')}>
      <DialogContainer>
        <DialogTitleText>Пожалуйста не закрывайте вкладку до окончания оплаты</DialogTitleText>
        <DialogTitleText>После оплаты нажмите кнопку "Продолжить"</DialogTitleText>
        <DialogButtonsContainer>
          <Button onClick={() => {
            checkPayment()
            setOpen(false)
          }}>Продолжить</Button>
        </DialogButtonsContainer>
      </DialogContainer>
    </Dialog>
    <Dialog open={areYouSure} onClose={() => setAreYouSure(false)}>
      <DialogContainer>
        <DialogTitleText>Вы уверены что хотите это купить?</DialogTitleText>
        <DialogButtonsContainer>
          <Button onClick={() => {
            props.StudentInitSubscribe(props.idx, AccountStudentModel.books?.products[0]._id)
            setAreYouSure(false)
            setOpen(true)
          }}>Да</Button>
          <Button onClick={() => {
            setAreYouSure(false)
          }}>нет</Button>
        </DialogButtonsContainer>
      </DialogContainer>
    </Dialog>
    {/*Error Dialog*/}
    <Dialog open={ErrorDialog} onClose={() => setErrorDialog(false)}>
      <DialogContainer>
        <DialogTitleErrorText>К сожалению вы не оплатили покупку</DialogTitleErrorText>
        <DialogText>Если вы оплатили, то свяжитесь с нами по e-mail visheedu@gmail.com</DialogText>
        <DialogButtonsContainer>
          <Button onClick={() => {
            setErrorDialog(false)
          }}>Продолждить</Button>
        </DialogButtonsContainer>
      </DialogContainer>
    </Dialog>
  </RegisterSelectBooksTarifs>
}
