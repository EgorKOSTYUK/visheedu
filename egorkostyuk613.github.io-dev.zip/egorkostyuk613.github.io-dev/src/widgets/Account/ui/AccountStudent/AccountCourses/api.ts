import axios from "axios";
import {useQuery} from "react-query";
import {BACK_URL} from "../../../../../shared/back/backURL";

export const getCourses = async () => {
  const res = await axios.get(BACK_URL + 'api/course/all', {
    withCredentials: true,
  })

  return res.data
}

// export const getCourseSolo = async (id: string) => {
//   const res = await axios.get('http://localhost:4000/api/course' + id, {
//     withCredentials: true,
//   })
//
//   return res.data
// }

export const getTeachersOfCourse = async (id: string) => {
  const res = await axios.get(BACK_URL + 'api/public/schedule/teachers?courseId=' + id, {
    withCredentials: true,
  })

  return res.data
}

export const getTeacher = async (id: string) => {
  const res = await axios.get(BACK_URL + 'api/public/schedule/teacher/' + id, {
    withCredentials: true,
  })

  return res.data
}

export const getCoursesSolo = async () => {
  const res = await axios.get(BACK_URL + 'api/public/payment/products?category=studyBook', {
    withCredentials: true,
  })

  return res.data
}

export const getTeacherSubscribe = async () => {
  const res = await axios.get(BACK_URL + 'api/public/payment/products?category=studyBookTeacher', {
    withCredentials: true,
  })

  return res.data
}

export const getTeachers = async () => {
  const res = await axios.get(BACK_URL + 'api/public/schedule/teachers', {
    withCredentials: true,
  })

  return res.data
}

export const getTarif = async () => {
  const res = await axios.get( BACK_URL + 'api/public/payment/products?category=course_lesson', {
    withCredentials: true,
  })

  return res.data
}

export const getMaterial = async () => {
  const res = await axios.get(BACK_URL + 'api/public/payment/products?category=studyBook', {
    withCredentials: true,
  })

  return res.data
}

export const getTarifsStudent = async () => {
  const res = await axios.get(BACK_URL + 'api/public/payment/products?category=course_lesson', {
    withCredentials: true,
  })

  return res.data
}

export const getMaterialSolo = async () => {
  const res = await axios.get(BACK_URL + 'api/course/studyBooks', {
    withCredentials: true,
  })

  return res.data
}

export const getBookSolo = async (id: string) => {
  const res = await axios.get(BACK_URL + 'api/course/studyBook/' + id, {
    withCredentials: true,
  })

  return res.data
}

export const getStudents = async () => {
  const res = await axios.get(BACK_URL + 'api/extra/user/partners', {
    withCredentials: true,
  })

  return res.data
}

export const getStudentInfo = async (id: string) => {
  const res = await axios.get(BACK_URL + 'api/extra/user/lessons?id=' + id, {
    withCredentials: true,
  })

  return res.data
}

export const getLessonsForTeacher = async () => {
  const res = await axios.get(BACK_URL + 'api/extra/user/lessons', {
    withCredentials: true,
  })

  return res.data
}

export const getSoloLesson = async (id: string) => {
  const res = await axios.get(BACK_URL + 'api/lesson/' + id, {
    withCredentials: true,
  })

  return res.data
}

export const getStudentLessons = async (id: string) => {
  const res = await axios.get(BACK_URL + 'api/extra/user/lessons?id=' + id, {
    withCredentials: true,
  })

  return res.data
}

export const getCourse = async () => {
  const res = await axios.get(BACK_URL + 'api/course/viewCourses?title=Разговорный китайский', {
    withCredentials: true,
  })
}

export const useCoursaes = () =>  {
  const { data } = useQuery({
    queryKey: "courses",
    queryFn: () => getCourses(),
    onError: (error) => {
      console.log('An error occurred', error);
    },
    retry: false
  })

  return {
    courses: data
  }
}

