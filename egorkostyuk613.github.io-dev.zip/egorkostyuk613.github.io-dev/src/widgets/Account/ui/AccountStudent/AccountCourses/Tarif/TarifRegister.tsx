import {
  DialogButtonsContainer,
  DialogContainer, DialogText, DialogTitleErrorText,
  DialogTitleText,
  TarifRoot,
  TarifTitle,
  VioletText
} from "./TarifRegister.styled";
import {Button} from "shared/ui";

import {observer} from "mobx-react";
import {Dialog} from "../../../../../../shared/ui/Dialog/Dialog";
import {useState} from "react";
import axios from "axios";
import {BACK_URL} from "../../../../../../shared/back/backURL";
import {registerModel} from "../../../../../Register/model/Register.model";
import {RegisterType} from "../../../../../Register/Register.types";

type TarifProps = {
  name: string,
  price: string,
  idx: number,
  id: string,
  StudentInitSubscribe: (idx: number, id: string) => void
}

export const TarifRegister = observer(({ name, price, idx, id, StudentInitSubscribe }:TarifProps) => {
  const [open, setOpen] = useState(false)
  const [areYouSure, setAreYouSure] = useState(false)
  const [ErrorDialog, setErrorDialog] = useState(false)

  const checkPayment = async () => {
    try{
      await axios.post(BACK_URL + `api/public/payment/tPay/${id}`,{}, {
        withCredentials: true
      })
      registerModel.setPage(RegisterType.tarif)
    }
    catch(e){
      setErrorDialog(true)
      console.log(e)
    }
  }

  return <TarifRoot>
    <TarifTitle>{name}</TarifTitle>
      <VioletText>{price} ₽</VioletText>
      <Button margin="auto" onClick={() => {
        setAreYouSure(true)
      }}>Записаться</Button>
    <Dialog open={open} onClose={() => console.log('не-а закрыть нельзя=)')}>
      <DialogContainer>
        <DialogTitleText>Пожалуйста не закрывайте вкладку до окончания оплаты</DialogTitleText>
        <DialogTitleText>После оплаты нажмите кнопку "Продолжить"</DialogTitleText>
        <DialogButtonsContainer>
            <Button onClick={() => {
              checkPayment()
              setOpen(false)
            }}>Продолжить</Button>
        </DialogButtonsContainer>
      </DialogContainer>
    </Dialog>
    <Dialog open={areYouSure} onClose={() => setAreYouSure(false)}>
      <DialogContainer>
        <DialogTitleText>Вы уверены что хотите это купить?</DialogTitleText>
        <DialogButtonsContainer>
          <Button onClick={() => {
            StudentInitSubscribe(idx, id)
            setAreYouSure(false)
            setOpen(true)
          }}>Да</Button>
          <Button onClick={() => {
            setAreYouSure(false)
          }}>нет</Button>
        </DialogButtonsContainer>
      </DialogContainer>
    </Dialog>
    {/*Error Dialog*/}
    <Dialog open={ErrorDialog} onClose={() => setErrorDialog(false)}>
      <DialogContainer>
        <DialogTitleErrorText>К сожалению вы не оплатили покупку</DialogTitleErrorText>
        <DialogText>Если вы оплатили, то свяжитесь с нами по e-mail visheedu@gmail.com</DialogText>
        <DialogButtonsContainer>
          <Button onClick={() => {
            setErrorDialog(false)
          }}>Продолждить</Button>
        </DialogButtonsContainer>
      </DialogContainer>
    </Dialog>
  </TarifRoot>
})
