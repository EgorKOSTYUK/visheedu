import {CourseContainer, CoursePurpleButton, HeadText, ImageContainer, MainText} from "./Course.styled";
import back from './6.png'
import {Box, Stack} from "@mui/system";
import axios from "axios";
import {BACK_URL} from "../../../../../../shared/back/backURL";

export const Course = (props: any) => {

  const initPay = async () => {
    await axios.post(BACK_URL + `course/initPay/${props.id}`, {
      mode: false,  //user choose sub or bundle(only category 1 and lAmount)
      index: 2, //index in array of time or lesson amount
      category: 0 // 0 - study books, 1 - timeslot
    },{
      withCredentials: true
    })
  }

  return <CourseContainer>
    <ImageContainer src={back} />
    <Stack spacing={10 / 8} mt={14 / 8}>
      <HeadText>Мир Знаний</HeadText>
      <MainText>Курсы для школьников, охватывающие основные школьные предметы, подготовку к экзаменам и развитие дополнительных навыков.</MainText>
      <Box>
        <CoursePurpleButton onClick={initPay}>Выбрать</CoursePurpleButton>
      </Box>
    </Stack>
  </CourseContainer>
}
