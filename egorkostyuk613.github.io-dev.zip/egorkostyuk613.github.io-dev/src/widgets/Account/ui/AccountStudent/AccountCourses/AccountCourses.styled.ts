import {styled} from "shared/lib";
import {Box} from "@mui/system";

export const AccountCoursesRoot = styled(Box)({
})

export const AccountCoursesHeadText = styled(Box)({
  fontSize: "24px",
  fontWeight: 600,
  marginBottom: 15,
})

export const AccountCoursesTarriffTitle = styled('p')(({theme}) => ({
  fontSize: "22px",
  lineHeight: "30px",
  color: theme.palette.dark.main,
  fontWeight: 600,
  textAlign: 'center',
  marginTop: 35,
}))

export const AccountCoursesTabsContainer = styled(Box)({
  display: 'grid',
  gridTemplateColumns: '155px 130px',
  margin: '20px 0px',
  gap: 15
})

interface TabProp {
  $background: boolean
}

export const AccountCoursesTab = styled(Box)<TabProp>(({$background}) => ({
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  background: $background ? 'rgba(117, 110, 222, 1)' : 'rgba(255, 255, 255, 1)',
  color: $background ? 'white' : 'black',
  fontSize: 16,
  lineHeight: '35px',
  fontWeight: 400,
  borderRadius: 20,
  padding: '8px 32px',
  cursor: 'pointer',
}))
