import {styled} from "../../../../../../shared/lib";
import {Box, Stack} from "@mui/system";

export const RegisterSoloEducatedContaioner = styled(Box)({
  display: 'grid',
  gridTemplateColumns: '1fr 1fr 1fr 1fr',
  gap: 12,
  marginTop: 45,
})

export const RegisterSelectBooksTarifs = styled(Stack)({
  background: 'white',
  borderRadius: 32,
  padding: 40,
  textAlign: 'center',
  justifyContent: 'center',
})

export const RegisterSelectBooksTarifsHeadText = styled('p')({
  fontSize: 25,
  fontWeight: 600,
  lineHeight: "30px",
})

export const RegisterSelectBooksTarifsSmallText = styled('p')({
  fontSize: 25,
  fontWeight: 400,
  lineHeight: "26px",
})

export const RegisterSelectBooksTarifsSPriceText = styled('p')({
  fontSize: 27,
  fontWeight: 500,
  lineHeight: "30px",
  color: "rgba(111, 103, 220, 1)",
})
