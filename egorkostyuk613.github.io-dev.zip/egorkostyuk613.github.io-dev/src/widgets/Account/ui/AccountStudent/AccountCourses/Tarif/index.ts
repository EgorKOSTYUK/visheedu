export * from './TarifRegister'
