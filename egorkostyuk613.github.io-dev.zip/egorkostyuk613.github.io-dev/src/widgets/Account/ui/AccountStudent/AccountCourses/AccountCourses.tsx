import {
  AccountCoursesRoot,
  AccountCoursesTab,
  AccountCoursesTabsContainer,
  AccountCoursesTarriffTitle
} from "./AccountCourses.styled";
import axios from "axios";
import {BACK_URL} from "../../../../../shared/back/backURL";
import {TarifRegister} from "./Tarif";
import {TarriffRoot} from "../../../../Register/RegisterTarif/RegisterTarif.styled";
import React, {Fragment, useState} from "react";
import {useGetTarifs} from "./hooks/useGetTarifs";
import {AccountStudentModel} from "../model/AccountStudent.model";
import {registerModel} from "../../../../Register/model/Register.model";
import {useGetBooks} from "./hooks/useGetBooks";
import {
  RegisterSoloEducatedContaioner
} from "../../../../Register/RegisterSoloEducated/RegisterSoloEducated.styled";
import {Book} from "./books/books";
import {observer} from "mobx-react";

export const AccountCourses = observer(() => {
  const [paymentId, setPaymentId] = useState()
  const [tab, setTab] = useState<'Библиотека' | 'Пакеты'>('Библиотека')

  useGetBooks()
  useGetTarifs()

  // const addCourses = async () => {
  //     const res = await axios.post(BACK_URL + 'api/course/add',{
  //       "title": 'Индивидуальные занятия "Бизнес китайский"',
  //       "description": "Повседневные фразы и выражения",
  //       "teachers": [
  //         "676c9954ad9e6aeeb5773e02"
  //       ]
  //     }, {
  //       withCredentials: true,
  //     })
  //
  // }
  //
  // const initSolo = async () => {
  //   await axios.post(`http://localhost:4000/api/course/product`,{
  //     title: 'Индивидуальные занятия "Бизнес китайский"',
  //     description: 'Повседневные фразы и выражения',
  //     category: "course_lesson",
  //     prices: [{
  //       price: 1745000,
  //       amount: 4,
  //       },
  //       {
  //         price: 3420000,
  //         amount: 8,
  //       },
  //       {
  //         price: 6750000,
  //         amount: 12,
  //       }],
  //     // course,
  //     // file,
  //     // teacher
  //   }, {
  //     withCredentials: true
  //   })
  // }

  const StudentInitSubscribe = async (index: number, id: string) => {
    try{
      const res = await axios.post( BACK_URL + `api/public/payment/initPay/${id}`,{
        index: index
      }, {
        withCredentials: true
      })
      registerModel.setCourseIdStudent(id)
      setPaymentId(res.data.PaymentId)
      window.open(res.data.PaymentURL, '_blank')

    }catch(e){
      console.log(e)
    }
  }



  return <AccountCoursesRoot>
    <AccountCoursesTabsContainer>
      <AccountCoursesTab $background={tab === 'Библиотека'} onClick={() => setTab('Библиотека')}>Библиотека</AccountCoursesTab>
      <AccountCoursesTab $background={tab === 'Пакеты'} onClick={() => setTab('Пакеты')}>Пакеты</AccountCoursesTab>
    </AccountCoursesTabsContainer>
    {tab === 'Пакеты' ? AccountStudentModel.tarifs?.products && AccountStudentModel.tarifs.products.map((value: any) => {
      return <Fragment>
        <AccountCoursesTarriffTitle>
          {value.title}
        </AccountCoursesTarriffTitle>

        <TarriffRoot>
          {value.prices.map((tarif: any, idx: any) =>(<TarifRegister name={tarif.amount + ' занятий по 60 минут'} price={tarif.price && tarif.price / 100} idx={idx} id={value._id} StudentInitSubscribe={StudentInitSubscribe} />))}
        </TarriffRoot>
      </Fragment>
    }) : <Fragment>
      <AccountCoursesTarriffTitle>
        Библиотека
      </AccountCoursesTarriffTitle>
      <RegisterSoloEducatedContaioner>
      {AccountStudentModel.books?.products && AccountStudentModel.books.products[0].prices.map((value: any, idx: number) => {
        return <Book amount={value.amount} price={value.price} idx={idx} StudentInitSubscribe={StudentInitSubscribe}/>
      })}
    </RegisterSoloEducatedContaioner>
    </Fragment>}

  </AccountCoursesRoot>
})
