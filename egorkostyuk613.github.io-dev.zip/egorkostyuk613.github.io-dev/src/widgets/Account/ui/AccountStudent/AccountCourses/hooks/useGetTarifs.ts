import { useQuery } from "react-query";
import { getTarifsStudent } from "../../../AccountStudent/AccountCourses/api";
import { AccountStudentModel } from "../../model/AccountStudent.model";

export const useGetTarifs = () => {
  const { tarifs } = AccountStudentModel;

  const { isLoading, isError } = useQuery({
    queryKey: "tarifs-student-tarifs",
    queryFn: getTarifsStudent,
    enabled: !tarifs,
    staleTime: Infinity,
    onError: (error) => {
      console.log("An error occurred", error);
    },
    onSuccess: AccountStudentModel.setTarifs,
  });

  return {
    isLoading,
    isError,
    tarifs, // Возвращаем tarifs из MobX
  };
};
