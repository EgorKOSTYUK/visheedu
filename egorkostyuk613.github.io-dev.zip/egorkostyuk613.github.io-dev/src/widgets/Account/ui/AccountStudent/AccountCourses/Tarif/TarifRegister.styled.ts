import {styled} from "shared/lib";
import {Box} from "@mui/system";

export const TarifRoot = styled(Box)({
  borderRadius: 32,
  padding: "34px 78px",
  textAlign: "center",
  background: 'rgba(255, 255, 255, 1)',
});

export const TarifTitle = styled('p')({
  fontSize: 20,
  lineHeight: "24px",
  fontWeight: 600,
});

export const VioletText = styled('p')({
  color: '#756EDE',
  fontSize: 18,
  lineHeight: "32px",
  marginBottom: 14,
  marginTop: 28,
})

export const DialogTitleText = styled('p')({
  fontSize: 20,
  lineHeight: "24px",
  fontWeight: 600,
  color: 'black',
  marginTop: 8,
})

export const DialogTitleErrorText = styled('p')({
  fontSize: 20,
  lineHeight: "24px",
  fontWeight: 600,
  color: 'red',
  marginTop: 8,
})


export const DialogText = styled('p')({
  fontSize: 20,
  lineHeight: "24px",
  fontWeight: 600,
  color: 'black',
  marginTop: 8,
})

export const DialogContainer = styled('p')({
  textAlign: 'center',
})

export const DialogButtonsContainer = styled('p')({
  display: 'flex',
  justifyContent: 'center',
  marginTop: 15,
})
