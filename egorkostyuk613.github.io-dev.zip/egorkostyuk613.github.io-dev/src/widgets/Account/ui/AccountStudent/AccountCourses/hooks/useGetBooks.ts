import { useQuery } from "react-query";
import {getMaterial} from "../../../AccountStudent/AccountCourses/api";
import { AccountStudentModel } from "../../model/AccountStudent.model";

export const useGetBooks = () => {
  const { books } = AccountStudentModel;

  const { isLoading, isError } = useQuery({
    queryKey: "tarifs-student-books",
    queryFn: getMaterial,
    enabled: !books,
    staleTime: Infinity,
    onError: (error) => {
      console.log("An error occurred", error);
    },
    onSuccess: AccountStudentModel.setBooks,
  });

  return {
    isLoading,
    isError,
    books, // Возвращаем tarifs из MobX
  };
};
