import {action, observable} from "mobx";

class AccountStudent {
  @observable accessor tarifs: any = null;
  @observable accessor books: any = null;


  @action.bound setTarifs(prop: any){
    this.tarifs = prop
  }

  @action.bound setBooks(prop: any){
    this.books = prop
  }

}

export const AccountStudentModel = new AccountStudent();
