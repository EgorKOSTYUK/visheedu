import {styled} from "shared/lib";
import {Box} from "@mui/system";

export const AccountScheduleRoot = styled(Box)({

})

export const AccountLessonsLine = styled(Box)({
  padding: 25,
  background: 'rgba(242, 242, 242, 1)',
  width: '100%',
  borderRadius: 8,
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  marginTop: "16px",
  ['a']: {
    textDecoration: 'none',
  }
})

export const AccountLessonsTime = styled('p')({
  fontSize: 16,
  color: 'rgba(102, 102, 102, 0.8)',
  lineHeight: '26px',
  fontWeight: 500,
})

export const AccountLessonsName = styled('p')({
  fontSize: 18,
  color: 'rgba(0, 0, 0, 1)',
  lineHeight: '26px',
  fontWeight: 500,
})

export const AccountLessonsButton = styled(Box)({
  background: 'rgba(117, 110, 222, 1)',
  color: 'white',
  padding: '12px 32px',
  borderRadius: 50,
  fontSize: 12,
  fontWeight: 500,
  lineHeight: '16px',
  cursor: 'pointer',
})

