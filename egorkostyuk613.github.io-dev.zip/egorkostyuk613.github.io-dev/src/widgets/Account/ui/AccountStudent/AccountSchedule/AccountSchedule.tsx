import {
  AccountLessonsButton,
  AccountLessonsLine,
  AccountLessonsName,
  AccountLessonsTime,
  AccountScheduleRoot
} from "./AccountSchedule.styled";
import {AccountStudentTitle} from "../AccountStudent.styled";
import {useGetLessons} from "../../AccountTeacher/AccountSchedule/hooks/useGetLessons";
import {Link} from "react-router-dom";
import {format} from "date-fns";
import {accountTeacherModel} from "../../AccountTeacher/model/AccountTeacher.model";

export const AccountSchedule = () => {
  useGetLessons()

  return <AccountScheduleRoot>
    <AccountStudentTitle>Расписание</AccountStudentTitle>

    {accountTeacherModel?.lessons ? accountTeacherModel?.lessons.map((value: any) => {
      return <AccountLessonsLine>
        <AccountLessonsTime>{format(value.deadLine, 'dd.MM.yyyy HH:mm')}</AccountLessonsTime>
        <AccountLessonsName>{value.course.title}</AccountLessonsName>
        <Link to={`/account/homeWork/${value._id}`}>
          <AccountLessonsButton>Перейти</AccountLessonsButton>
        </Link>
      </AccountLessonsLine>
    }) : null}

  </AccountScheduleRoot>
}
