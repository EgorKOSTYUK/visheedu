export interface AccountTypes{
  fullName: string;
  role: 'teacher' | 'user';
}
