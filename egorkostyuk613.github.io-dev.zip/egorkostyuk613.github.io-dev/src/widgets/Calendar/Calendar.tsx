import {
  CalendarArrowBlock, CalendarArrowRightBlock, CalendarDay,
  CalendarDays,
  CalendarRoot,
  CalendarSelectWeeks, CalendarSwitcherBlock,
  CalendarSwitchWeek, CalendarText, CalendarTime, CalendarTimes, CalendarTimeText,
  CalendarUpContainer, DayText, UTCText
} from "./Calendar.styled";
import { format } from 'date-fns';
import {useWeeklyCalendar} from "./config";
import axios from "axios";
import React, {useState} from "react";
import {Button} from "../../shared/ui";
import {observer} from "mobx-react";
import {registerModel} from "../Register/model/Register.model";
import {RegisterType} from "../Register/Register.types";
import {InfoTeacherHeadText} from "../Register/InfoTeacher/InfoTeacher.styled";
import {BACK_URL} from "../../shared/back/backURL";
import {RegisterButtonsContainer} from "../Register/Register.styled";

export const Calendar = observer(() => {
  // @ts-ignore
  // const { time } = useGetTimeTeacher(registerModel.registerTeacherId);
  // console.log(time)
  const {weekDaysWithTimes, goToPreviousWeek, goToNextWeek, weekRange} = useWeeklyCalendar()
  // const [selectTeacherTime, setSelectTeacherTime] = useState()
  const [timeWeek, setTime] = useState<any>({
    0: [],
    1: [],
    2: [],
    3: [],
    4: [],
    5: [],
    6: [],
  })

  const selectTime = async () => {
    try{
      await axios.post(BACK_URL + 'api/extra/user/schedule', {
        hours: {
          Mon: timeWeek[0].sort((a: any, b: any) => a.timeslot - b.timeslot),
          Tue: timeWeek[1].sort((a: any, b: any) => a.timeslot - b.timeslot),
          Wed: timeWeek[2].sort((a: any, b: any) => a.timeslot - b.timeslot),
          Thu: timeWeek[3].sort((a: any, b: any) => a.timeslot - b.timeslot),
          Fri: timeWeek[4].sort((a: any, b: any) => a.timeslot - b.timeslot),
          Sat: timeWeek[5].sort((a: any, b: any) => a.timeslot - b.timeslot),
          Sun: timeWeek[6].sort((a: any, b: any) => a.timeslot - b.timeslot),
        }
      }, {
        withCredentials: true
      })
      registerModel.setPage(RegisterType.thanks)
    }
    catch(e){
      console.log(e)
    }
  }
  //
  // const selectTimeStudent = async () => {
  //   await axios.post('http://localhost:4000/api/course/reserveHour/' + registerModel.courseId, {
  //     teacherId: registerModel.registerTeacherId,
  //     timeslot: 2,
  //     day: "Mon",
  //     time: selectTeacherTime,
  //   } , {
  //     withCredentials: true
  //   })
  // }

  return <CalendarRoot>
    <InfoTeacherHeadText>Выбор расписания</InfoTeacherHeadText>
    <UTCText>Выбор времени в UTC+0</UTCText>
    <CalendarUpContainer>
      <CalendarSelectWeeks>
        <CalendarSwitcherBlock>
          <CalendarSwitchWeek>
            <CalendarArrowBlock onClick={goToPreviousWeek}>
              {"<"}
            </CalendarArrowBlock>
            <CalendarArrowRightBlock onClick={goToNextWeek}>
              {">"}
            </CalendarArrowRightBlock>
          </CalendarSwitchWeek>
          <CalendarText>{weekRange.start + " - " + weekRange.end}</CalendarText>
        </CalendarSwitcherBlock>
      </CalendarSelectWeeks>
      <CalendarDays>
        {weekDaysWithTimes.map(value => {
          return <CalendarDay>
            <DayText>{value.shortDay}</DayText>
            <DayText>{value.dayNumber}</DayText>
          </CalendarDay>
        })}
      </CalendarDays>
      <CalendarTimes>
        {weekDaysWithTimes.map((value, index) => (
          <CalendarTime key={index}>
            {value.times.map((time, idx) => {
              const isSelected = timeWeek[index].some((item: any) => item.timeslot === idx);

              return (
                <CalendarTimeText
                  key={idx}
                  $select={isSelected}
                  onClick={() => {
                    setTime({
                      ...timeWeek,
                      [index]: isSelected
                        ? timeWeek[index].filter((item: any) => item.timeslot !== idx) // Удалить элемент
                        : [...timeWeek[index], { timeslot: idx }], // Добавить элемент
                    });
                  }}
                >
                  {format(time, 'HH:mm')}
                </CalendarTimeText>
              );
            })}
          </CalendarTime>
        ))}
      </CalendarTimes>
    </CalendarUpContainer>
    <RegisterButtonsContainer>
      <Button variant="outlinedv4" onClick={() => registerModel.setPage(RegisterType.TeacherSubscribe)}>Назад</Button>
      <Button variant="outlinedv4" type="submit" ml={18 / 8} onClick={selectTime}>Запись</Button>
    </RegisterButtonsContainer>
  </CalendarRoot>
})
