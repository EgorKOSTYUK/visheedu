import {
  BoxesWrapper,
  BTContainer,
  LineContainer,
  LineText,
  LineTextUnderline,
  LineWrapper,
  SelectBooksTarifs,
  SelectBooksTarifsHeadText,
  SelectBooksTarifsSmallText,
  SelectBooksTarifsSPriceText,
  TarriffBig,
  TarriffContainer,
  TarriffRoot,
  TarriffTitle,
  TarriffWrapper,
  VioletteButton,
  VioletText
} from "./Tariffs.styled";
import {Tarif} from "./Tarif";
import {Fragment} from "react";
import {Box} from "@mui/system";
import {Button} from "../../shared/ui";

const tarrifsArr = [
  {
    name: 'Индивидуальные занятия "Разговорный китайский"',
    list: [{
      name: '4 занятия по 60 мин',
      price: 'от 13 600₽ до 14 350₽'
    },
      {
        name: '8 занятий по 60 мин',
        price: 'от 26 600₽ до 28 150₽'
      },
      {
        name: '12 занятий по 60 мин',
        price: 'от 39 000₽ до 41 300₽'
      },
    ],
  },
  {
    name: 'Индвидуальные занятия "Подготовка к экзамену"',
    list: [{
      name: '4 занятия по 60 мин',
      price: 'от 14 350₽ до 15 150₽'
    },
      {
        name: '8 занятий по 60 мин',
        price: 'от 28 150₽ до 29 650₽'
      },
      {
        name: '12 занятий по 60 мин',
        price: 'от 41 300₽ до 43 550₽'
      },
    ],
  },
  {
    name: 'Индивидуальные занятия "Разговорный китайский"',
    list: [{
      name: '4 занятия по 60 мин',
      price: '17 450₽'
    },
      {
        name: '8 занятий по 60 мин',
        price: '34 200₽'
      },
      {
        name: '12 занятий по 60 мин',
        price: '51 200₽'
      },
    ],
  },
]

export const Tariffs = () => {
  return <TarriffContainer>
    <TarriffBig>Тарифы</TarriffBig>
    <BTContainer>Пакеты индивидуальных занятий</BTContainer>
    <TarriffWrapper spacing={40 / 8}>
    {
      tarrifsArr.map((value) => {
        return <Fragment>
          <TarriffTitle>
            {value.name}
          </TarriffTitle>
          <TarriffRoot>
            {value.list.map((tarif) =>(<Tarif name={tarif.name} price={tarif.price} />))}
          </TarriffRoot>
        </Fragment>
      })
    }
    </TarriffWrapper>
    <BTContainer>Услуги для преподавателей</BTContainer>
    <LineWrapper spacing={20 / 8}>
      <LineContainer>
        <Box>
          <LineText>Методическое консультирование у носителя</LineText>
        </Box>
        <Box>
          <LineTextUnderline>Уточнить цену</LineTextUnderline>
        </Box>
      </LineContainer>
      <LineContainer>
        <Box>
          <LineText>Методическое консультирование у русско-англоязычного преподавателя</LineText>
        </Box>
        <Box>
          <LineTextUnderline>Уточнить цену</LineTextUnderline>
        </Box>
      </LineContainer>
      <LineContainer>
        <Box>
          <LineText>Учебный план на урок</LineText>
        </Box>
        <Box display="flex" alignItems="center" gap={20 / 8} height="fit-content">
          <VioletText>2 500₽</VioletText>
          <VioletteButton>Выбрать</VioletteButton>
        </Box>
      </LineContainer>
      <LineContainer>
        <Box>
          <LineText>Учебный план на неделю/ месяц</LineText>
        </Box>
        <Box display="flex" alignItems="center" gap={20 / 8} height="fit-content">
          <VioletText>6 990₽</VioletText>
          <VioletteButton>Выбрать</VioletteButton>
        </Box>
      </LineContainer>
    </LineWrapper>
    <BTContainer>Пакет библиотека</BTContainer>
    <BoxesWrapper>
        <SelectBooksTarifs>
          <SelectBooksTarifsHeadText>Пробный период</SelectBooksTarifsHeadText>
          <SelectBooksTarifsSmallText>2 недели</SelectBooksTarifsSmallText>
          <Box mt={24 / 8}>
            <SelectBooksTarifsSPriceText>990₽</SelectBooksTarifsSPriceText>
            <Box display="flex" justifyContent="center" mt={1}>
              <Button>Записаться</Button>
            </Box>
          </Box>
        </SelectBooksTarifs>
        <SelectBooksTarifs>
          <SelectBooksTarifsSmallText>1 месяц</SelectBooksTarifsSmallText>
          <Box mt={54 / 8}>
            <SelectBooksTarifsSPriceText>1 490₽</SelectBooksTarifsSPriceText>
            <Box display="flex" justifyContent="center" mt={1}>
              <Button>Записаться</Button>
            </Box>
          </Box>
        </SelectBooksTarifs>
        <SelectBooksTarifs>
          <SelectBooksTarifsSmallText>3 месяца</SelectBooksTarifsSmallText>
          <Box mt={54 / 8}>
            <SelectBooksTarifsSPriceText>4 190₽</SelectBooksTarifsSPriceText>
            <Box display="flex" justifyContent="center" mt={1}>
              <Button>Записаться</Button>
            </Box>
          </Box>
        </SelectBooksTarifs>
        <SelectBooksTarifs>
          <SelectBooksTarifsSmallText>6 месяцев</SelectBooksTarifsSmallText>
          <Box mt={54 / 8}>
            <SelectBooksTarifsSPriceText>7 790₽</SelectBooksTarifsSPriceText>
            <Box display="flex" justifyContent="center" mt={1}>
              <Button>Записаться</Button>
            </Box>
          </Box>
        </SelectBooksTarifs>
    </BoxesWrapper>
  </TarriffContainer>
}
