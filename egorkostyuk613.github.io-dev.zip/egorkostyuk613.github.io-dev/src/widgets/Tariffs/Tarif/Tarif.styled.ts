import {styled} from "shared/lib";
import {Box} from "@mui/system";

export const TarifRoot = styled(Box)({
  borderRadius: 8,
  padding: "34px 78px",
  textAlign: "center",
  background: 'white',
});

export const TarifTitle = styled('p')({
  fontSize: 20,
  lineHeight: "24px",
  fontWeight: 600,
});

export const VioletText = styled('p')({
  color: '#756EDE',
  fontSize: 18,
  lineHeight: "32px",
  marginBottom: 14,
  marginTop: 28,
})

