import { TarifRoot, TarifTitle, VioletText} from "./Tarif.styled";
import {Button} from "shared/ui";

type TarifProps = {
  name: string,
  price: string
}

export const Tarif = ({ name, price }:TarifProps) => {

  return <TarifRoot>
    <TarifTitle>{name}</TarifTitle>
      <VioletText>{price}₽</VioletText>
      <Button margin="auto">Записаться</Button>
  </TarifRoot>
}
