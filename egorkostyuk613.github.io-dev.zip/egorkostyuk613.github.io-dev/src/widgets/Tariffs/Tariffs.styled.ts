import {styled} from "shared/lib";
import {Box, Stack} from "@mui/system";


export const TarriffContainer = styled(Box)({
  marginTop: 100,
})

export const TarriffWrapper = styled(Stack)({})

export const TarriffRoot = styled(Box)({
  display: 'grid',
  gridTemplateColumns: '1fr 1fr 1fr',
  gap: 32,
  marginTop: 65,
})

export const TarriffTitle = styled('p')(({theme}) => ({
  fontSize: "22px",
  lineHeight: "30px",
  color: theme.palette.dark.main,
  fontWeight: 600,
  textAlign: 'center'
}))

export const TarriffBig = styled('p')(({theme}) => ({
  fontSize: "45px",
  lineHeight: "43px",
  color: theme.palette.dark.main,
  fontWeight: 600,
  textAlign: 'left'
}))

export const BTContainer = styled(Box)({
  borderTop: "3px solid rgba(154, 161, 202, 1)",
  borderBottom: "3px solid rgba(154, 161, 202, 1)",
  padding: "14px",
  textAlign: 'center',
  fontSize: 25,
  fontWeight: 600,
  lineHeight: "34px",
  margin: "35px 0px "
})

export const LineWrapper = styled(Stack)({

})

export const LineContainer = styled(Box)({
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  background: 'rgba(255, 255, 255, 1)',
  borderRazdius: 8,
  padding: 35,
})

export const LineText = styled('p')({
  fontSize: 22,
  linbeHeight: '26px',
  fontWeight: 500,
})

export const LineTextUnderline = styled('p')({
  fontSize: 18,
  linbeHeight: '21px',
  fontWeight: 500,
  textDecoration: 'underline',
  cursor: 'pointer',
})

export const VioletteButton = styled(Box)({
  padding: '12px 32px',
  color: 'white',
  background: 'rgba(117, 110, 222, 1)',
  cursor: 'pointer',
  borderRadius: 50,
  height: 'fit-content'
})

export const VioletText = styled('p')({
  color: '#756EDE',
  fontSize: 22,
  lineHeight: "32px",
})

export const BoxesWrapper = styled(Box)({
  display: 'grid',
  gridTemplateColumns: '1fr 1fr 1fr 1fr',
  gap: 38,
})

export const SoloHeadText = styled('p')({
  fontSize: 45,
  fontWeight: 600,
  lineHeight: '60px',
  textAlign: 'left',
})

export const SelectBooksTarifs = styled(Stack)({
  background: 'rgba(255, 255, 255, 1)',
  borderRadius: 18,
  padding: 40,
  textAlign: 'center',
  justifyContent: 'center',
})

export const SelectBooksTarifsHeadText = styled('p')({
  fontSize: 25,
  fontWeight: 600,
  lineHeight: "30px",
})

export const SelectBooksTarifsSmallText = styled('p')({
  fontSize: 25,
  fontWeight: 400,
  lineHeight: "26px",
})

export const SelectBooksTarifsSPriceText = styled('p')({
  fontSize: 27,
  fontWeight: 500,
  lineHeight: "30px",
  color: "rgba(111, 103, 220, 1)",
})
