import styled from "styled-components";
import {Box} from "@mui/system";

export const LoadingContainer = styled(Box)({
  height: '100vh',
  width: '100%',
  position: 'fixed',
  zIndex: 9999999,
  background: "#00000085",
  top: 0,
  left: 0,
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
})

export const LoadingImg = styled('img')({
  height: 100,
  width: 100,
})
