import {LoadingContainer, LoadingImg} from "./Loading.styled";
import spiner from './Spinner.gif'

export const Loading = () => {
  return <LoadingContainer>
    <LoadingImg src={spiner}/>
  </LoadingContainer>
}
