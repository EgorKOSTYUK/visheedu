import {
  ErrorMessageText,
  FormStyled,
  InputContainer,
  InputStyled,
  LoginRoot,
  LoginTitle,
  StyledLink
} from "./Login.styled";
import {Stack} from "@mui/system";
import {Button} from "shared/ui";
import {useNavigate} from "react-router-dom";
import {FieldValues, SubmitHandler, useForm} from "react-hook-form";
import {loginModel} from "../model";
import {useEffect} from "react";
import {observer} from "mobx-react";

export const Login = observer(() => {
  const navigate = useNavigate();
  const {
    register,
    handleSubmit,
  } = useForm()

  useEffect(() => {
    loginModel.setNavigate(navigate);
  }, [navigate]);


  const onSubmit: SubmitHandler<FieldValues> = (data) => {
    loginModel.LoginFunction({
      email: data.email,
      password: data.password,
    })
  }

  // const RequestPasswordRecovery = async () => {
  //   try{
  //     const res = await axios.post('http://localhost:4000/api/user/requestPasswordRecovery', {
  //       email: 'ooovovaooo.2023@gmail.com',
  //     })
  //     console.log(res)
  //   }catch (e){
  //     console.log(e)
  //   }
  //
  // }
  //
  // const ResetPassword = async () => {
  //   try{
  //     const res = await axios.post('http://localhost:4000/api/user/resetPassword', {
  //       email: 'ooovovaooo.2023@gmail.com',
  //       newPassword: 'qwerty123',
  //       code: '48ccf1'
  //     })
  //     console.log(res)
  //   }catch (e){
  //     console.log(e)
  //   }
  //
  // }


  return <LoginRoot>
    <LoginTitle>Войти</LoginTitle>
    <FormStyled onSubmit={handleSubmit(onSubmit)}>
      <Stack spacing={25 / 8} mt={40 / 8}>
        <InputContainer slots={{
          input: InputStyled
        }} placeholder="Электронная почта" {...register('email')}/>
        <InputContainer slots={{
          input: InputStyled
        }} placeholder="Пароль" type="password" {...register('password')}/>
      </Stack>
      <StyledLink to="/register">
        <Button variant="text" mt={15 / 8}>Зарегистрироваться</Button>
      </StyledLink>
        <Button variant="outlinedv4" margin="auto" mt={40 / 8} type='submit'>Войти</Button>
      {loginModel.error ? <ErrorMessageText>Не верный логин или пароль</ErrorMessageText> : null}
    </FormStyled>
  </LoginRoot>
})
