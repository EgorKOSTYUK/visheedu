export const USER_LOGIN_STORAGE_KEY = 'user'
