import {
  ButtonPill, PillArrowImg,
  PillSquere, StyledLink, StyledSpan,
  WhyBlock,
  WhyMainText,
  WhyRoot,
  WhySecondText,
  WhyText,
  WhyWrapper
} from "widgets/Why/Why.styled";

import arrow from './assets/arrow.png';
import first from './assets/first.png';
import second from './assets/second.png';
import third from './assets/third.png';

export const Why = () => {
  return <WhyWrapper>
    <WhyText>Почему именно мы?</WhyText>
    <WhyRoot>
      <WhyBlock style={{ gridArea: 'left1' }} $src={second}>
        <WhyMainText>Индивидуальный подход <br /> к каждому студенту</WhyMainText>
      </WhyBlock>
      <WhyBlock style={{gridArea: 'left2'}} $src={third}>
        <WhyMainText>Начни заниматься <br/> уже сейчас!</WhyMainText>
        <StyledLink to="/register" >
          <ButtonPill>
            <StyledSpan>Зарегестрироваться</StyledSpan>
            <PillSquere>
              <PillArrowImg src={arrow}/>
            </PillSquere>
          </ButtonPill>
        </StyledLink>
      </WhyBlock>
      <WhyBlock style={{ gridArea: 'right' }} $src={first}>
        <WhyMainText>Инновационные технологии<br/>
          бучения,  позволяют <br/> о учиться легко</WhyMainText>
        <WhySecondText>Постепенный и осознанный подход, <br/> чтобы вы не просто учили, а <br/> действительно понимали язык</WhySecondText>
      </WhyBlock>
    </WhyRoot>
  </WhyWrapper>
}
