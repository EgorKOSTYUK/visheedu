import {action, observable} from "mobx";

class AdminModel {
  @observable accessor teachers: any = null
  @observable accessor students: any = null
  @observable accessor studentsForTeacher: any = null
  @observable accessor lessonsForTeacher: any = null
  @observable accessor teacherSolo: any = null
  @observable accessor studentSolo: any = null
  @observable accessor reviews: any = null
  @observable accessor books: any = null
  @observable accessor courses: any = null


  @action.bound setTeachers (user: any) {
    this.teachers = user?.partners || null;
  }

  @action.bound setStudents (user: any) {
    this.students = user?.partners || null;
  }

  @action.bound setStudentsForTeacher (user: any) {
    this.studentsForTeacher = user?.users || null;
  }

  @action.bound setLessonsForStudent (lessons: any) {
    this.lessonsForTeacher = lessons?.lessons || null;
  }

  @action.bound setTeacher (user: any) {
    this.teacherSolo = user;
  }

  @action.bound setStudent (user: any) {
    this.studentSolo = user;
  }

  @action.bound setCourses (books: any) {
    this.courses = books.courses;
  }

  @action.bound setBooks (books: any) {
    this.books = books;
  }

  @action.bound setReviews (tickets: any) {
    this.reviews = tickets.tickets;
  }

}

export const adminModel = new AdminModel();
