import {
  AllReviewsAbsolute,
  AllReviewsContainerLine, AllReviewsHeadDesc,
  AllReviewsHeadText, AllReviewsSpan, AllReviewsText,
  AllReviewsWrapper,
  AllRevirewsContainer
} from "./AllReviews.styled";
import {AdminHeadTitle} from "../Admin.styled";
import {useGetReviews} from "./hooks/useGetReviews";
import {adminModel} from "../../model/Admin.model";
import {format} from "date-fns";

export const AllReviews = () => {
  useGetReviews()

  return <AllRevirewsContainer>
    <AdminHeadTitle>Связь с нами</AdminHeadTitle>
    <AllReviewsWrapper spacing={12 / 8}>
      {adminModel.reviews && adminModel.reviews.map((value: any) => {
        return <AllReviewsContainerLine>
          <AllReviewsAbsolute>{format(value.updatedAt, "dd-MM-yyyy HH:mm")}</AllReviewsAbsolute>
          <AllReviewsHeadText>{value.title}</AllReviewsHeadText>
          <AllReviewsText><AllReviewsSpan>E-mail для связи:</AllReviewsSpan> {value.email}</AllReviewsText>
          <AllReviewsHeadDesc>Описание</AllReviewsHeadDesc>
          <AllReviewsText>{value.description}</AllReviewsText>
        </AllReviewsContainerLine>
      })}

    </AllReviewsWrapper>
  </AllRevirewsContainer>
}
