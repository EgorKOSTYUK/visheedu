import { useQuery } from "react-query";
import axios from "axios";
import { BACK_URL } from "../../../../../shared/back/backURL";
import { adminModel } from "../../../model/Admin.model";

export const getReviews = async () => {
  const res = await axios.get(
    `${BACK_URL}api/admin/course/supportTickets`,
    { withCredentials: true }
  );
  return res.data;
};

export const useGetReviews = () => {
  const { reviews } = adminModel;

  const { data } = useQuery({
    queryKey: "get-admin-reviews",
    queryFn: getReviews,
    enabled: !reviews,
    onSuccess: adminModel.setReviews,
    staleTime: 1000 * 60 * 60 * 24,
    cacheTime: 1000 * 60 * 60 * 24,
    onError: (error) => {
      console.log("An error occurred", error);
    },
    retry: false,
  });

  return {
    reviews: reviews || data?.reviews,
  };
};
