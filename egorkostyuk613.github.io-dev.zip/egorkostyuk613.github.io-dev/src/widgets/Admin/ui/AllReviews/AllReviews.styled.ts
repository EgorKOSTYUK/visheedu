import {styled} from "../../../../shared/lib";
import {Box, Stack} from "@mui/system";

export const AllRevirewsContainer = styled(Box)({})

export const AllReviewsWrapper = styled(Stack)({
  marginTop: 15,
})

export const AllReviewsContainerLine = styled(Box)({
  background: '#FFFFFFB2',
  borderRadius: 8,
  padding: 15,
  position: 'relative',
})

export const AllReviewsHeadText = styled('p')({
  fontSize: 20,
  lineHeight: '43px',
  fontWeight: 'bold',
})

export const AllReviewsHeadDesc = styled('p')({
  fontSize: 18,
  lineHeight: '43px',
  fontWeight: 'bold',
})

export const AllReviewsText = styled('p')({
  fontSize: 16,
  lineHeight: '30px',
  fontWeight: '400',
})

export const AllReviewsSpan = styled('span')({
  fontSize: 16,
  lineHeight: '30px',
  fontWeight: '600',
})

export const AllReviewsAbsolute = styled(Box)({
  position: 'absolute',
  right: 15,
  top: 15,
})
