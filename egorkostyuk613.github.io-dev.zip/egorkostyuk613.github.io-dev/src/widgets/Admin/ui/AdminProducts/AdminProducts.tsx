import {AdminProductsContainer} from "./AdminProducts.styled";
import axios from "axios";
import {BACK_URL} from "../../../../shared/back/backURL";
import {Button} from "../../../../shared/ui";

export const AdminProducts = () => {

const changeProductPrice = async () => {
  try{
    await axios.patch(BACK_URL + 'api/course/product/676c654012ed23ad60bceefa', {
      prices: [
        {
          price: 399900,
          amount: 2592000000
        },
        {
          price: 719000,
          amount: 7776000000
        },
        {
          price: 1979000,
          amount: 15552000000
        },
      ]
    }, {
      withCredentials: true,
    })
  }catch(e){
    console.log(e)
  }
}

  const deleteProductPrice = async () => {
    try{
      await axios.delete(BACK_URL + 'api/course/product/6776ed7678e7834888167c59', {
        withCredentials: true,
      })
    }catch(e){
      console.log(e)
    }
  }


  const createProductPrice = async () => {
    try{
      await axios.post(BACK_URL + 'api/course/product/', { title: "блаблабла", description: "блаааааааааа", category: 'studyBook', prices: [
          {
            price: 399900,
            amount: 2592000000
          },
          {
            price: 719000,
            amount: 7776000000
          },
          {
            price: 1979000,
            amount: 15552000000
          },
        ], course: "676f40a984e066467e758ce8" }, {
        withCredentials: true,
      })
    }catch(e){
      console.log(e)
    }
  }

  return <AdminProductsContainer>
    <Button onClick={changeProductPrice}>change</Button>

    <Button onClick={createProductPrice}>create</Button>

    <Button onClick={deleteProductPrice}>delete</Button>
  </AdminProductsContainer>
}
