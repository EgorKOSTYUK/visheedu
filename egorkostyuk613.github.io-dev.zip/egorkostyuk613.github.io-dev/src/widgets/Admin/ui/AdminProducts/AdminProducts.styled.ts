import {styled} from "../../../../shared/lib";
import {Box} from "@mui/system";

export const AdminProductsContainer = styled(Box)({})
