import {styled} from "../../../shared/lib";
import {Box} from "@mui/system";


export const AdminHeadTitle = styled('p')({
  fontSize: 24,
  lineHeight: "43px",
  fontWeight: 600,
})

export const AdminAccountMenu = styled(Box)({
  background: 'white',
  ['a']:{
    textDecoration: "none",
  }
})

interface backProp {
  $background: boolean;
}

export const AdminAccountMenuText = styled(Box)<backProp>(({$background}) => ({
  fontSize: 18,
  lineHeight: "43px",
  color: "black",
  background: $background ? '#FFFFFFB2' : 'transparent',
  cursor: 'pointer',
  paddingLeft: 4,
  borderRadius: 8,
}))

