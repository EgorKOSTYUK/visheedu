import {TeacherStudentsContainer} from "./TeacherStudents.styled";
import {AdminLine} from "../../../AdminLine/AdminLine";
import {useGetLessonsForTeacher} from "./hooks/useGetLessonsForTeacher";
import {useParams} from "react-router-dom";
import {adminModel} from "../../../../model/Admin.model";

export const TeacherStudents = () => {
  const {teacherId} = useParams()

  // @ts-ignore
  useGetLessonsForTeacher(teacherId)

  console.log(adminModel.studentsForTeacher)

  return <TeacherStudentsContainer spacing={10 / 8}>
    {adminModel.studentsForTeacher && adminModel.studentsForTeacher.map((value: any) => {
      return <AdminLine {...value} who={"students"} key={value._id}/>
    })}

  </TeacherStudentsContainer>
}
