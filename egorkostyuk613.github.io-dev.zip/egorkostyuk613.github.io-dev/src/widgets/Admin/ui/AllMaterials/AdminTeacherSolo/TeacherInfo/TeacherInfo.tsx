import {AvatarContainer, AvatarImage, InfoContainer, InfoTable, InfoText, InfoWrap} from "../AdminTeacherSolo.styled";
import {InfoButtonsContainer} from "./TeacherInfo.styled";
import {Button} from "../../../../../../shared/ui";
import {adminModel} from "../../../../model/Admin.model";
import {format} from "date-fns";
import {useParams} from "react-router-dom";
import {useGetTeacher} from "../hooks/useGetTeacher";

export const TeacherInfo = () => {
  const {teacherId} = useParams()

  // @ts-ignore
  useGetTeacher(teacherId)



  function convertGoogleDriveLink(url: any) {
    const regex = /(?:drive\.google\.com\/file\/d\/)([^\/?]+)/;
    const match = url.match(regex);

    if (match) {
      const fileId = match[1];
      return `https://lh3.google.com/u/0/d/${fileId}`;
    } else {
      return 'Неверная ссылка Google Drive';
    }
  }

  return <InfoContainer>
    <InfoButtonsContainer>
      <Button variant='dark'>Заблокировать</Button>
      {adminModel.teacherSolo && adminModel.teacherSolo.accountActive !== 2 ? <Button>Одобрить</Button> : null}
    </InfoButtonsContainer>
    {adminModel.teacherSolo && <InfoWrap>
      {adminModel.teacherSolo.pictureLink ? <AvatarImage src={convertGoogleDriveLink(adminModel.teacherSolo.pictureLink)}/> : <AvatarContainer />}

      <InfoTable spacing={1}>
        <InfoText>ФИ: {adminModel.teacherSolo.name} {adminModel.teacherSolo.surname}</InfoText>
        <InfoText>E-mail: {adminModel.teacherSolo.email}</InfoText>
        <InfoText>О нем: {adminModel.teacherSolo.bio}</InfoText>
        <InfoText>Образование: {adminModel.teacherSolo.education}</InfoText>
        <InfoText>Подписка действительна до: {adminModel.teacherSolo.studyBooks ? format(adminModel.teacherSolo.studyBooks, "dd-MM-yyyy HH:mm") : "Подписка не продлена/или не куплена"}</InfoText>
      </InfoTable>
    </InfoWrap>}

  </InfoContainer>
}
