import {
  AdminSoloContainer,
  SoloTeacherTab,
  SoloTeacherTabsContainer,
  UpContainer
} from "./AdminTeacherSolo.styled";
import {useState} from "react";
import {TeacherInfo} from "./TeacherInfo/TeacherInfo";
import {TeacherStudents} from "./TeacherStudents";
import {TeacherCalendar} from "./TeacherCalendar";
import {observer} from "mobx-react";

export const AdminTeacherSolo = observer(() => {


  const [tab, setTab] = useState<'info' | "students" | "times">('info')

  const renderFunc = () => {
    switch (tab) {
      case "info":
        return <TeacherInfo />
      case "students":
        return <TeacherStudents />
      case "times":
        return <TeacherCalendar />
    }
  }

  return <AdminSoloContainer>
    <UpContainer>
      <SoloTeacherTabsContainer>
        <SoloTeacherTab $background={tab === 'info'} onClick={() => setTab('info')}>Информация</SoloTeacherTab>
        <SoloTeacherTab $background={tab === 'students'} onClick={() => setTab('students')}>Студенты</SoloTeacherTab>
        <SoloTeacherTab $background={tab === 'times'} onClick={() => setTab('times')}>Расписание</SoloTeacherTab>
      </SoloTeacherTabsContainer>
    </UpContainer>

    {renderFunc()}
  </AdminSoloContainer>
})
