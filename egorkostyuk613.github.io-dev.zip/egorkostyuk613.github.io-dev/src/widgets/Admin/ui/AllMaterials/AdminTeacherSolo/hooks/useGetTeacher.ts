import { useQuery } from "react-query";
import axios from "axios";
import {BACK_URL} from "../../../../../../shared/back/backURL";
import {adminModel} from "../../../../model/Admin.model";


export const getTeacher = async (id: string) => {
  const res = await axios.get(
    `${BACK_URL}api/admin/user/profile/${id}`,
    { withCredentials: true }
  );
  return res.data;
};

export const useGetTeacher = (id: string) => {
  const { data, isLoading } = useQuery({
    queryKey: "get-admin-students",
    queryFn: () => getTeacher(id),
    onSuccess: adminModel.setTeacher,
    onError: (error) => {
      console.log("An error occurred", error);
    },
    retry: false,
  });

  return {
    teachers: adminModel.students || data?.partners,
    isLoading
  };
};
