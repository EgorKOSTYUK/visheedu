import {styled} from "../../../../../../shared/lib";
import { Stack } from "@mui/system";

export const TeacherStudentsContainer = styled(Stack)({})
