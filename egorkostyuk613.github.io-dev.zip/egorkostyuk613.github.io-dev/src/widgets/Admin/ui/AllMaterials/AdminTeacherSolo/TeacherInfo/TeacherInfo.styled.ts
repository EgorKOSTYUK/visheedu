import {styled} from "../../../../../../shared/lib";
import {Box} from "@mui/system";


export const InfoButtonsContainer = styled(Box)({
  margin: "20px 0px",
  display: 'grid',
  gridTemplateColumns: '240px 200px',
  gap: 12,
})
