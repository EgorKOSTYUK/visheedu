import {
  CalendarArrowBlock,
  CalendarArrowRightBlock,
  CalendarDay,
  CalendarDays,
  CalendarRoot,
  CalendarSelectWeeks,
  CalendarSwitcherBlock,
  CalendarSwitchWeek,
  CalendarText,
  CalendarTime,
  CalendarTimes,
  CalendarTimeText,
  CalendarUpContainer, DayText
} from "./TeacherCalendar.styled";
import { format,isSameDay  } from 'date-fns';

import React, {useState} from "react";
import {observer} from "mobx-react";
import {useWeeklyCalendar} from "../../../../../Calendar/config";
import {useGetTimeTeacher} from "../../../../../Calendar/hooks/useGetTimeTeacher";
import {useParams} from "react-router-dom";


export const TeacherCalendar = observer(() => {
  const {teacherId} = useParams()

  // @ts-ignore
  const { time } = useGetTimeTeacher(teacherId);

  const {weekDaysWithTimes, goToPreviousWeek, goToNextWeek, weekRange} = useWeeklyCalendar()

  const [timeWeek, _] = useState<any>({
    timeSlot: null,
    day: null,
    time: null,
    timeForSelect: null
  })

  const filteredTimes = weekDaysWithTimes.map(day => {
    const dayName = format(day.day, 'EEE');


    const availableTimes = time?.hours?.[dayName] || [];

    const filteredDayTimes = day.times.filter(time => {
      const hour = time.getHours();
      return availableTimes.some((slot: any) => slot.timeslot === hour);
    });

    return {
      ...day,
      times: filteredDayTimes
    };
  });

  return <CalendarRoot>
    <h2>Расписание учителя(UTC+0)</h2>
    <CalendarUpContainer>
      <CalendarSelectWeeks>
        <CalendarSwitcherBlock>
          <CalendarSwitchWeek>
            <CalendarArrowBlock onClick={goToPreviousWeek}>
              {"<"}
            </CalendarArrowBlock>
            <CalendarArrowRightBlock onClick={goToNextWeek}>
              {">"}
            </CalendarArrowRightBlock>
          </CalendarSwitchWeek>
          <CalendarText>{weekRange.start + " - " + weekRange.end}</CalendarText>
        </CalendarSwitcherBlock>
      </CalendarSelectWeeks>
      <CalendarDays>
        {weekDaysWithTimes.map(value => {
          return <CalendarDay>
            <DayText>{value.shortDay}</DayText>
            <DayText>{value.dayNumber}</DayText>
          </CalendarDay>
        })}
      </CalendarDays>
      <CalendarTimes>
        {filteredTimes && filteredTimes.map((value, index) => (
          <CalendarTime key={index}>
            {value.times.map((time, idx) => {
              // Проверяем, выбрано ли время
              const isSelected = timeWeek.timeForSelect &&
                isSameDay(time, timeWeek.timeForSelect) &&
                format(time, 'HH:mm') === format(timeWeek.timeForSelect, 'HH:mm');

              return (
                <CalendarTimeText
                  key={idx}
                  $select={isSelected}
                >
                  {format(time, 'HH:mm')}
                </CalendarTimeText>
              );
            })}
          </CalendarTime>
        ))}
      </CalendarTimes>
    </CalendarUpContainer>
  </CalendarRoot>
})
