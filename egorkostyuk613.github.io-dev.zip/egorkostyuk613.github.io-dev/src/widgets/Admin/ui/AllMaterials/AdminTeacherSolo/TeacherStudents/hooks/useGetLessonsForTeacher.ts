import { useQuery } from "react-query";
import axios from "axios";
import {adminModel} from "../../../../../model/Admin.model";
import {BACK_URL} from "../../../../../../../shared/back/backURL";


export const getLessons = async (id: string) => {
  const res = await axios.get(
    `${BACK_URL}api/admin/user/partners?id=${id}&role=1`,
    { withCredentials: true }
  );
  return res.data;
};

export const useGetLessonsForTeacher = (id: string) => {
  const { data } = useQuery({
    queryKey: "get-admin-students",
    queryFn: () => getLessons(id),
    onSuccess: adminModel.setStudentsForTeacher,
    onError: (error) => {
      console.log("An error occurred", error);
    },
    retry: false,
  });

  return {
    teachers: adminModel.students || data?.partners,
  };
};
