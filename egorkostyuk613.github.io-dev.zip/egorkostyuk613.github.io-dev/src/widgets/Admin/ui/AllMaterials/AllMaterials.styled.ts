import {styled} from "../../../../shared/lib";
import {Box} from "@mui/system";

export const AllMaterialsContainer = styled(Box)({})

export const AllMaterialsWrapper = styled(Box)({
  display: 'grid',
  gridTemplateColumns: '1fr 1fr 1fr',
  gap: 24,
})

export const MaterialsTabsContainer = styled(Box)({
  display: 'grid',
  gridTemplateColumns: '200px 200px',
  gap: 12,
  margin: '20px 0px'
})

interface MaterialTabProps {
  $background: boolean
}

export const MaterialsTab = styled(Box)<MaterialTabProps>(({$background}) => ({
  background: $background ? 'rgba(117, 110, 222, 1)' : 'rgba(242, 242, 242, 1)',
  color: $background ? 'white' : 'black',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  fontSize: 18,
  lineHeight: '28px',
  padding: '8px 16px',
  borderRadius: 8,
  cursor: 'pointer'
}))

export const MaterialsCoursesContainer = styled(Box)({
  borderRadius: 8,
  padding: 20,
  background: 'rgba(255, 255, 255, 1)',
  textAlign: 'center',
})

export const MaterialsCoursesButtonsContainer = styled(Box)({
  display: 'flex',
  justifyContent: 'center',
  marginTop: 20,
})


