import {AdminMaterialButton, AdminMaterialContainer, AdminMaterialImg} from "./AdminMaterial.styled";
import {Box} from "@mui/system";
import { ReactComponent as Arrow } from "./arrow.svg"
import {Link, useParams} from "react-router-dom";

export const AdminMaterial = (props: any) => {
  const {courseId} = useParams()

  return <AdminMaterialContainer>
    <AdminMaterialImg />
    <Box>
      {props.name}
      <Box sx={{
        display: 'flex',
        justifyContent: 'flex-end',
        alignItems: 'flex-end',
        height: '80%',
        textDecoration: 'none',
      }}>
        <Link to={`/administr/materials/${courseId}/${props.id}`}>
          <AdminMaterialButton>Перейти <Arrow /> </AdminMaterialButton>
        </Link>
      </Box>
    </Box>
  </AdminMaterialContainer>
}
