
import {Box} from "@mui/system";
import {styled} from "../../../../../shared/lib";

export const AdminMaterialContainer = styled(Box)({
  height: 150,
  background: 'white',
  borderRadius: 8,
  display: 'grid',
  gridTemplateColumns: '98px 1fr',
  padding: 8,
  gap: 15,
  ['a']: {
    textDecoration: 'none',
    color: 'black'
  }
})

export const AdminMaterialImg = styled(Box)({
  background: '#D9D9D9',
  borderRadius: 8,
  height: "100%"
})

export const AdminMaterialButton = styled(Box)({
  cursor: 'pointer',
  padding: "4px 10px",
  display: 'flex',
  alignItems: 'center',
  border: "1px solid black",
  borderRadius: 20,
  width: 'fit-content',
  fontSize: 10,
  marginTop: 'auto',
  ['svg']: {
    marginLeft: 5,
  }
})
