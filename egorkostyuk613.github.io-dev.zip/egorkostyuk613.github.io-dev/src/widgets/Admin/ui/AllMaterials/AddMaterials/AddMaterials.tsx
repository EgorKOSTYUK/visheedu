import { AddMaterialsContainer, AddMaterialsText, AddMaterialsWrapper } from "./AddMaterials.styled";
import { Box } from "@mui/system";
import { Button } from "../../../../../shared/ui";
import axios from "axios";
import { useState } from "react";

export const AddMaterials = () => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.type !== "application/pdf") {
        alert("Пожалуйста, выберите файл в формате PDF.");
        return;
      }
      setSelectedFile(file);
    }
  };

  const handleUpload = async () => {
    if (!selectedFile) {
      alert("Выберите файл для загрузки.");
      return;
    }

    const formData = new FormData();
    formData.append("studyBook", selectedFile);

    console.log(`File name: ${selectedFile.name}, File type: ${selectedFile.type}, File size: ${selectedFile.size}`);

    try {
      const response = await axios.post(
        "http://localhost:4000/api/admin/course/studyBook/676f40a984e066467e758ce8",
        formData,
        {
          withCredentials: true,
        }
      );
      console.log("Upload successful", response.data);
    } catch (error) {
      console.error("Upload failed", error);
    }
  };

  return (
    <AddMaterialsContainer>
      <AddMaterialsWrapper>
        <Box>
          <AddMaterialsText>Добавить книгу</AddMaterialsText>
          <input
            type="file"
            id="pdf-input"
            accept=".pdf"
            onChange={handleFileChange}
          />
        </Box>
        <Button mt={4} onClick={handleUpload}>
          Добавить
        </Button>
      </AddMaterialsWrapper>
    </AddMaterialsContainer>
  );
};
