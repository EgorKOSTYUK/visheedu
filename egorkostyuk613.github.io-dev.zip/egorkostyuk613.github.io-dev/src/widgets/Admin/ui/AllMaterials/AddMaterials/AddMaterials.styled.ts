import {styled} from "../../../../../shared/lib";
import {Box} from "@mui/system";


export const AddMaterialsContainer = styled(Box)({})

export const AddMaterialsWrapper = styled(Box)({
  display: 'grid',
  gridTemplateColumns: '250px 250px',
})

export const AddMaterialsText = styled(Box)({
  fontSize: 16,
  fontWeight: 'bold',
  lineHeight: 3,
})
