import { useQuery } from "react-query";
import { getMaterialSolo } from "../../../../Account/ui/AccountStudent/AccountCourses/api";
import { adminModel } from "../../../model/Admin.model";

export const useGetBooks = () => {
  const shouldFetch = adminModel.books === null; // Проверка, пуст ли `books`

  const { data, isLoading, isError } = useQuery({
    queryKey: "courses-solo",
    queryFn: getMaterialSolo,
    onSuccess: adminModel.setCourses,
    onError: (error) => {
      console.log("An error occurred", error);
    },
    retry: false,
    enabled: shouldFetch, // Запрос выполняется только если `books` пуст
  });

  return {
    book: data ?? adminModel.books, // Возвращаем данные из запроса или из MobX
    isLoading,
    isError,
  };
};
