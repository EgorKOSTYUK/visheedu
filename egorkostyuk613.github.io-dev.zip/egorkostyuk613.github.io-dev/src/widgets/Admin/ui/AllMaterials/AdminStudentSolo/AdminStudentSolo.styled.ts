import {styled} from "../../../../../shared/lib";
import {Box, Stack} from "@mui/system";

export const AdminStudentSoloContainer = styled(Box)({})

export const UpContainer = styled(Box)({})

export const SoloStudentTabsContainer = styled(Box)({
  display: 'grid',
  gridTemplateColumns: '200px 200px 200px',
  gap: 12,
  margin: '20px 0px'
})

interface SoloStudentTabProps {
  $background: boolean
}

export const SoloStudentTab = styled(Box)<SoloStudentTabProps>(({$background}) => ({
  background: $background ? 'rgba(117, 110, 222, 1)' : 'rgba(242, 242, 242, 1)',
  color: $background ? 'white' : 'black',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  fontSize: 18,
  lineHeight: '28px',
  padding: '8px 16px',
  borderRadius: 8,
  cursor: 'pointer'
}))

export const InfoContainer = styled(Box)({
});

export const InfoWrap = styled(Box)({
  display: 'grid',
  gridTemplateColumns: '180px auto',
});


export const AvatarContainer = styled(Box)({
  background: 'rgba(242, 242, 242, 1)',
  borderRadius: 4,
  width: 145,
  height: 165,
})

export const InfoTable = styled(Stack)({})

export const InfoText = styled('p')({
  fontSize: 18,
  lineHeight: '28px',
  fontWeight: 400,
})
