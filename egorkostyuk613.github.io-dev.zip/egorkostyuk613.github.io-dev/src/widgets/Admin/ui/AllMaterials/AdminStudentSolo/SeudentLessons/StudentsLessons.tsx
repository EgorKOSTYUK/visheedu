import {useGetLessonsForStudents} from "./hooks/useGetLessonsForStudents";
import {StudentLessonText, StudentLessonWrapper, StudentsLessonsContainer} from "./StudentsLessons.styled";
import {useParams} from "react-router-dom";
import {adminModel} from "../../../../model/Admin.model";
import {format} from "date-fns";

export const StudentLessons = () => {
  const {studentId} = useParams()

  // @ts-ignore
  useGetLessonsForStudents(studentId)

  console.log(adminModel.lessonsForTeacher)

  return <StudentsLessonsContainer spacing={10 / 8}>
    {adminModel.lessonsForTeacher && adminModel.lessonsForTeacher.map((value: any) => {
      return <StudentLessonWrapper>
        <StudentLessonText>{value.title}</StudentLessonText>
        <StudentLessonText>{new Date(value.time).toISOString().replace("T", " ").slice(0, 16)} UTC+0</StudentLessonText>
      </StudentLessonWrapper>
    })}

  </StudentsLessonsContainer>
}
