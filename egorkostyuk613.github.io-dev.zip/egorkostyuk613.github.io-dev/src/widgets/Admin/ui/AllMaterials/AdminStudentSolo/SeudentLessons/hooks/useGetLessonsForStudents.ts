import { useQuery } from "react-query";
import axios from "axios";
import {adminModel} from "../../../../../model/Admin.model";
import {BACK_URL} from "../../../../../../../shared/back/backURL";


export const getLessons = async (id: string) => {
  const res = await axios.get(
    `${BACK_URL}api/admin/user/lessons?id=${id}&role=2`,
    { withCredentials: true }
  );
  return res.data;
};

export const useGetLessonsForStudents = (id: string) => {
  const { data } = useQuery({
    queryKey: "get-admin-lessons-student",
    queryFn: () => getLessons(id),
    onSuccess: adminModel.setLessonsForStudent,
    onError: (error) => {
      console.log("An error occurred", error);
    },
    retry: false,
  });

  return {
    teachers: adminModel.students || data?.partners,
  };
};
