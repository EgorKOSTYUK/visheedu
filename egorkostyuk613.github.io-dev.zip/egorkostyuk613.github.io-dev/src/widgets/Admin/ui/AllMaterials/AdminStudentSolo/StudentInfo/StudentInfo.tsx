import {AvatarContainer, InfoContainer, InfoTable, InfoText, InfoWrap} from "./../AdminStudentSolo.styled";
import {useGetStudentAdmin} from "./hooks/useGetStudent";
import {useParams} from "react-router-dom";
import {adminModel} from "../../../../model/Admin.model";
import {AvatarImage} from "../../AdminTeacherSolo/AdminTeacherSolo.styled";
import {format} from "date-fns";

export const StudentInfo = () => {
  const {studentId} = useParams()

  // @ts-ignore
  useGetStudentAdmin(studentId)

  function convertGoogleDriveLink(url: any) {
    const regex = /(?:drive\.google\.com\/file\/d\/)([^\/?]+)/;
    const match = url.match(regex);

    if (match) {
      const fileId = match[1];
      return `https://lh3.google.com/u/0/d/${fileId}`;
    } else {
      return 'Неверная ссылка Google Drive';
    }
  }

  return <InfoContainer>
    <InfoWrap>
      {adminModel.studentSolo && <InfoWrap>
        {adminModel.studentSolo.pictureLink ? <AvatarImage src={convertGoogleDriveLink(adminModel.studentSolo.pictureLink)}/> : <AvatarContainer />}

        <InfoTable spacing={1}>
          <InfoText>ФИ: {adminModel.studentSolo.name} {adminModel.studentSolo.surname}</InfoText>
          <InfoText>E-mail: {adminModel.studentSolo.email}</InfoText>
          <InfoText>О нем: {adminModel.studentSolo.bio}</InfoText>
          <InfoText>Образование: {adminModel.studentSolo.education}</InfoText>
          <InfoText>Подписка действительна до: {adminModel.studentSolo.studyBooks ? format(adminModel.studentSolo, "dd-MM-yyyy HH:mm") : "Подписка не продлена/или не куплена"}</InfoText>
        </InfoTable>
      </InfoWrap>}
    </InfoWrap>
  </InfoContainer>
}
