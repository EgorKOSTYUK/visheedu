import {styled} from "../../../../../../shared/lib";
import {Box, Stack} from "@mui/system";

export const StudentsLessonsContainer = styled(Stack)({})

export const StudentLessonWrapper = styled(Box)({
  background: 'rgba(242, 242, 242, 1)',
  borderRadius: 8,
  display: 'flex',
  justifyContent: 'space-between',
  width: "100%",
  padding: 12,
})

export const StudentLessonText = styled('p')({
  fontSize: 18,
  fontWeight: 400,
  lineHeight: '28px',
})
