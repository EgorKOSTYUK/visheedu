import {
  AdminStudentSoloContainer,
  SoloStudentTab,
  SoloStudentTabsContainer,
  UpContainer
} from "./AdminStudentSolo.styled";
import {useState} from "react";
import {StudentInfo} from "./StudentInfo/StudentInfo";
import {StudentLessons} from "./SeudentLessons/StudentsLessons";

export const AdminStudentSolo = () => {
  const [tab, setTab] = useState<'info' | "lessons" | "courses">('info')

  const renderFunc = () => {
    switch (tab) {
      case "info":
        return <StudentInfo />
      case "lessons":
        return <StudentLessons />
    }
  }

  return <AdminStudentSoloContainer>
    <UpContainer>
      <SoloStudentTabsContainer>
        <SoloStudentTab $background={tab === 'info'} onClick={() => setTab('info')}>Информация</SoloStudentTab>
        <SoloStudentTab $background={tab === 'lessons'} onClick={() => setTab('lessons')}>Уроки</SoloStudentTab>
        {/*<SoloStudentTab $background={tab === 'courses'} onClick={() => setTab('courses')}>Курсы</SoloStudentTab>*/}
      </SoloStudentTabsContainer>
    </UpContainer>
    {renderFunc()}
  </AdminStudentSoloContainer>
}
