import {MaterialsContainer} from "./Materials.styled";
import {AllMaterialsWrapper, MaterialsCoursesButtonsContainer, MaterialsCoursesContainer} from "../AllMaterials.styled";
import {useGetBooks} from "../hooks/useGetBooks";
import {adminModel} from "../../../model/Admin.model";
import {Button} from "../../../../../shared/ui";
import {Link} from "react-router-dom";

export const Materials = () => {
  useGetBooks()

  return <MaterialsContainer>
    <AllMaterialsWrapper>
      {adminModel.courses && adminModel.courses.map((value: any) => {
        return <MaterialsCoursesContainer>
          {value.title}
          <MaterialsCoursesButtonsContainer>
            <Link to={`/administr/materials/${value._id}`}>
              <Button variant="outlined" onClick={() => adminModel.setBooks(value.studyBooks)}>Перейти</Button>
            </Link>
          </MaterialsCoursesButtonsContainer>
        </MaterialsCoursesContainer>
      })}
    </AllMaterialsWrapper>
  </MaterialsContainer>
}
