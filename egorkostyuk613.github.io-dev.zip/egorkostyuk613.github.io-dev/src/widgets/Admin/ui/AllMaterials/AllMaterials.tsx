import {AllMaterialsContainer, MaterialsTab, MaterialsTabsContainer} from "./AllMaterials.styled";
import {AdminHeadTitle} from "../Admin.styled";
import {useState} from "react";
import {Materials} from "./Materials";
import {AddMaterials} from "./AddMaterials";
import {useGetBooks} from "./hooks/useGetBooks";

export const AllMaterials = () => {
  useGetBooks()

  const [tab, setTab] = useState<"materials" | "add" >("materials")

  return <AllMaterialsContainer>
    <AdminHeadTitle>Все Материалы</AdminHeadTitle>
    <MaterialsTabsContainer>
      <MaterialsTab onClick={() => setTab("materials")} $background={tab === 'materials'}>Все Книги</MaterialsTab>
      <MaterialsTab onClick={() => setTab("add")} $background={tab === 'add'}>Добавить Книги</MaterialsTab>
    </MaterialsTabsContainer>

    {tab === "materials" ? <Materials /> : <AddMaterials />}
  </AllMaterialsContainer>
}
