import {styled} from "../../../../../shared/lib";
import {Box} from "@mui/system";

export const MaterialListContainer = styled(Box)({
  display: 'grid',
  gridTemplateColumns: '1fr 1fr 1fr',
  gap: 14,
})
