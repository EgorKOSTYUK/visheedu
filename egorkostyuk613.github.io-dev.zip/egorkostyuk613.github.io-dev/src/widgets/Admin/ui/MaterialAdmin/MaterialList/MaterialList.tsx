import {MaterialListContainer} from "./MaterialList.styled";
import {adminModel} from "../../../model/Admin.model";
import {AdminMaterial} from "../../AllMaterials/AdminMaterial/AdminMaterial";

export const MaterialList = () => {

  return <MaterialListContainer>{
    adminModel.books && adminModel.books.map((value: any) => {
      return <AdminMaterial name={value.name} id={value._id}/>
    })
  }</MaterialListContainer>
}
