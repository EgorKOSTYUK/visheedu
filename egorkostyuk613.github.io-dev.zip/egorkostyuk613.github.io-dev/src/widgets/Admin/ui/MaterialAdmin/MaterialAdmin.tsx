import {MaterialContainer} from "./MaterialAdmin.styled";
import {useParams} from "react-router-dom";
import {PDFViewer} from "../../../Account/ui/AccountTeacher/AccountMaterialTeacher/PDFViewer";
import {Loading} from "../../../Loading/Loading";
import {useGetSoloBook} from "../../../Account/ui/AccountTeacher/AccountStudyMaterialSolo/hooks/useGetSoloBook";

export const MaterialAdmin = () => {
  const {bookId, isLoading} = useParams()

  // @ts-ignore
  const {book} = useGetSoloBook(bookId)

  return <MaterialContainer>
    {!isLoading && book ? <PDFViewer base64Data={book.file}/> : <Loading />}
  </MaterialContainer>
}
