import {Link, Outlet, useLocation} from "react-router-dom";
import {AccountTeacherContainer, AccountTeachertRoot} from "../../Account/ui/AccountTeacher/AccountTeacher.styled";
import {AccountContainer, AccountMenu, AccountMenuText} from "../../Account/ui/Account.styled";
import { AdminHeadTitle } from "./Admin.styled";

export const AccountAdmin = () => {
  const location: any = useLocation()

  return <AccountTeachertRoot>
    <AdminHeadTitle>Админ панель</AdminHeadTitle>
    <AccountContainer>
      <AccountMenu>
        <Link to="/administr/students">
          <AccountMenuText $background={location.pathname && location?.pathname.startsWith('/administr/students')}>Все ученики</AccountMenuText>
        </Link>
        <Link to="/administr/teachers">
          <AccountMenuText $background={location.pathname && location?.pathname.startsWith('/administr/teachers')}>Все Учителя</AccountMenuText>
        </Link>
        <Link to="/administr/materials">
          <AccountMenuText $background={location.pathname && location?.pathname.startsWith('/administr/materials')}>Учебные Материалы</AccountMenuText>
        </Link>
        {/*<Link to="/administr/tarifs">*/}
        {/*  <AccountMenuText $background={location.pathname === '/administr/tarifs'}>Тарифы</AccountMenuText>*/}
        {/*</Link>*/}
        <Link to="/administr/reviews">
          <AccountMenuText $background={location.pathname === '/administr/reviews'}>Связь с нами</AccountMenuText>
        </Link>
      </AccountMenu>
      <AccountTeacherContainer>
        <Outlet />
      </AccountTeacherContainer>
    </AccountContainer>
  </AccountTeachertRoot>
}
