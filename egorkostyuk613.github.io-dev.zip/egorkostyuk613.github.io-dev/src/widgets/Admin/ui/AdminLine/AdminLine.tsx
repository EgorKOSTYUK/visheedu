import {AdminLineContainer, AdminNameText} from "./AdminLine.styled";
import {Button} from "../../../../shared/ui";
import {Link} from "react-router-dom";

export const AdminLine = (props: any) => {
  return <AdminLineContainer>
    <AdminNameText>{props.name} {props.surname}</AdminNameText>
    <Link to={`/administr/${props.who}/${props._id}`}>
      <Button variant='outlined'>Открыть пользователя</Button>
    </Link>
  </AdminLineContainer>
}
