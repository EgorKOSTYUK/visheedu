import {styled} from "../../../../shared/lib";
import {Box} from "@mui/system";

export const AdminLineContainer = styled(Box)({
  display: 'flex',
  justifyContent: 'space-between',
  background: 'rgba(255, 255, 255, 1)',
  borderRadius: 8,
  padding: '16px',
  alignItems: 'center',
  ['a']: {
    textDecoration: 'none',
  }
})

export const AdminLineNameContainer = styled(Box)({
  display: 'flex',
  gap: 6,
})

export const AdminNameText = styled('p')({
  color: 'black',
  fontSize: 18,
  lineHeight: '28px'
})

