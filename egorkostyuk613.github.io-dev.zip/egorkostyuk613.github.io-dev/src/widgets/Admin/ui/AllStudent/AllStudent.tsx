import {AllStudentContainer, AllStudentWrapper} from "./AllStudent.styled";
import {AdminHeadTitle} from "../Admin.styled";
import {AdminLine} from "../AdminLine/AdminLine";
import {useGetStudets} from "./hooks/useGetStudents";
import {adminModel} from "../../model/Admin.model";


export const AllStudent = () => {
  useGetStudets()

  return <AllStudentContainer>
    <AdminHeadTitle>Все студенты</AdminHeadTitle>
    <AllStudentWrapper>
      {adminModel.students && adminModel.students.map((value: any) => {
        return <AdminLine {...value} key={value._id} who={"students"}/>
      })}
    </AllStudentWrapper>
  </AllStudentContainer>
}
