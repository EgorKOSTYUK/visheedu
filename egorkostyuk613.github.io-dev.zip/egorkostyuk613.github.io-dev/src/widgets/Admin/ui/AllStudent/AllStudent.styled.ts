import {styled} from "../../../../shared/lib";
import {Box, Stack} from "@mui/system";

export const AllStudentContainer = styled(Box)({})

export const AllStudentWrapper = styled(Stack)({
  marginTop: 15,
})
