import { useQuery } from "react-query";
import axios from "axios";
import { BACK_URL } from "../../../../../shared/back/backURL";
import { adminModel } from "../../../model/Admin.model";

export const getStudents = async () => {
  const res = await axios.get(
    `${BACK_URL}api/admin/course/partners?role=2`,
    { withCredentials: true }
  );
  return res.data;
};

export const useGetStudets = () => {
  const { students } = adminModel;

  const { data } = useQuery({
    queryKey: "get-admin-students",
    queryFn: getStudents,
    enabled: !students,
    onSuccess: adminModel.setStudents,
    staleTime: 1000 * 60 * 60 * 24,
    cacheTime: 1000 * 60 * 60 * 24,
    onError: (error) => {
      console.log("An error occurred", error);
    },
    retry: false,
  });

  return {
    teachers: students || data?.partners,
  };
};
