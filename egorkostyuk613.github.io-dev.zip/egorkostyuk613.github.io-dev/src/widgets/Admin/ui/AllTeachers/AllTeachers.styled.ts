import {styled} from "../../../../shared/lib";
import {Box, Stack} from "@mui/system";


export const AllTeachersContainer = styled(Box)({})

export const AllTeachersWrapper = styled(Stack)({
  marginTop: 15,
})
