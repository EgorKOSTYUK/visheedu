import {AllTeachersContainer, AllTeachersWrapper} from "./AllTeachers.styled";
import {AdminHeadTitle} from "../Admin.styled";
import {AdminLine} from "../AdminLine/AdminLine";
import {useGetTeachers} from "./hooks/useGetTeachers";
import {adminModel} from "../../model/Admin.model";

export const AllTeachers = () => {
  useGetTeachers()

  return <AllTeachersContainer>
    <AdminHeadTitle>Все учителя</AdminHeadTitle>
    <AllTeachersWrapper spacing={10 / 8}>
      {adminModel.teachers && adminModel.teachers.map((value: any) => {
        return <AdminLine {...value} key={value._id} who={"teachers"} />
      })}

    </AllTeachersWrapper>
  </AllTeachersContainer>
}
