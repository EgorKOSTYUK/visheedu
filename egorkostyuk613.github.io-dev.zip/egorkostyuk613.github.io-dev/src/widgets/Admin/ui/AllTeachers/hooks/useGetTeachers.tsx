import { useQuery } from "react-query";
import axios from "axios";
import { BACK_URL } from "../../../../../shared/back/backURL";
import { adminModel } from "../../../model/Admin.model";

export const getTeachersOfCourse = async () => {
  const res = await axios.get(
    `${BACK_URL}api/admin/course/partners?role=1`,
    { withCredentials: true }
  );
  return res.data;
};

export const useGetTeachers = () => {
  const { teachers } = adminModel;

  const { data } = useQuery({
    queryKey: "get-admin-teacher",
    queryFn: getTeachersOfCourse,
    enabled: !teachers, // Выполняем запрос только если teachers не заполнен
    onSuccess: adminModel.setTeachers,
    staleTime: 1000 * 60 * 60 * 24,
    cacheTime: 1000 * 60 * 60 * 24,
    onError: (error) => {
      console.log("An error occurred", error);
    },
    retry: false,
  });

  return {
    teachers: teachers || data?.teachers,
  };
};
