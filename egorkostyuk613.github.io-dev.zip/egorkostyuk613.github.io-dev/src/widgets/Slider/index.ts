export * from './Slidier'
