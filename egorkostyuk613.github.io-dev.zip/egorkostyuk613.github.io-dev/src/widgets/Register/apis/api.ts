import axios from "axios";
import {BACK_URL} from "../../../shared/back/backURL";


export const RegisterFunc = async (props: any) => {
  await axios.post(BACK_URL + 'api/user/profile', {
    "surname": props.surname,
    "name": props.name,
    "network": props.network,
    "role": props.role,
    "email": props.email,
    "password": props.password,
    "termsAgreement": props.termsAgreement,
  }, {
    withCredentials: true
  }).then((data: any) => {
    return data
  })
}
