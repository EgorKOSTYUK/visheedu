export enum RegisterType {
  info,
  email,
  format,
  tarif,
  teacher,
  time,
  timeStudent,
  thanks,
  soloTarif,
  infoTeacher,
  TeacherSubscribe,
}

export enum SelectTarifs {
  solo,
  teacher
}
