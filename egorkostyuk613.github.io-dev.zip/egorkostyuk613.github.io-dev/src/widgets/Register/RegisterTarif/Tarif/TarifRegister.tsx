import { TarifRoot, TarifTitle, VioletText} from "./TarifRegister.styled";
import {Button} from "shared/ui";
import {registerModel} from "../../model/Register.model";
import {RegisterType} from "../../Register.types";
import {observer} from "mobx-react";

type TarifProps = {
  name: string,
  price: string,
  idx: number,
  id: string,
  courseId: string,
  StudentInitSubscribe: (idx: number, id: string) => void
}

export const TarifRegister = observer(({ name, price, idx, id, courseId, StudentInitSubscribe }:TarifProps) => {

  return <TarifRoot>
    <TarifTitle>{name}</TarifTitle>
      <VioletText>{price} ₽</VioletText>
      <Button margin="auto" onClick={() => {
        StudentInitSubscribe(idx, id)
        registerModel.setInfoSelectCourse(id, idx, courseId)
      }}>Записаться</Button>
  </TarifRoot>
})
