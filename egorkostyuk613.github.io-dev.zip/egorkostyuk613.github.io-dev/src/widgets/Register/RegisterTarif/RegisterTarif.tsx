import {RegisterTarifWrapper, TarriffRoot, TarriffTitle} from "./RegisterTarif.styled";
import {TarifRegister} from "./Tarif";
import {observer} from "mobx-react";
import React, {Fragment, useState} from "react";
import {useTarif} from "./hooks/useTarif";
import axios from "axios";
import {registerModel} from "../model/Register.model";
import {RegisterType} from "../Register.types";
import {Button} from "../../../shared/ui";
import {BACK_URL} from "../../../shared/back/backURL";
import {RegisterButtonsContainer} from "../Register.styled";


export const RegisterTarif = observer(() => {
  const { tarifs } = useTarif()
  const [paymentId, setPaymentId] = useState()

  const StudentInitSubscribe = async (index: number, id: string) => {
    try{
      const res = await axios.post( BACK_URL + `api/public/payment/initPay/${id}`,{
        index: index
      }, {
        withCredentials: true
      })
      registerModel.setCourseIdStudent(id)
      setPaymentId(res.data.PaymentId)
      window.open(res.data.PaymentURL, '_blank')

    }catch(e){
      console.log(e)
    }
  }

  const checkPayment = async () => {

    try{
      await axios.post(BACK_URL + `api/public/payment/tPay/${paymentId}`,{}, {
        withCredentials: true
      })



      registerModel.setPage(RegisterType.tarif)
    }
    catch(e){
      console.log(e)
    }
  }

  return <RegisterTarifWrapper spacing={40 / 8}>
    {tarifs?.products && tarifs.products.map((value: any) => {
      return <Fragment>
        <TarriffTitle>
          {value.title}
        </TarriffTitle>

        <TarriffRoot>
          {value.prices.map((tarif: any, idx: any) =>(<TarifRegister name={tarif.amount + ' занятий по 60 минут'} price={tarif.price && tarif.price / 100} idx={idx} id={value._id} courseId={value.course} StudentInitSubscribe={StudentInitSubscribe} />))}
        </TarriffRoot>
      </Fragment>
    })}

    <RegisterButtonsContainer>
      <Button variant="outlinedv4" onClick={checkPayment} ml={18 / 8}>Продолжить</Button>
    </RegisterButtonsContainer>

  </RegisterTarifWrapper>
})
