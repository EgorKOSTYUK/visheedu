import {styled} from "../../../shared/lib";
import {Box, Stack} from "@mui/system";


export const RegisterTarifWrapper = styled(Stack)({
  marginTop: 100,
})

export const TarriffRoot = styled(Box)({
  display: 'grid',
  gridTemplateColumns: '1fr 1fr 1fr',
  gap: 32,
  marginTop: 65,
})

export const TarriffTitle = styled('p')(({theme}) => ({
  fontSize: "22px",
  lineHeight: "30px",
  color: theme.palette.dark.main,
  fontWeight: 600,
  textAlign: 'center'
}))
