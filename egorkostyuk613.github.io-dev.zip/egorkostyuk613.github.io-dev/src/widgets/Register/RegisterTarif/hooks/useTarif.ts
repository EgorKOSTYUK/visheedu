import {useQuery} from "react-query";
import {getTarif} from "../../../Account/ui/AccountStudent/AccountCourses/api";

export const useTarif = () =>  {
  const { data } = useQuery(
    {
      queryKey: "courses-tarif",
      queryFn: () => getTarif(),
      onError: (error) => {
        console.log('An error occurred', error);
      },
      retry: false,
      staleTime: Infinity, // Данные всегда актуальны
      cacheTime: 1000 * 60 * 60, // Кэшируем на 1 час
      enabled: true, // Позволяет запросу выполняться только при явном требовании
    }
  );

  return {
    tarifs: data
  }
}
