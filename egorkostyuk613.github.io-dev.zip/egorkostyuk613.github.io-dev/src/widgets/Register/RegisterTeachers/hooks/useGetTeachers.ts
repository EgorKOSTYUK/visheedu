import {useQuery} from "react-query";
import { getTeachersOfCourse } from "../../../Account/ui/AccountStudent/AccountCourses/api";

export const useGetTeachers = (id: string) => {
  const { data } = useQuery({
    queryKey: 'get-teacher',
    queryFn: () => getTeachersOfCourse(id),
    staleTime: 1000 * 60 * 60 * 24,
    cacheTime: 1000 * 60 * 60 * 24,
    onError: (error) => {
      console.log('An error occurred', error);
    },
    retry: false
  })

  return {
    teachers: data?.teachers
  }
}
