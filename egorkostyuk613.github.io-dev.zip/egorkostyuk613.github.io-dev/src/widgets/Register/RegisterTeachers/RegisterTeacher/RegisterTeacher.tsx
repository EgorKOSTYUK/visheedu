import {
  AboutText,
  AboutWrapeer, Closeutton,
  NameText, RatingText, StarImg, StyledContainer,
  StyledRootButton, StyledVideoContainer,
  TeacherButtonContainer, TeacherImage,
  TeacherImageContainer,
  TeacherInfoContainer,
  TeacherRoot, TeachInfoHeadText
} from "./RegisterTeacher.styled";
import {Button} from "shared/ui";
import {Stack} from "@mui/system";
import star from './star.png'
import {registerModel} from "../../model/Register.model";
import {RegisterType} from "../../Register.types";
import {Dialog} from "../../../../shared/ui/Dialog/Dialog";
import {useState} from "react";

export const RegisterTeacher = (props: any) => {
  const [open, setOpen] = useState(false)

  const getEmbedLink = (link: string) => {
    const fileIdMatch = link.match(/\/d\/(.+?)\//);
    if (fileIdMatch) {
      return `https://drive.google.com/file/d/${fileIdMatch[1]}/preview`;
    }
    return link;
  };

  function convertGoogleDriveLink(url: any) {
    const regex = /(?:drive\.google\.com\/file\/d\/)([^\/?]+)/;
    const match = url.match(regex);

    if (match) {
      const fileId = match[1];
      return `https://lh3.google.com/u/0/d/${fileId}`;
    } else {
      return 'Неверная ссылка Google Drive';
    }
  }

  return <TeacherRoot>
    <TeacherInfoContainer>
      {props?.pictureLink ? <TeacherImage src={convertGoogleDriveLink(props.pictureLink)} /> : <TeacherImageContainer />}

      <Stack spacing={18 / 8}>
        <Stack spacing={12 / 8}>
          <NameText>{props.name} {props.surname} <StarImg src={star}/> <RatingText>5,0</RatingText> </NameText>
          <AboutWrapeer>
            <AboutText>Опыт: 20 лет</AboutText>
            {/*<AboutText>Возраст: 57 лет</AboutText>*/}
            {/*<AboutText>Отзывы: 12</AboutText>*/}
          </AboutWrapeer>
        </Stack>
        <Stack spacing={12 / 8}>
          <TeachInfoHeadText>Образование</TeachInfoHeadText>
          <AboutText>{props.education}</AboutText>
        </Stack>
        <Stack spacing={12 / 8}>
          <TeachInfoHeadText>О себе</TeachInfoHeadText>
          <AboutText>{props.bio}</AboutText>
        </Stack>
      </Stack>
    </TeacherInfoContainer>
    <TeacherButtonContainer>
      {props?.accountActive !== 2 ?
        <Button>Учитель не подтвержен</Button>
        : <Button onClick={() => {
        registerModel.setTeacherId(props.id)
          registerModel.setCourseIdStudent(props.pictureLink)
        registerModel.setPage(RegisterType.timeStudent)
      }}>Записаться</Button>}

      <Button variant="outlined" slots={{
        root: StyledRootButton
      }} onClick={() => setOpen(true)}>Видео-знакомство</Button>
    </TeacherButtonContainer>
    <Dialog open={open} onClose={() => setOpen(false)}>
      <StyledContainer>
        <Closeutton onClick={() => setOpen(false)}>X</Closeutton>
        <StyledVideoContainer>
          <iframe src={getEmbedLink(props.videoYT)} width="640"
                  height="400" allow="autoplay" frameBorder="none"></iframe>
        </StyledVideoContainer>
      </StyledContainer>
    </Dialog>
  </TeacherRoot>
}
