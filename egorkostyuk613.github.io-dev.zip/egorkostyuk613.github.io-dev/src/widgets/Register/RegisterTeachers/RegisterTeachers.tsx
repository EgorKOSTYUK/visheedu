import {TeachersRoot, TeachersTitle} from "./RegisterTeachers.styled";
import {Stack} from "@mui/system";
import {RegisterTeacher} from "./RegisterTeacher";
import {useGetTeachers} from "./hooks/useGetTeachers";
import {observer} from "mobx-react";
import {registerModel} from "../model/Register.model";
import {Button} from "../../../shared/ui";
import {RegisterType} from "../Register.types";
import {RegisterButtonsContainer} from "../Register.styled";
import React from "react";

export const RegisterTeachers = observer(() => {
  // @ts-ignore
  const { teachers } = useGetTeachers(registerModel?.courseId);

  return <TeachersRoot>
    <TeachersTitle>Выбор преподавателя</TeachersTitle>
    <Stack spacing={30 / 8} mt={34 / 8}>
      {teachers && teachers.map((value: any) => {
        return <RegisterTeacher key={value.surname} name={value.name} surname={value.surname} id={value._id} videoYT={value.videoYT} pictureLink={value.pictureLink} accountActive={value.accountActive} education={value.education} bio={value.bio}/>
      })}
    </Stack>
    <RegisterButtonsContainer>
      <Button variant="outlinedv4" onClick={() => registerModel.setPage(RegisterType.teacher)}>Назад</Button>
    </RegisterButtonsContainer>
  </TeachersRoot>
})
