import {
  CalendarArrowBlock, CalendarArrowRightBlock, CalendarDay,
  CalendarDays,
  CalendarRoot,
  CalendarSelectWeeks, CalendarSwitcherBlock,
  CalendarSwitchWeek, CalendarText, CalendarTime, CalendarTimes, CalendarTimeText,
  CalendarUpContainer, DayText
} from "./CalendarStudent.styled";
import { format,isSameDay  } from 'date-fns';
import {useWeeklyCalendar} from "./config";
import axios from "axios";
import React, {useState} from "react";
import {observer} from "mobx-react";

import {useGetTimeTeacher} from "./hooks/useGetTimeTeacher";
import {Button} from "../../../shared/ui";
import {registerModel} from "../model/Register.model";
import {RegisterType} from "../Register.types";
import {BACK_URL} from "../../../shared/back/backURL";
import {RegisterButtonsContainer} from "../Register.styled";
import {InfoTeacherHeadText} from "../InfoTeacher/InfoTeacher.styled";
import {UTCText} from "../../Calendar/Calendar.styled";

export const CalendarStudent = observer(() => {
  // @ts-ignore
  const { time } = useGetTimeTeacher(registerModel.registerTeacherId);

  const {weekDaysWithTimes, goToPreviousWeek, goToNextWeek, weekRange} = useWeeklyCalendar()

  const [timeWeek, setTime] = useState<any>({
    timeSlot: null,
    day: null,
    time: null,
    timeForSelect: null
  })

  // console.log(timeWeek)

//+ registerModel.courseId
  const selectTimeStudent = async () => {

    await axios.post(BACK_URL + 'api/public/schedule/reserveHour/' + registerModel.courseId , {
      teacherId: registerModel.registerTeacherId,
      timeslot: timeWeek.timeSlot,
      day: timeWeek.day,
      time: timeWeek.time,
    } , {
      withCredentials: true
    })

    registerModel.setPage(RegisterType.thanks)
  }

  const filteredTimes = weekDaysWithTimes.map(day => {
    const dayName = format(day.day, 'EEE'); // Получаем сокращенное название дня, например "Mon"

    // Проверка на наличие данных, если time.hours отсутствует (null или undefined)
    const availableTimes = time?.hours?.[dayName] || []; // Получаем доступные слоты для дня из backendData, или пустой массив если нет данных

    // Фильтруем время в зависимости от доступных слотов с бэка, если availableTimes не пустой
    const filteredDayTimes = day.times.filter(time => {
      const hour = time.getHours(); // Извлекаем час из времени
      return availableTimes.some((slot: any) => slot.timeslot === hour); // Проверяем, что этот слот присутствует в данных с бэка
    });

    // Возвращаем новый объект с отфильтрованным временем
    return {
      ...day,
      times: filteredDayTimes
    };
  });

  return <CalendarRoot>
    <InfoTeacherHeadText>Выбор расписания</InfoTeacherHeadText>
    <UTCText>Выбор времени в UTC+0</UTCText>
    <CalendarUpContainer>
      <CalendarSelectWeeks>
        <CalendarSwitcherBlock>
          <CalendarSwitchWeek>
            <CalendarArrowBlock onClick={goToPreviousWeek}>
              {"<"}
            </CalendarArrowBlock>
            <CalendarArrowRightBlock onClick={goToNextWeek}>
              {">"}
            </CalendarArrowRightBlock>
          </CalendarSwitchWeek>
          <CalendarText>{weekRange.start + " - " + weekRange.end}</CalendarText>
        </CalendarSwitcherBlock>
      </CalendarSelectWeeks>
      <CalendarDays>
        {weekDaysWithTimes.map(value => {
          return <CalendarDay>
            <DayText>{value.shortDay}</DayText>
            <DayText>{value.dayNumber}</DayText>
          </CalendarDay>
        })}
      </CalendarDays>
      <CalendarTimes>
        {filteredTimes && filteredTimes.map((value, index) => (
          <CalendarTime key={index}>
            {value.times.map((time, idx) => {
              // Проверяем, выбрано ли время
              const isSelected = timeWeek.timeForSelect &&
                isSameDay(time, timeWeek.timeForSelect) &&
                format(time, 'HH:mm') === format(timeWeek.timeForSelect, 'HH:mm');

              return (
                <CalendarTimeText
                  key={idx}
                  $select={isSelected}
                  onClick={() => {
                    const hour = parseInt(format(time, 'H'), 10);

                    setTime({
                      timeSlot: hour,
                      day: format(time, 'EEE'),
                      time: format(time, 'yyyy-MM-dd'),
                      timeForSelect: time
                    });
                  }}
                >
                  {format(time, 'HH:mm')}
                </CalendarTimeText>
              );
            })}
          </CalendarTime>
        ))}
      </CalendarTimes>
    </CalendarUpContainer>
    <RegisterButtonsContainer>
      <Button variant="outlinedv4" onClick={() => registerModel.setPage(RegisterType.tarif)}>Назад</Button>
      <Button variant="outlinedv4" type="submit" ml={18 / 8} onClick={selectTimeStudent}>Запись</Button>
    </RegisterButtonsContainer>
  </CalendarRoot>
})
