import {useQuery} from "react-query";
import {getTeacher} from "../../../Account/ui/AccountStudent/AccountCourses/api";


export const useGetTimeTeacher = (id: string) => {
  const { data } = useQuery({
    queryKey: 'get-teachers',
    queryFn: () => getTeacher(id),
    staleTime: 1000 * 60 * 60 * 24,
    cacheTime: 1000 * 60 * 60 * 24,
    onError: (error) => {
      console.log('An error occurred', error);
    },
    retry: false
  })

  return {
    time: data
  }
}
