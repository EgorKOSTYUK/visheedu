import {
  RegisterSelectBooksTarifs,
  RegisterSelectBooksTarifsHeadText,
  RegisterSelectBooksTarifsSmallText,
  RegisterSelectBooksTarifsSPriceText,
  RegisterSoloEducatedContaioner,
  RegisterSoloEducatedWrapper,
  RegisterSoloHeadText
} from "./RegisterSoloEducated.styled";
import {Button} from "../../../shared/ui";
import {Box} from "@mui/system";
import {registerModel} from "../model/Register.model";
import {RegisterType} from "../Register.types";
import axios from "axios";
import {useCoursaes} from "./hooks/useSoloBooks";
import React, {useState} from "react";
import {BACK_URL} from "../../../shared/back/backURL";
import {RegisterButtonsContainer} from "../Register.styled";

export const RegisterSoloEducated = () => {
  const [paymentId, setPaymentId] = useState()
  const {courses} = useCoursaes();

  const payFunc = async (props: any) => {

    try{
      const res = await axios.post(BACK_URL + `api/public/payment/initPay/${props.id}`,{
        index: props.index
      }, {
        withCredentials: true
      })
      setPaymentId(res.data.PaymentId)
      window.open(res.data.PaymentURL, '_blank')

      //registerModel.setPage(RegisterType.thanks)
    }
    catch(e){
      console.log(e)
    }
  }

  const checkPayment = async () => {

    try{
      await axios.post(BACK_URL + `api/public/payment/tPay/${paymentId}`,{}, {
        withCredentials: true
      })
      //
      // registerModel.setPage(RegisterType.thanks)
    }
    catch(e){
      console.log(e)
    }
  }

  // const initSolo = async () => {
  //   await axios.post(`http://localhost:4000/api/course/product/`,{
  //     title: 'доступ к учебникам',
  //     description: 'доступ к учебникам',
  //     category: "studyBook",
  //     prices: [{
  //       price: 99000,
  //       amount: 1209600000,
  //       },
  //       {
  //         price: 199900,
  //         amount: 2592000000,
  //       },
  //       {
  //         price: 419000,
  //         amount: 7776000000,
  //       },
  //       {
  //         price: 770900,
  //         amount: 15552000000,
  //       }],
  //     // course,
  //     // file,
  //     // teacher
  //   }, {
  //     withCredentials: true
  //   })
  // }
  return <RegisterSoloEducatedWrapper>
    <RegisterSoloHeadText>Доступ к учебникам</RegisterSoloHeadText>
    <RegisterSoloEducatedContaioner>
      {courses?.products && courses.products[0].prices.map((value: any, idx: number) => {
        return <RegisterSelectBooksTarifs>
          {value.amount / 1000 / 60 / 60 / 24 < 15 && <RegisterSelectBooksTarifsHeadText>Пробный период</RegisterSelectBooksTarifsHeadText>}

          <RegisterSelectBooksTarifsSmallText>{value.amount / 1000 / 60 / 60 / 24} дней</RegisterSelectBooksTarifsSmallText>
          <Box mt={24 / 8}>
            <RegisterSelectBooksTarifsSPriceText>{value.price / 100}</RegisterSelectBooksTarifsSPriceText>
            <Box display="flex" justifyContent="center" mt={1}>
              <Button onClick={() => payFunc({
                id: courses.products[0]._id,
                index: idx
              })}>Записаться</Button>
            </Box>
          </Box>
        </RegisterSelectBooksTarifs>
      })}

    </RegisterSoloEducatedContaioner>
    <RegisterButtonsContainer>
      <Button variant="outlinedv4" onClick={() => registerModel.setPage(RegisterType.email)}>Назад</Button>
      <Button variant="outlinedv4" onClick={checkPayment} ml={18 / 8}>Продолжить</Button>
    </RegisterButtonsContainer>
  </RegisterSoloEducatedWrapper>
}
