import {styled} from "../../../shared/lib";
import {Box} from "@mui/system";


export const RegisterFormatWrapper = styled(Box)({
  textAlign: 'left',
})

export const RegisterFormatHeaderText = styled('p')({
  fontSize: 45,
  lineHeight: '65px',
  fontWeight: 600,
})

export const RegisterFormatSelect = styled(Box)({
  border: '4px solid rgba(192, 197, 228, 1)',
  padding: 40,
  borderRadius: 18,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
})

export const RagisterFormatNameText = styled('p')({
  fontSize: 25,
  fontWeight: 600,
  lineHeight: "34px",
})

export const RegisterFormatText = styled('p')({
  fontSize: 20,
  fontWeight: 400,
  lineHeight: "37px",
})

export const RegisterFormatButton = styled(Box)({
  padding: '16px 32px',
  background: 'rgba(0, 0, 0, 1)',
  color: 'rgba(255, 255, 255, 1)',
  fontSize: 18,
  fontWeight: 600,
  lineHeight: "25px",
  borderRadius: 25,
  cursor: 'pointer',
})
