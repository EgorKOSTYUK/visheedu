import {
  RagisterFormatNameText, RegisterFormatButton,
  RegisterFormatHeaderText,
  RegisterFormatSelect, RegisterFormatText,
  RegisterFormatWrapper
} from "./RegisterFormat.styled";
import {Box, Stack} from "@mui/system";
import { ReactComponent as OpenBook } from './open-book.svg'
import { ReactComponent as ManAtTheBlackboard } from './man-at-the-blackboard.svg'
import {registerModel} from "../model/Register.model";
import {RegisterType, SelectTarifs} from "../Register.types";
import {Button} from "../../../shared/ui";
import {RegisterButtonsContainer} from "../Register.styled";
import React from "react";

export const RegisterFormat = () => {
  return <RegisterFormatWrapper>
    <RegisterFormatHeaderText>Какой формат обучения вам подходит?</RegisterFormatHeaderText>
    <Stack spacing={25 / 8} mt={45 / 8}>
      <RegisterFormatSelect>
        <Box display="flex" alignItems="center" gap={25 / 8}> <OpenBook /> <RagisterFormatNameText>Самостоятельно</RagisterFormatNameText> </Box>
        <RegisterFormatText>Доступ к материалам для самостоятельного изучения.</RegisterFormatText>
        <RegisterFormatButton onClick={() => {
          registerModel.setTarif(SelectTarifs.solo)
          registerModel.setPage(RegisterType.soloTarif)
        }}>Выбрать</RegisterFormatButton>
      </RegisterFormatSelect>
      <RegisterFormatSelect>
        <Box display="flex" alignItems="center" gap={25 / 8}> <ManAtTheBlackboard /> <RagisterFormatNameText>С преподавателем</RagisterFormatNameText> </Box>
        <RegisterFormatText>Получите персональную поддержку и наставничество.</RegisterFormatText>
        <RegisterFormatButton onClick={() => {
          registerModel.setTarif(SelectTarifs.teacher)
          registerModel.setPage(RegisterType.teacher)
        }}>Выбрать</RegisterFormatButton>
      </RegisterFormatSelect>
    </Stack>
    <RegisterButtonsContainer>
      <Button variant="outlinedv4" onClick={() => registerModel.setPage(RegisterType.email)}>Назад</Button>
    </RegisterButtonsContainer>
  </RegisterFormatWrapper>
}
