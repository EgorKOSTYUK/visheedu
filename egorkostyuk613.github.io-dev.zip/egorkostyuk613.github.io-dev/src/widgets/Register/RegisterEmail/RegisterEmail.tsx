import React, { useState, useEffect } from "react";
import {
  InputStyledEmail,
  RegisterEmailButton,
  RegisterEmailHeaderText,
  RegisterEmailWrapper,
  RegisterMainText,
  RegisterMainTextBold,
} from "./RegisterEmail.styled";
import { Box } from "@mui/system";
import { registerModel } from "../model/Register.model";
import { observer } from "mobx-react";
import { RegisterType } from "../Register.types";
import axios from "axios";
import {Loading} from "../../Loading/Loading";
import {ErrorMessage} from "../InfoTeacher/InfoTeacher.styled";
import {BACK_URL} from "../../../shared/back/backURL";
import {RegisterButtonsContainer} from "../Register.styled";
import {Button} from "../../../shared/ui";

export const RegisterEmail = observer(() => {
  const [timer, setTimer] = useState<number>(0); // Хранит оставшееся время в секундах
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(false);
  const [emailCode, setEmailCode] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<boolean>(false);

  const startTimer = (duration: number) => {
    setTimer(duration);
    setIsTimerRunning(true);
  };

  useEffect(() => {
    // @ts-ignore
    let interval: NodeJS.Timeout | null = null;

    if (isTimerRunning && timer > 0) {
      interval = setInterval(() => {
        setTimer((prevTimer) => prevTimer - 1);
      }, 1000);
    }

    if (timer <= 0 && isTimerRunning) {
      setIsTimerRunning(false); // Устанавливаем false, когда таймер заканчивается
    }

    return () => {
      if (interval) clearInterval(interval); // Очистка таймера
    };
  }, [timer, isTimerRunning]);

  const sendVerifyEmail = async () => {
    setLoading(true)
    if(isTimerRunning){
      return;
    }

    try {
      await axios.post(BACK_URL + "api/user/sendVerificationEmail", {}, {
        withCredentials: true,
      });
      startTimer(1 * 60); // Запуск таймера на 5 минут
      setLoading(false)
    } catch (e) {
      console.log(e);
      setLoading(false)
    }
  };

  const verifyEmail = async () => {
    try {
      await axios.post(
        BACK_URL + "api/user/verifyEmail",
        {
          code: emailCode,
        },
        {
          withCredentials: true,
        }
      );

      registerModel.setPage(
        registerModel.selectRole === "ученик" ? RegisterType.format : RegisterType.infoTeacher
      );
    } catch (e) {
      setError(true)
      console.log(e);
    }
  };

  // Форматирование таймера в mm:ss
  const formatTimer = (time: number) => {
    const minutes = Math.floor(time / 60);
    const seconds = time % 60;
    return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
  };

  return (
    <RegisterEmailWrapper>
      <RegisterEmailHeaderText>Подтверждение email</RegisterEmailHeaderText>
      <Box mt={23 / 8} maxWidth="800px">
        <RegisterMainText>
          На ваш адрес электронной почты{" "}
          <RegisterMainTextBold>{registerModel.email}</RegisterMainTextBold> было отправлено письмо со
          ссылкой для подтверждения.
        </RegisterMainText>
        <RegisterMainText>Пожалуйста, проверьте вашу почту.</RegisterMainText>
      </Box>
      <Box mt={25 / 8}>
        <InputStyledEmail placeholder="Введите код" onChange={(e) => setEmailCode(e.target.value)} value={emailCode}/>
        {error && <ErrorMessage>Не верный код</ErrorMessage>}
        <Box display={"grid"} gridTemplateColumns={isTimerRunning ? "280px 220px" : "220px 220px"} mt={2}>
          <RegisterEmailButton onClick={sendVerifyEmail}>
            {isTimerRunning ? `Запросить код (${formatTimer(timer)})` : "Запросить код"}
          </RegisterEmailButton>
          <RegisterEmailButton onClick={verifyEmail}>Подтвердить код</RegisterEmailButton>
        </Box>
      </Box>
      <RegisterButtonsContainer>
        <Button variant="outlinedv4" onClick={() => registerModel.setPage(RegisterType.info)}>Назад</Button>
      </RegisterButtonsContainer>
      {loading && <Loading />}
    </RegisterEmailWrapper>
  );
});
