import {styled} from "../../../shared/lib";
import {Box} from "@mui/system";

export const RegisterEmailWrapper = styled(Box)({
  textAlign: 'left',
  padding: 100,
})

export const RegisterEmailHeaderText = styled('p')({
  fontSize: 45,
  lineHeight: '65px',
  fontWeight: 600,
})

export const RegisterMainText = styled('p')({
  fontSize: 27,
  lineHeight: '36px',
  fontWeight: 400,
  marginTop: "12px"
})

export const RegisterMainTextBold = styled('span')({
  fontWeight: 600,
})

export const RegisterMainSmallText = styled('p')({
  fontSize: 18,
  fontWeight: 600,
})

export const RegisterEmailButton = styled(Box)({
  padding: "16px 32px",
  borderRadius: 8,
  fontSize: 18,
  fontWeight: 600,
  color: "#FFFFFF",
  backgroundColor: "rgba(0, 0, 0, 1)",
  width: 'fit-content',
  cursor: 'pointer'
})

export const InputStyledEmail = styled('input')({
  border: "1px solid #F2F2F2",
  borderRadius: 10,
  padding: '12px 18px',
  backgroundColor: "#F2F2F2",
  width: '390px',
})

