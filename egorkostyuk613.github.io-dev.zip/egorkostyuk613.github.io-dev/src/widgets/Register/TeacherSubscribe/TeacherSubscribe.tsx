import {
  TeacherButton,
  TeacherSubscribeContainer,
  TeacherSubscribeGrid,
  TeacherSubscribeHeadText, TeacherSubscribePriceText,
  TeacherSubscribeWrapper
} from "./TeacherSubscribe.styled";
import {Stack} from "@mui/system";
import {registerModel} from "../model/Register.model";
import {RegisterType} from "../Register.types";
import axios from "axios";
import { useGetTeacherSubscribes} from "./hooks/useGetTeacherSubscribes";
import React, {useState} from "react";
import {Button} from "../../../shared/ui";
import {BACK_URL} from "../../../shared/back/backURL";
import {RegisterButtonsContainer} from "../Register.styled";

export const TeacherSubscribe = () => {
  const [paymentId, setPaymentId] = useState()

  const { courses } = useGetTeacherSubscribes()

  const TeacherInitSubscribe = async (index: number, id: string) => {
    try{
      const res = await axios.post(BACK_URL + `api/public/payment/initPay/${id}`,{
        index: index
      }, {
        withCredentials: true
      })

      setPaymentId(res.data.PaymentId)
      window.open(res.data.PaymentURL, '_blank')

    }catch(e){
      console.log(e)
    }
  }

  const checkPayment = async () => {

    try{
      await axios.post(BACK_URL + `api/public/payment/tPay/${paymentId}`,{}, {
        withCredentials: true
      })

      registerModel.setPage(RegisterType.time)
    }
    catch(e){
      console.log(e)
    }
  }


  return <TeacherSubscribeContainer>
    <TeacherSubscribeHeadText>Варианты подписки для учебных материалов</TeacherSubscribeHeadText>

    <TeacherSubscribeGrid>
      {courses && courses[0].prices.map((value: any, idx: number) => {
        return <TeacherSubscribeWrapper spacing={10}>
          <TeacherSubscribeHeadText>{value.amount / 1000 / 60 / 60 / 24} дней</TeacherSubscribeHeadText>
          <Stack spacing={35 / 8} justifyContent="center" alignItems="center">
            <TeacherSubscribePriceText>{value.price / 100} ₽</TeacherSubscribePriceText>
            <TeacherButton onClick={() => TeacherInitSubscribe(idx, courses[0]._id)}>Выбрать</TeacherButton>
          </Stack>
        </TeacherSubscribeWrapper>
      })}
    </TeacherSubscribeGrid>
    <RegisterButtonsContainer>
      <Button variant="outlinedv4" onClick={() => registerModel.setPage(RegisterType.email)}>Назад</Button>
      <Button variant="outlinedv4" onClick={checkPayment} ml={18 / 8}>Продолжить</Button>
    </RegisterButtonsContainer>

  </TeacherSubscribeContainer>
}
