import {styled} from "../../../shared/lib";
import {Box, Stack} from "@mui/system";

export const TeacherSubscribeContainer = styled(Box)({
  textAlign: 'left',
  marginTop: 40,
})

export const TeacherSubscribeGrid = styled(Box)({
  display: 'grid',
  gridTemplateColumns: '1fr 1fr 1fr',
  gap: 35,
  marginTop: 35,
})

export const TeacherSubscribeWrapper = styled(Stack)({
  padding: 84,
  border: '4px solid rgba(192, 197, 228, 1)',
  borderRadius: '32px',
  textAlign: 'center'
})


export const TeacherSubscribeHeadText = styled('p')({
  fontSize: 45,
  fontWeght: 600,
})

export const TeacherSubscribePriceText = styled('p')({
  fontSize: 27,
  fontWeght: 500,
  color: 'rgba(117, 110, 222, 1)',
})

export const TeacherButton = styled(Box)({
  background: 'rgba(117, 110, 222, 1)',
  borderRadius: '40px',
  padding: '8px 55px',
  color: 'white',
  fontSize: 18,
  fontWeight: 500,
  textAlign: 'center',
  width: 'fit-content',
  margin: '0 auto',
  cursor: 'pointer'
})
