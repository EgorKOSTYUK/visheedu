import {useQuery} from "react-query";
import axios from "axios";
import {BACK_URL} from "../../../../shared/back/backURL";

export const getTeacherSubscribe = async () => {
  const res = await axios.get( BACK_URL + 'api/public/payment/products?category=studyBookTeacher', {
    withCredentials: true,
  })

  return res.data
}

export const useGetTeacherSubscribes = () =>  {
  const { data } = useQuery(
    {
      queryKey: "teacher-courses-solo",
      queryFn: () => getTeacherSubscribe(),
      onError: (error) => {
        console.log('An error occurred', error);
      },
    }
  );

  return {
    courses: data?.products
  }
}
