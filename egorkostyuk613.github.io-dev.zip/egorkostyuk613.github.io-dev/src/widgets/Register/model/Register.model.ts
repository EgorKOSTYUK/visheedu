import {action, observable} from "mobx";
import {RegisterType, SelectTarifs} from "../Register.types";

class Register {
  @observable accessor registerPage: RegisterType = RegisterType.info;
  @observable accessor selectTarif: SelectTarifs = SelectTarifs.solo;
  @observable accessor idSelect: string | null = null;
  @observable accessor email: string | null = null;
  @observable accessor indexPrice: number | null = null;
  @observable accessor courseId: string | null = null;
  @observable accessor courseIdStudent: string | null = null;
  @observable accessor selectRole: 'ученик' | "преподаватель" = 'ученик';
  @observable accessor registerTeacherId: string | null = null;

  @action.bound setPage(prop: RegisterType){
    this.registerPage = prop
  }

  @action.bound setEmail(email: string){
    this.email = email
  }

  @action.bound setTarif(selectTarifProp: SelectTarifs){
    this.selectTarif = selectTarifProp
  }

  @action.bound setRole(selectRoleProp: 'ученик' | "преподаватель"){
    this.selectRole = selectRoleProp
  }

  @action.bound setInfoSelectCourse(id: string, idx: number, courseId: string){
    this.idSelect = id
    this.indexPrice = idx
    this.courseId = courseId
  }

  @action.bound setTeacherId(teacherId: string){
    this.registerTeacherId = teacherId;
  }

  @action.bound setCourseIdStudent(teacherId: string){
    this.courseIdStudent = teacherId;
  }
}

export const registerModel: Register = new Register();
