import { useState } from "react";
import { useDropzone } from "react-dropzone";
import {
  IconsContaienr,
  SendDragItem,
  SendHomeWorkContainer,
  SendHomeWorkContent,
  SendHomeWorkRight,
  SendSmallText,
  SendTable,
  SendTableBody,
  SendTableHead,
  SendTableRow,
  SendText,
  SendWhiteContainer,
} from "./InfoUploadFiles.styled";
import { format } from "date-fns";
import { ReactComponent as Trash } from "./assets/trash.svg";
import { ReactComponent as Upload } from "./assets/upload.svg";

export const InfoUploadFiles = ({ onFilesSelected }: { onFilesSelected: (files: File[]) => void }) => {
  const [files, setFiles] = useState<File[]>([]);
  const { getRootProps, getInputProps } = useDropzone({
    onDrop: (acceptedFiles) => {
      setFiles((prevFiles) => [...prevFiles, ...acceptedFiles]);
      onFilesSelected(acceptedFiles); // Передача файлов в родительский компонент
    },
    maxFiles: 5,
  });

  return (
    <SendHomeWorkContainer>
      {"(PDF 1 файл до 10мб)"}
      <SendHomeWorkContent>
        <SendHomeWorkRight>
          <IconsContaienr>
            <Upload />
            <Trash onClick={() => setFiles([])} />
          </IconsContaienr>
          <SendWhiteContainer {...getRootProps()}>
            <input {...getInputProps()} style={{ display: "none" }} />
            {files.length > 0 ? (
              <SendTable>
                <SendTableHead>
                  <SendSmallText>Название</SendSmallText>
                  <SendSmallText>Последнее изменение</SendSmallText>
                  <SendSmallText>Размер</SendSmallText>
                  <SendSmallText>Тип</SendSmallText>
                </SendTableHead>
                <SendTableBody>
                  {files.map((file) => (
                    <SendTableRow key={file.name}>
                      <SendSmallText>{file.name}</SendSmallText>
                      <SendSmallText>{format(file.lastModified, "dd.MM.yyyy")}</SendSmallText>
                      <SendSmallText>{(file.size / 1024).toFixed(2)} KB</SendSmallText>
                      <SendSmallText>{file.type}</SendSmallText>
                    </SendTableRow>
                  ))}
                </SendTableBody>
              </SendTable>
            ) : (
              <SendDragItem>
                <SendText>Для загрузки файлов перетащите их сюда</SendText>
              </SendDragItem>
            )}
          </SendWhiteContainer>
        </SendHomeWorkRight>
      </SendHomeWorkContent>
    </SendHomeWorkContainer>
  );
};
