import { useForm, Controller } from "react-hook-form";
import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import {
  AvtarBlock,
  AvtarBlockBox,
  ErrorMessage,
  InfoButton, InfoButtonVideo,
  InfoTeacherCaptureText,
  InfoTeacherContainer,
  InfoTeacherFilesContainer,
  InfoTeacherHeadText,
  InfoTeacherMainText,
  InfoTextArea,
  InfoTextAreaBig,
  InfoTextContainer,
  InfoUploadAvatar,
} from "./InfoTeacher.styled";
import { Box } from "@mui/system";
import { InfoUploadFiles } from "./InfoUploadFiles";
import axios from "axios";
import { Button } from "../../../shared/ui";
import { ReactComponent as Avatar } from "./icon.svg";
import { ReactComponent as Document } from "./document.svg";
import React, { useRef, useState } from "react";
import {registerModel} from "../model/Register.model";
import {RegisterType} from "../Register.types";
import {BACK_URL} from "../../../shared/back/backURL";
import {RegisterButtonsContainer} from "../Register.styled";

const schema = yup.object().shape({
  education: yup.string().required("Образование обязательно"),
  experience: yup.string().required("Опыт работы обязателен"),
  aboutMe: yup
    .string()
    .min(20, "О себе должно быть минимум 100 символов")
    .required("Поле 'О себе' обязательно"),
});

export const InfoTeacher = () => {
  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
    defaultValues: {
      education: "",
      experience: "",
      aboutMe: "",
    },
  });

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const videoInputRef = useRef<HTMLInputElement | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [selectedVideo, setSelectedVideo] = useState<File | null>(null);
  const [previewSrc, setPreviewSrc] = useState<string | null>(null);
  const [documents, setDocuments] = useState<File[]>([]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const file = e.target.files[0];
      setSelectedFile(file);
      setPreviewSrc(URL.createObjectURL(file));
    }
  };

  const handleVideoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setSelectedVideo(e.target.files[0]);
    }
  };

  const handleFileButtonClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const handleVideoButtonClick = () => {
    if (videoInputRef.current) {
      videoInputRef.current.click();
    }
  };

  const uploadPhoto = async () => {
    if (!selectedFile) {
      alert("Пожалуйста, выберите фото.");
      return;
    }

    const formData = new FormData();
    formData.append("picture", selectedFile);

    try {
      await axios.post(BACK_URL + "api/user/picture", formData, {
        withCredentials: true,
        headers: { "Content-Type": "multipart/form-data" },
      });
      console.log("Фото успешно загружено");
    } catch (error) {
      throw Error(error);
    }
  };

  const uploadVideo = async () => {
    if (!selectedVideo) {
      alert("Пожалуйста, выберите видео.");
      return;
    }

    const formData = new FormData();
    formData.append("video", selectedVideo);

    try {
      await axios.post(BACK_URL + "api/user/video", formData, {
        withCredentials: true,
        headers: { "Content-Type": "multipart/form-data" },
      });
      console.log("Видео успешно загружено");
    } catch (error) {
      throw Error(error);
    }
  };

  const uploadDocuments = async () => {
    if (documents.length === 0) {
      alert("Пожалуйста, выберите документы.");
      return;
    }

    const formData = new FormData();
    // @ts-ignore
    formData.append("doc", documents[0]);

    try {
      await axios.post(BACK_URL + "api/user/docs", formData, {
        withCredentials: true,
        headers: { "Content-Type": "multipart/form-data" },
      });
      console.log("Документы успешно загружены");
    } catch (error) {
      throw Error(error);
    }
  };

  const setInfo = async (data: { education: string; experience: string; aboutMe: string }) => {
    try {
      await uploadPhoto();
      await uploadVideo();
      await uploadDocuments();

      await axios.patch(
        BACK_URL + "api/user/profile",
        {
          bio: data.aboutMe,
          education: data.education,
          background: data.experience,
        },
        { withCredentials: true }
      );

      registerModel.setPage(RegisterType.TeacherSubscribe)
    } catch (error) {
      console.error("Ошибка при обновлении информации", error);
    }
  };

  return (
    <InfoTeacherContainer>
      <InfoTeacherHeadText>Заполнение информации</InfoTeacherHeadText>
      <InfoTeacherFilesContainer>
        <Box>
          <InfoTeacherMainText>Загрузка фото</InfoTeacherMainText>
          <InfoUploadAvatar>
            {previewSrc ? (
              <AvtarBlock as="img" src={previewSrc} alt="Предпросмотр аватара" />
            ) : (
              <AvtarBlockBox>
                <Avatar />
              </AvtarBlockBox>
            )}
          </InfoUploadAvatar>
          <InfoTeacherCaptureText>Изображение, макс размер 5 МБ(png)</InfoTeacherCaptureText>
          <input
            type="file"
            ref={fileInputRef}
            style={{ display: "none" }}
            onChange={handleFileChange}
          />
          <InfoButton onClick={handleFileButtonClick}>Выбрать файл</InfoButton>
        </Box>
        <Box>
          <InfoUploadFiles onFilesSelected={setDocuments} />
        </Box>
      </InfoTeacherFilesContainer>
      <Box>
        <InfoTeacherMainText>Загрузка видео</InfoTeacherMainText>
        <input
          type="file"
          ref={videoInputRef}
          style={{ display: "none" }}
          accept="video/*"
          onChange={handleVideoChange}
        />
        {!selectedVideo && <InfoButtonVideo onClick={handleVideoButtonClick}>Выбрать видео</InfoButtonVideo>}

        {selectedVideo && <Box display="flex" justifyContent="space-between" width={"100%"}>
          <Box display="flex" gap={1} alignItems="center">
            <Document />
            <InfoTeacherCaptureText>{selectedVideo.name}</InfoTeacherCaptureText>
          </Box>
          <InfoButton onClick={handleVideoButtonClick}>изменить</InfoButton>
        </Box>}


      </Box>
      <form onSubmit={handleSubmit(setInfo)}>
        <InfoTextContainer spacing={45 / 8}>
          <Box>
            <InfoTeacherMainText>Образование</InfoTeacherMainText>
            <Controller
              name="education"
              control={control}
              render={({ field }) => <InfoTextArea {...field} />}
            />
            {errors.education && <ErrorMessage>{errors.education.message}</ErrorMessage>}
          </Box>
          <Box>
            <InfoTeacherMainText>Опыт работы</InfoTeacherMainText>
            <Controller
              name="experience"
              control={control}
              render={({ field }) => <InfoTextArea {...field} />}
            />
            {errors.experience && <ErrorMessage>{errors.experience.message}</ErrorMessage>}
          </Box>
          <Box>
            <InfoTeacherMainText>О себе (мин 20 символов)</InfoTeacherMainText>
            <Controller
              name="aboutMe"
              control={control}
              render={({ field }) => <InfoTextAreaBig {...field} />}
            />
            {errors.aboutMe && <ErrorMessage>{errors.aboutMe.message}</ErrorMessage>}
          </Box>
        </InfoTextContainer>
        <RegisterButtonsContainer>
          <Button variant="outlinedv4" onClick={() => registerModel.setPage(RegisterType.email)}>Назад</Button>
          <Button variant="outlinedv4" type="submit" ml={18 / 8}>Добавить</Button>
        </RegisterButtonsContainer>

      </form>
    </InfoTeacherContainer>
  );
};
