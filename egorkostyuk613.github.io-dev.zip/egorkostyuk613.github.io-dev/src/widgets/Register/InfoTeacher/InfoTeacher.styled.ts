import {styled} from "../../../shared/lib";
import {Box, Stack} from "@mui/system";

export const InfoTeacherContainer = styled(Box)({})

export const InfoTeacherHeadText = styled('p')({
  fontSize: 45,
  fontWeight: '600px',
  lineHeight: '62px',
  textAlign: 'left'
})

export const InfoTeacherMainText = styled('p')({
  fontSize: 24,
  fontWeight: '500px',
  lineHeight: '43px',
  textAlign: 'left'
})

export const InfoTeacherCaptureText = styled('p')({
  fontSize: 12,
  fontWeight: '500px',
  lineHeight: '43px',
  textAlign: 'left'
})

export const InfoTeacherFilesContainer = styled(Box)({
  width: '100%',
  display: 'flex',
  justifyContent: 'space-between',
})

export const InfoUploadAvatar = styled(Box)({
  background: 'rgba(242, 242, 242, 1)',
  borderRadius: 10,
  width: 193,
  height: 214,
})

export const AvtarBlock = styled('img')({
  width: '100%',
  height: '100%',
  borderRadius: 10,
  border: 'none',
})

export const AvtarBlockBox = styled(Box)({
  width: '100%',
  height: '100%',
  borderRadius: 10,
  border: 'none',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
})

export const InfoTextContainer = styled(Stack)({})

export const InfoTextArea = styled('textarea')({
  background: 'rgba(242, 242, 242, 1)',
  border: 'none',
  width: "100%",
  borderRadius: 10,
  height: 80,
  padding: 10,
  resize: 'none'
})

export const InfoTextAreaBig = styled('textarea')({
  background: 'rgba(242, 242, 242, 1)',
  border: 'none',
  width: "100%",
  borderRadius: 10,
  height: 180,
  padding: 10,
  resize: 'none'
})

export const InfoButton = styled(Box)({
  background: 'rgba(193, 198, 224, 1)',
  padding: '12px 32px',
  borderRadius: 50,
  color: 'black',
  fontSize: 12,
  fontWeight: 500,
  cursor: 'pointer'
})

export const InfoButtonVideo = styled(Box)({
  background: 'rgba(193, 198, 224, 1)',
  padding: '12px 32px',
  borderRadius: 50,
  color: 'black',
  fontSize: 12,
  fontWeight: 500,
  cursor: 'pointer',
  width: 'fit-content'
})

export const NoneInput = styled('input')({
  display: 'none'
})


export const ErrorMessage = styled('p')({
  color: 'red',
  textAlign: 'left',
})

export const GreenMessage = styled('p')({
  color: 'green',
  textAlign: 'left',
})
