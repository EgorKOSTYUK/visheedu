export * from './InfoTeacher'
