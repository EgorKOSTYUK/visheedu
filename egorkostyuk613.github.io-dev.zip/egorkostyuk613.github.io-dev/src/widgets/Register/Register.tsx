import {
  GridWrapper,
  InputContainer,
  InputStyled,
  RegisterButtonsContainer,
  RegisterForm,
  RegisterImg,
  RegisterRoot,
  RegisterSelect,
  RegisterSelectContainer,
  RegisterText,
  RegisterTitle,
  RegisterWrapper,
  StyledSpan
} from "widgets/Register/Register.styled";
import * as yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import {Stack} from "@mui/system";
import {Button} from "shared/ui";
import arrow from './arrow.png'
import {Success} from "widgets/Register/Success";
import {useForm} from "react-hook-form";
import {RegisterFormSubmit} from "./Register.styled";
import {RegisterType} from "./Register.types";
import {RegisterTarif} from "./RegisterTarif/RegisterTarif";
import {registerModel} from "./model/Register.model";
import {observer} from "mobx-react";
import {RegisterTeachers} from "./RegisterTeachers";
import {Calendar} from "../Calendar/Calendar";
import {RegisterEmail} from "./RegisterEmail";
import {RegisterFormat} from "./RegisterFormat";
import {RegisterSoloEducated} from "./RegisterSoloEducated";
import {InfoTeacher} from "./InfoTeacher";
import {TeacherSubscribe} from "./TeacherSubscribe";
import {RegisterFunc} from "./apis/api";
import {CalendarStudent} from "./CalendarStudent/CalendarStudent";
import {ErrorMessageText} from "./CalendarStudent/CalendarStudent.styled";
import {Link} from "react-router-dom";

const schema = yup.object({
  name: yup.string().required('Имя обязательно'),
  surname: yup.string().required('Фамилия обязательна'),
  network: yup.string().required('Социальная сеть обязательна'),
  email: yup.string().email('Некорректный email').required('Email обязателен'),
  password: yup.string().required('Пароль обязателен').min(8, 'Пароль должен быть минимум 8 символов'),
  password_second: yup.string()
    .oneOf([yup.ref('password'), undefined], 'Пароли не совпадают')
    .required('Повторите пароль'),
  politics: yup.boolean().oneOf([true], 'Необходимо согласие с политикой конфиденциальности')
}).required();

export const Register = observer(() => {

  const {
    register,
    handleSubmit,
    formState: { errors }
  } = useForm({
    resolver: yupResolver(schema)
  })

  const onSubmit = async (data: any) => {
    registerModel.setEmail(data.email)
    try{
      await RegisterFunc({
        email: data.email,
        password: data.password,
        name: data.name,
        network: data.network,
        surname: data.surname,
        role: registerModel.selectRole === "преподаватель" ? 1 : 2,
        termsAgreement: data.politics,
      })
      registerModel.setPage(RegisterType.email)
    }
    catch (e){
      console.log(e)
    }




  }

  const renderFunc = () => {

    switch (registerModel.registerPage) {
      case RegisterType.info:
      return <RegisterFormSubmit onSubmit={handleSubmit(onSubmit)}>
        <RegisterButtonsContainer>
          <Link to="/login">
            <Button variant="outlinedv4">Войти <RegisterImg src={arrow}/></Button>
          </Link>
        </RegisterButtonsContainer>
        <RegisterWrapper>
          {registerModel.selectRole === "преподаватель" ? <RegisterTitle>Заполните <StyledSpan>форму</StyledSpan> и мы обязательно свяжемся с Вами.</RegisterTitle> :  <RegisterTitle>Форма регистрации</RegisterTitle>}

          <RegisterForm>
            <Stack spacing={20 / 8} mt={28 / 8}>
              <GridWrapper>
                <InputContainer slots={{
                  input: InputStyled
                }} placeholder="Имя" {...register('name')}/>
                {errors.name && <ErrorMessageText>{errors.name.message}</ErrorMessageText>}
                <InputContainer slots={{
                  input: InputStyled
                }} placeholder="Фамилия" {...register('surname')}/>
                {errors.surname && <ErrorMessageText>{errors.surname.message}</ErrorMessageText>}
              </GridWrapper>
              <InputContainer slots={{
                input: InputStyled
              }} placeholder="Социальная сеть" {...register('network')}/>
              {errors.network && <ErrorMessageText>{errors.network.message}</ErrorMessageText>}
              <InputContainer slots={{
                input: InputStyled
              }} placeholder="Электронная почта" type="email" {...register('email')}/>
              {errors.email && <ErrorMessageText>{errors.email.message}</ErrorMessageText>}
              <InputContainer slots={{
                input: InputStyled
              }} placeholder="Пароль" type="password" {...register('password')}/>
              {errors.password && <ErrorMessageText>{errors.password.message}</ErrorMessageText>}
              <InputContainer slots={{
                input: InputStyled
              }} placeholder="Повторите пароль" type="password" {...register('password_second')}/>
              {errors.password_second && <ErrorMessageText>{errors.password_second.message}</ErrorMessageText>}

              <input type="checkbox" {...register("politics")} />
              <p>
              Нажимая на кнопку «Далее», я подтверждаю что ознакомлен с договором оферты и политикой конфиденциальности на платформе.
              </p>
            </Stack>
          </RegisterForm>
          <RegisterText>Вы хотите зарегестрироваться как?</RegisterText>
          <RegisterSelectContainer>
            <RegisterSelect $select={registerModel.selectRole === "ученик"} onClick={() => registerModel.setRole("ученик")}>УЧЕНИК</RegisterSelect>
            <RegisterSelect $select={registerModel.selectRole === "преподаватель"} onClick={() => registerModel.setRole("преподаватель")}>ПРЕПОДАВАТЕЛЬ</RegisterSelect>
          </RegisterSelectContainer>
        </RegisterWrapper>
        <RegisterButtonsContainer>
          {registerModel.selectRole === "ученик" && <Button variant="outlinedv4" onClick={() => window.history.back()}>Назад</Button>}
          <Button variant="outlinedv4" ml={18 / 8} type="submit">Продолжить</Button>
        </RegisterButtonsContainer>
      </RegisterFormSubmit>
      case RegisterType.email:
        return <RegisterEmail />
      case RegisterType.format:
        return <RegisterFormat />
      case RegisterType.infoTeacher:
        return <InfoTeacher />
      case RegisterType.tarif:
        return <RegisterTeachers />
      case RegisterType.TeacherSubscribe:
        return <TeacherSubscribe />
      case RegisterType.soloTarif:
        return <RegisterSoloEducated />
      case RegisterType.teacher:
        return <RegisterTarif />
      case RegisterType.time:
        return <Calendar />
      case RegisterType.timeStudent:
        return <CalendarStudent />
      case RegisterType.thanks:
        return <Success select={registerModel.selectRole}/>
    }
  }

  return <RegisterRoot>
    {renderFunc()}
  </RegisterRoot>
})
