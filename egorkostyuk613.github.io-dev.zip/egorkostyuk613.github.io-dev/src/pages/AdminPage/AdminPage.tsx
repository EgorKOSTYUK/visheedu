import {Fragment} from "react";
import {Header} from "../../widgets/Header";
import {Footer} from "../../widgets/Footer/Footer";
import {AccountAdmin} from "../../widgets/Admin/ui/Admin";

export const AdminPage = () => {
  return <Fragment>
    <Header />
    <AccountAdmin />
    <Footer />
  </Fragment>
}
