export { TeacherPage } from "./TeacherPage";
