export { RegisterPage} from './RegisterPage'
