export { NewsPage } from './NewsPage'
