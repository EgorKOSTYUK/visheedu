import {action, computed, observable} from "mobx";

class AuthModel {
  @observable accessor user: any = null
  @observable accessor isLoading: boolean = false
  @observable accessor books: any = null

  @computed get accountRole(){
    return this.user.role
  }

  @action.bound setUser (user: any) {
    this.isLoading = true;
    this.user = user?.data || null;
    this.isLoading = false;
  }

  @action.bound setBooks (books: any) {
    this.books = books;
  }

  @action.bound setBooksAxios (books: any) {
    this.books = books?.studyBooks;
  }


}

export const authModel = new AuthModel();
