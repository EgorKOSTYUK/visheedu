export const GET_USER_INFO = 'GET_USER_INFO';
