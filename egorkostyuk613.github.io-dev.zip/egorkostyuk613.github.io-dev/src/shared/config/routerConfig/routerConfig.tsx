import { RouteProps } from "react-router-dom";

import { MainPage } from "pages/MainPage";
import { AboutPage } from "pages/AboutPage";
import { TeacherPage } from "pages/TeachersPage";
import { TariffsPage } from "pages/TariffsPage";
import { NewsPage } from "pages/NewsPage";
import {LoginPage} from "pages/LoginPage";
import {RegisterPage} from "pages/RegisterPage";
import {AccountPage} from "pages/AccountPage";
import {PrivatRoute} from "../../ui/PrivatRoute/PrivatRoute";
import {AccountSchedule} from "../../../widgets/Account/ui/AccountStudent/AccountSchedule";
import {AccountHomeWork} from "../../../widgets/Account/ui/AccountStudent/AccountHomeWork";
import {HomeWork} from "../../../widgets/Account/ui/AccountStudent/AccountHomeWork/HomeWork/HomeWork";
import { SendHomeWork } from "../../../widgets/Account/ui/AccountStudent/AccountHomeWork/HomeWork/SendHomeWork";
import {AccountCourses} from "../../../widgets/Account/ui/AccountStudent/AccountCourses";
import {AccountMaterial} from "../../../widgets/Account/ui/AccountStudent/AccountMaterial";
import {AccountSettings} from "../../../widgets/Account/ui/AccountStudent/AccountSettings";
import {
  AccountTeachertSchedule
} from "../../../widgets/Account/ui/AccountTeacher/AccountSchedule";
import {AccountList} from "../../../widgets/Account/ui/AccountTeacher/AccountList";
import {AccountTeacherStudent} from "../../../widgets/Account/ui/AccountTeacher/AccountTeacherStudent";
import {
  AccountTeacherAddHomeWork
} from "../../../widgets/Account/ui/AccountTeacher/AccountTeacherAddHomeWork/AccountTeacherAddHomeWork";
import {AccountTeacherSettings} from "../../../widgets/Account/ui/AccountTeacher/AccountTeacherSettings";
import {
  AccountMaterialTeacher
} from "../../../widgets/Account/ui/AccountTeacher/AccountMaterialTeacher/AccountMaterialTeacher";
import {
  AccountStudyMaterialSolo
} from "../../../widgets/Account/ui/AccountTeacher/AccountStudyMaterialSolo/AccountStudyMaterialSolo";
import {AdminPage} from "../../../pages/AdminPage";
import {AllStudent} from "../../../widgets/Admin/ui/AllStudent/AllStudent";
import {AllTeachers} from "../../../widgets/Admin/ui/AllTeachers/AllTeachers";
import {AllMaterials} from "../../../widgets/Admin/ui/AllMaterials/AllMaterials";
import {AllReviews} from "../../../widgets/Admin/ui/AllReviews/AllReviews";
import {AdminTeacherSolo} from "../../../widgets/Admin/ui/AllMaterials/AdminTeacherSolo/AdminTecherSolo";
import {AdminStudentSolo} from "../../../widgets/Admin/ui/AllMaterials/AdminStudentSolo/AdminStudentSolo";
import {MaterialAdmin} from "../../../widgets/Admin/ui/MaterialAdmin/MaterialAdmin";
import {
  AccountTeacherContactUs
} from "../../../widgets/Account/ui/AccountTeacher/AccountTeacherContactUs/AccountTeacherContactUs";
import {ChangeSchadule} from "../../../widgets/Account/ui/AccountTeacher/ChangeSchadule";
import {MaterialList} from "../../../widgets/Admin/ui/MaterialAdmin/MaterialList/MaterialList";
import {AdminProducts} from "../../../widgets/Admin/ui/AdminProducts/AdminProducts";
import {
  MaterialCoursesList
} from "../../../widgets/Account/ui/AccountTeacher/AccountMaterialTeacher/MaterialCoursesList/MaterialCoursesList";


export enum AppRoutes {
  main = "main",
  about = "about",
  teacher = 'teacher',
  tariffs = 'tariffs',
  news = 'news',
  login = 'login',
  register = 'register',
  account = 'account',
  admin = 'administr'
}

export const RoutePath: Record<AppRoutes, string> = {
  [AppRoutes.main]: "/",
  [AppRoutes.about]: "/about",
  [AppRoutes.teacher]: "/teacher",
  [AppRoutes.tariffs]: "/tariffs",
  [AppRoutes.news]: "/news",
  [AppRoutes.login]: "/login",
  [AppRoutes.register]: '/register',
  [AppRoutes.account]: '/account/*',
  [AppRoutes.admin]: '/administr/*',
};

export const routeConfig = {
  [AppRoutes.main]: {
    path: RoutePath.main,
    element: <MainPage />
  },
  [AppRoutes.about]: {
    path: RoutePath.about,
    element: <AboutPage />
  },
  [AppRoutes.teacher]: {
    path: RoutePath.teacher,
    element: <TeacherPage />
  },
  [AppRoutes.tariffs]: {
    path: RoutePath.tariffs,
    element: <TariffsPage />
  },
  [AppRoutes.news]: {
    path: RoutePath.news,
    element: <NewsPage />
  },
  [AppRoutes.login]: {
    path: RoutePath.login,
    element: <LoginPage />
  },
  [AppRoutes.register]: {
    path: RoutePath.register,
    element: <RegisterPage />
  },
  [AppRoutes.account]: {
    path: RoutePath.account,
    element: <PrivatRoute><AccountPage /></PrivatRoute>,
    children: [
      {
        path: "schedule",
        element: <AccountSchedule />,
      },
      {
        path: "contactUs",
        element: <AccountTeacherContactUs />,
      },
      {
        path: "teacher/schedule",
        element: <AccountTeachertSchedule />,
      },
      {
        path: "teacher/changeSchadule",
        element: <ChangeSchadule />,
      },
      {
        path: "teacher/students",
        element: <AccountList />,
      },
      {
        path: "teacher/contactUs",
        element: <AccountTeacherContactUs />,
      },
      // {
      //   path: "teacher/materials",
      //   element: <AccountMaterialTeacher />,
      // },
      {
        path: "teacher/materials/:coureId",
        element: <AccountMaterialTeacher />,
      },
      {
        path: "teacher/materials",
        element: <MaterialCoursesList />,
      },
      {
        path: "teacher/materials/:coureId/:bookId",
        element: <AccountStudyMaterialSolo />,
      },
      {
        path: "teacher/students/:studentId",
        element: <AccountTeacherStudent />,
      },
      {
        path: "teacher/students/:studentId/:hw",
        element: <AccountTeacherAddHomeWork />,
      },
      {
        path: "homeWork",
        element: <AccountHomeWork />,
      },
      {
        path: "courses",
        element: <AccountCourses />,
      },
      {
        path: "materials/:coureId",
        element: <AccountMaterial />,
      },
      {
        path: "settings",
        element: <AccountSettings />,
      },
      {
        path: "teacher/settings",
        element: <AccountTeacherSettings />,
      },
      {
        path: "homeWork/:homeWorkId",
        element: <HomeWork />,
      },
      {
        path: "homeWork/:homeWorkId/:slug",
        element: <SendHomeWork />,
      }
    ],
  },
  [AppRoutes.admin]: {
    path: RoutePath.administr,
    element: <PrivatRoute><AdminPage /></PrivatRoute>,
    children: [
      {
        path: "students",
        element: <AllStudent />
      },
      {
        path: "students/:studentId",
        element: <AdminStudentSolo />
      },
      {
        path: "teachers",
        element: <AllTeachers />
      },
      {
        path: "teachers/:teacherId",
        element: <AdminTeacherSolo />
      },
      {
        path: "materials",
        element: <AllMaterials />
      },
      {
        path: "tarifs",
        element: <AdminProducts />
      },
      {
        path: "materials/:courseId/:bookId",
        element: <MaterialAdmin />
      },
      {
        path: "materials/:courseId",
        element: <MaterialList />,
      },
      {
        path: "reviews",
        element: <AllReviews />
      },
    ]
  }
};
