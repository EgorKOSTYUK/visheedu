import { zIndex } from './zIndex';

export type ZIndex = typeof zIndex;
