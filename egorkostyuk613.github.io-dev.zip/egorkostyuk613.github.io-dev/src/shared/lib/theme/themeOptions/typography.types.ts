import { typography } from './typography';

export type TypographyVariant = keyof typeof typography;

export type ThemeTypography = typeof typography;
