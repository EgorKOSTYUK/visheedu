import { breakpoints } from './breakpoints';

export type Breakpoint = keyof typeof breakpoints.values;
