import { variables } from './variables';

export type Variables = typeof variables;
