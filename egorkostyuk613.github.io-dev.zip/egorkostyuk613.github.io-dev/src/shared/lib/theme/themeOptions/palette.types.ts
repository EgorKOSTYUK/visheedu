import { palette } from './palette';

export type Palette = typeof palette;
