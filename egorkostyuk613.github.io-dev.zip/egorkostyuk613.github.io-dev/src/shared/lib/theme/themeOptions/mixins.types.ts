import { mixins } from './mixins';

export type Mixins = typeof mixins;
