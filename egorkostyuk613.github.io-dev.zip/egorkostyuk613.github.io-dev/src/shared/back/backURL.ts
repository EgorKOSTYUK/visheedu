export const BACK_URL = 'https://vishe-backend.fly.dev/'
// export const BACK_URL = 'http://localhost:4000/'
